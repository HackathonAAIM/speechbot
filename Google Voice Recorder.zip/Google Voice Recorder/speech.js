! function() {
    function resolve() {
        document.body.removeAttribute("unresolved")
    }
    window.WebComponents ? addEventListener("WebComponentsReady", resolve) : "interactive" === document.readyState || "complete" === document.readyState ? resolve() : addEventListener("DOMContentLoaded", resolve)
}(), window.Polymer = {
        Settings: function() {
            var settings = window.Polymer || {};
            if (!settings.noUrlSettings)
                for (var o, parts = location.search.slice(1).split("&"), i = 0; i < parts.length && (o = parts[i]); i++) o = o.split("="), o[0] && (settings[o[0]] = o[1] || !0);
            return settings.wantShadow = "shadow" === settings.dom, settings.hasShadow = Boolean(Element.prototype.createShadowRoot), settings.nativeShadow = settings.hasShadow && !window.ShadowDOMPolyfill, settings.useShadow = settings.wantShadow && settings.hasShadow, settings.hasNativeImports = Boolean("import" in document.createElement("link")), settings.useNativeImports = settings.hasNativeImports, settings.useNativeCustomElements = !window.CustomElements || window.CustomElements.useNative, settings.useNativeShadow = settings.useShadow && settings.nativeShadow, settings.usePolyfillProto = !settings.useNativeCustomElements && !Object.__proto__, settings.hasNativeCSSProperties = !navigator.userAgent.match("AppleWebKit/601") && window.CSS && CSS.supports && CSS.supports("box-shadow", "0 0 0 var(--foo)"), settings.useNativeCSSProperties = settings.hasNativeCSSProperties && settings.lazyRegister && settings.useNativeCSSProperties, settings.isIE = navigator.userAgent.match("Trident"), settings
        }()
    },
    function() {
        var userPolymer = window.Polymer;
        window.Polymer = function(prototype) {
            "function" == typeof prototype && (prototype = prototype.prototype), prototype || (prototype = {}), prototype = desugar(prototype);
            var customCtor = prototype === prototype.constructor.prototype ? prototype.constructor : null,
                options = {
                    prototype: prototype
                };
            prototype["extends"] && (options["extends"] = prototype["extends"]), Polymer.telemetry._registrate(prototype);
            var ctor = document.registerElement(prototype.is, options);
            return customCtor || ctor
        };
        var desugar = function(prototype) {
            var base = Polymer.Base;
            return prototype["extends"] && (base = Polymer.Base._getExtendedPrototype(prototype["extends"])), prototype = Polymer.Base.chainObject(prototype, base), prototype.registerCallback(), prototype
        };
        if (userPolymer)
            for (var i in userPolymer) Polymer[i] = userPolymer[i];
        Polymer.Class = function(prototype) {
            return prototype.factoryImpl || (prototype.factoryImpl = function() {}), desugar(prototype).constructor
        }
    }(), Polymer.telemetry = {
        registrations: [],
        _regLog: function(prototype) {
            console.log("[" + prototype.is + "]: registered")
        },
        _registrate: function(prototype) {
            this.registrations.push(prototype), Polymer.log && this._regLog(prototype)
        },
        dumpRegistrations: function() {
            this.registrations.forEach(this._regLog)
        }
    }, Object.defineProperty(window, "currentImport", {
        enumerable: !0,
        configurable: !0,
        get: function() {
            return (document._currentScript || document.currentScript || {}).ownerDocument
        }
    }), Polymer.RenderStatus = {
        _ready: !1,
        _callbacks: [],
        whenReady: function(cb) {
            this._ready ? cb() : this._callbacks.push(cb)
        },
        _makeReady: function() {
            this._ready = !0;
            for (var i = 0; i < this._callbacks.length; i++) this._callbacks[i]();
            this._callbacks = []
        },
        _catchFirstRender: function() {
            requestAnimationFrame(function() {
                Polymer.RenderStatus._makeReady()
            })
        },
        _afterNextRenderQueue: [],
        _waitingNextRender: !1,
        afterNextRender: function(element, fn, args) {
            this._watchNextRender(), this._afterNextRenderQueue.push([element, fn, args])
        },
        hasRendered: function() {
            return this._ready
        },
        _watchNextRender: function() {
            if (!this._waitingNextRender) {
                this._waitingNextRender = !0;
                var fn = function() {
                    Polymer.RenderStatus._flushNextRender()
                };
                this._ready ? requestAnimationFrame(fn) : this.whenReady(fn)
            }
        },
        _flushNextRender: function() {
            var self = this;
            setTimeout(function() {
                self._flushRenderCallbacks(self._afterNextRenderQueue), self._afterNextRenderQueue = [], self._waitingNextRender = !1
            })
        },
        _flushRenderCallbacks: function(callbacks) {
            for (var h, i = 0; i < callbacks.length; i++) h = callbacks[i], h[1].apply(h[0], h[2] || Polymer.nar)
        }
    }, window.HTMLImports ? HTMLImports.whenReady(function() {
        Polymer.RenderStatus._catchFirstRender()
    }) : Polymer.RenderStatus._catchFirstRender(), Polymer.ImportStatus = Polymer.RenderStatus, Polymer.ImportStatus.whenLoaded = Polymer.ImportStatus.whenReady,
    function() {
        "use strict";
        var settings = Polymer.Settings;
        Polymer.Base = {
            __isPolymerInstance__: !0,
            _addFeature: function(feature) {
                this.mixin(this, feature)
            },
            registerCallback: function() {
                if ("max" === settings.lazyRegister) this.beforeRegister && this.beforeRegister();
                else {
                    this._desugarBehaviors();
                    for (var b, i = 0; i < this.behaviors.length; i++) b = this.behaviors[i], b.beforeRegister && b.beforeRegister.call(this);
                    this.beforeRegister && this.beforeRegister()
                }
                this._registerFeatures(), settings.lazyRegister || this.ensureRegisterFinished()
            },
            createdCallback: function() {
                if (settings.disableUpgradeEnabled) {
                    if (this.hasAttribute("disable-upgrade")) return this._propertySetter = disableUpgradePropertySetter, this._configValue = null, void(this.__data__ = {});
                    this.__hasInitialized = !0
                }
                this.__initialize()
            },
            __initialize: function() {
                this.__hasRegisterFinished || this._ensureRegisterFinished(this.__proto__), Polymer.telemetry.instanceCount++, this.root = this;
                for (var b, i = 0; i < this.behaviors.length; i++) b = this.behaviors[i], b.created && b.created.call(this);
                this.created && this.created(), this._initFeatures()
            },
            ensureRegisterFinished: function() {
                this._ensureRegisterFinished(this)
            },
            _ensureRegisterFinished: function(proto) {
                if (proto.__hasRegisterFinished !== proto.is || !proto.is) {
                    if ("max" === settings.lazyRegister) {
                        proto._desugarBehaviors();
                        for (var b, i = 0; i < proto.behaviors.length; i++) b = proto.behaviors[i], b.beforeRegister && b.beforeRegister.call(proto)
                    }
                    proto.__hasRegisterFinished = proto.is, proto._finishRegisterFeatures && proto._finishRegisterFeatures();
                    for (var pb, j = 0; j < proto.behaviors.length; j++) pb = proto.behaviors[j], pb.registered && pb.registered.call(proto);
                    proto.registered && proto.registered(), settings.usePolyfillProto && proto !== this && proto.extend(this, proto)
                }
            },
            attachedCallback: function() {
                var self = this;
                Polymer.RenderStatus.whenReady(function() {
                    self.isAttached = !0;
                    for (var b, i = 0; i < self.behaviors.length; i++) b = self.behaviors[i], b.attached && b.attached.call(self);
                    self.attached && self.attached()
                })
            },
            detachedCallback: function() {
                var self = this;
                Polymer.RenderStatus.whenReady(function() {
                    self.isAttached = !1;
                    for (var b, i = 0; i < self.behaviors.length; i++) b = self.behaviors[i], b.detached && b.detached.call(self);
                    self.detached && self.detached()
                })
            },
            attributeChangedCallback: function(name, oldValue, newValue) {
                this._attributeChangedImpl(name);
                for (var b, i = 0; i < this.behaviors.length; i++) b = this.behaviors[i], b.attributeChanged && b.attributeChanged.call(this, name, oldValue, newValue);
                this.attributeChanged && this.attributeChanged(name, oldValue, newValue)
            },
            _attributeChangedImpl: function(name) {
                this._setAttributeToProperty(this, name)
            },
            extend: function(target, source) {
                if (target && source)
                    for (var n, n$ = Object.getOwnPropertyNames(source), i = 0; i < n$.length && (n = n$[i]); i++) this.copyOwnProperty(n, source, target);
                return target || source
            },
            mixin: function(target, source) {
                for (var i in source) target[i] = source[i];
                return target
            },
            copyOwnProperty: function(name, source, target) {
                var pd = Object.getOwnPropertyDescriptor(source, name);
                pd && Object.defineProperty(target, name, pd)
            },
            _logger: function(level, args) {
                switch (1 === args.length && Array.isArray(args[0]) && (args = args[0]), level) {
                    case "log":
                    case "warn":
                    case "error":
                        console[level].apply(console, args)
                }
            },
            _log: function() {
                var args = Array.prototype.slice.call(arguments, 0);
                this._logger("log", args)
            },
            _warn: function() {
                var args = Array.prototype.slice.call(arguments, 0);
                this._logger("warn", args)
            },
            _error: function() {
                var args = Array.prototype.slice.call(arguments, 0);
                this._logger("error", args)
            },
            _logf: function() {
                return this._logPrefix.concat(this.is).concat(Array.prototype.slice.call(arguments, 0))
            }
        }, Polymer.Base._logPrefix = function() {
            var color = window.chrome && !/edge/i.test(navigator.userAgent) || /firefox/i.test(navigator.userAgent);
            return color ? ["%c[%s::%s]:", "font-weight: bold; background-color:#EEEE00;"] : ["[%s::%s]:"]
        }(), Polymer.Base.chainObject = function(object, inherited) {
            return object && inherited && object !== inherited && (Object.__proto__ || (object = Polymer.Base.extend(Object.create(inherited), object)), object.__proto__ = inherited), object
        }, Polymer.Base = Polymer.Base.chainObject(Polymer.Base, HTMLElement.prototype), Polymer.BaseDescriptors = {};
        var disableUpgradePropertySetter;
        if (settings.disableUpgradeEnabled) {
            disableUpgradePropertySetter = function(property, value) {
                this.__data__[property] = value
            };
            var origAttributeChangedCallback = Polymer.Base.attributeChangedCallback;
            Polymer.Base.attributeChangedCallback = function(name, oldValue, newValue) {
                this.__hasInitialized || "disable-upgrade" !== name || (this.__hasInitialized = !0, this._propertySetter = Polymer.Bind._modelApi._propertySetter, this._configValue = Polymer.Base._configValue, this.__initialize()), origAttributeChangedCallback.call(this, name, oldValue, newValue)
            }
        }
        Polymer["instanceof"] = window.CustomElements ? CustomElements["instanceof"] : function(obj, ctor) {
            return obj instanceof ctor
        }, Polymer.isInstance = function(obj) {
            return Boolean(obj && obj.__isPolymerInstance__)
        }, Polymer.telemetry.instanceCount = 0
    }(),
    function() {
        function forceDomModulesUpgrade() {
            if (cePolyfill)
                for (var m, script = document._currentScript || document.currentScript, doc = script && script.ownerDocument || document, modules = doc.querySelectorAll("dom-module"), i = modules.length - 1; i >= 0 && (m = modules[i]); i--) {
                    if (m.__upgraded__) return;
                    CustomElements.upgrade(m)
                }
        }
        var modules = {},
            lcModules = {},
            findModule = function(id) {
                return modules[id] || lcModules[id.toLowerCase()]
            },
            DomModule = function() {
                return document.createElement("dom-module")
            };
        DomModule.prototype = Object.create(HTMLElement.prototype), Polymer.Base.mixin(DomModule.prototype, {
            createdCallback: function() {
                this.register()
            },
            register: function(id) {
                id = id || this.id || this.getAttribute("name") || this.getAttribute("is"), id && (this.id = id, modules[id] = this, lcModules[id.toLowerCase()] = this)
            },
            "import": function(id, selector) {
                if (id) {
                    var m = findModule(id);
                    return m || (forceDomModulesUpgrade(), m = findModule(id)), m && selector && (m = m.querySelector(selector)), m
                }
            }
        }), Object.defineProperty(DomModule.prototype, "constructor", {
            value: DomModule,
            configurable: !0,
            writable: !0
        });
        var cePolyfill = window.CustomElements && !CustomElements.useNative;
        document.registerElement("dom-module", DomModule)
    }(), Polymer.Base._addFeature({
        _prepIs: function() {
            if (!this.is) {
                var module = (document._currentScript || document.currentScript).parentNode;
                if ("dom-module" === module.localName) {
                    var id = module.id || module.getAttribute("name") || module.getAttribute("is");
                    this.is = id
                }
            }
            this.is && (this.is = this.is.toLowerCase())
        }
    }), Polymer.Base._addFeature({
        behaviors: [],
        _desugarBehaviors: function() {
            this.behaviors.length && (this.behaviors = this._desugarSomeBehaviors(this.behaviors))
        },
        _desugarSomeBehaviors: function(behaviors) {
            var behaviorSet = [];
            behaviors = this._flattenBehaviorsList(behaviors);
            for (var i = behaviors.length - 1; i >= 0; i--) {
                var b = behaviors[i]; - 1 === behaviorSet.indexOf(b) && (this._mixinBehavior(b), behaviorSet.unshift(b))
            }
            return behaviorSet
        },
        _flattenBehaviorsList: function(behaviors) {
            for (var flat = [], i = 0; i < behaviors.length; i++) {
                var b = behaviors[i];
                b instanceof Array ? flat = flat.concat(this._flattenBehaviorsList(b)) : b ? flat.push(b) : this._warn(this._logf("_flattenBehaviorsList", "behavior is null, check for missing or 404 import"))
            }
            return flat
        },
        _mixinBehavior: function(b) {
            for (var n, n$ = Object.getOwnPropertyNames(b), useAssignment = b._noAccessors, i = 0; i < n$.length && (n = n$[i]); i++) Polymer.Base._behaviorProperties[n] || this.hasOwnProperty(n) || (useAssignment ? this[n] = b[n] : this.copyOwnProperty(n, b, this))
        },
        _prepBehaviors: function() {
            this._prepFlattenedBehaviors(this.behaviors)
        },
        _prepFlattenedBehaviors: function(behaviors) {
            for (var i = 0, l = behaviors.length; l > i; i++) this._prepBehavior(behaviors[i]);
            this._prepBehavior(this)
        },
        _marshalBehaviors: function() {
            for (var i = 0; i < this.behaviors.length; i++) this._marshalBehavior(this.behaviors[i]);
            this._marshalBehavior(this)
        }
    }), Polymer.Base._behaviorProperties = {
        hostAttributes: !0,
        beforeRegister: !0,
        registered: !0,
        properties: !0,
        observers: !0,
        listeners: !0,
        created: !0,
        attached: !0,
        detached: !0,
        attributeChanged: !0,
        ready: !0,
        _noAccessors: !0
    }, Polymer.Base._addFeature({
        _getExtendedPrototype: function(tag) {
            return this._getExtendedNativePrototype(tag)
        },
        _nativePrototypes: {},
        _getExtendedNativePrototype: function(tag) {
            var p = this._nativePrototypes[tag];
            if (!p) {
                p = Object.create(this.getNativePrototype(tag));
                for (var n, p$ = Object.getOwnPropertyNames(Polymer.Base), i = 0; i < p$.length && (n = p$[i]); i++) Polymer.BaseDescriptors[n] || (p[n] = Polymer.Base[n]);
                Object.defineProperties(p, Polymer.BaseDescriptors), this._nativePrototypes[tag] = p
            }
            return p
        },
        getNativePrototype: function(tag) {
            return Object.getPrototypeOf(document.createElement(tag))
        }
    }), Polymer.Base._addFeature({
        _prepConstructor: function() {
            this._factoryArgs = this["extends"] ? [this["extends"], this.is] : [this.is];
            var ctor = function() {
                return this._factory(arguments)
            };
            this.hasOwnProperty("extends") && (ctor["extends"] = this["extends"]), Object.defineProperty(this, "constructor", {
                value: ctor,
                writable: !0,
                configurable: !0
            }), ctor.prototype = this
        },
        _factory: function(args) {
            var elt = document.createElement.apply(document, this._factoryArgs);
            return this.factoryImpl && this.factoryImpl.apply(elt, args), elt
        }
    }), Polymer.nob = Object.create(null), Polymer.Base._addFeature({
        getPropertyInfo: function(property) {
            var info = this._getPropertyInfo(property, this.properties);
            if (!info)
                for (var i = 0; i < this.behaviors.length; i++)
                    if (info = this._getPropertyInfo(property, this.behaviors[i].properties)) return info;
            return info || Polymer.nob
        },
        _getPropertyInfo: function(property, properties) {
            var p = properties && properties[property];
            return "function" == typeof p && (p = properties[property] = {
                type: p
            }), p && (p.defined = !0), p
        },
        _prepPropertyInfo: function() {
            this._propertyInfo = {};
            for (var i = 0; i < this.behaviors.length; i++) this._addPropertyInfo(this._propertyInfo, this.behaviors[i].properties);
            this._addPropertyInfo(this._propertyInfo, this.properties), this._addPropertyInfo(this._propertyInfo, this._propertyEffects)
        },
        _addPropertyInfo: function(target, source) {
            if (source) {
                var t, s;
                for (var i in source) t = target[i], s = source[i], ("_" !== i[0] || s.readOnly) && (target[i] ? (t.type || (t.type = s.type), t.readOnly || (t.readOnly = s.readOnly)) : target[i] = {
                    type: "function" == typeof s ? s : s.type,
                    readOnly: s.readOnly,
                    attribute: Polymer.CaseMap.camelToDashCase(i)
                })
            }
        }
    }),
    function() {
        var propertiesDesc = {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: {}
        };
        Polymer.BaseDescriptors.properties = propertiesDesc, Object.defineProperty(Polymer.Base, "properties", propertiesDesc)
    }(), Polymer.CaseMap = {
        _caseMap: {},
        _rx: {
            dashToCamel: /-[a-z]/g,
            camelToDash: /([A-Z])/g
        },
        dashToCamelCase: function(dash) {
            return this._caseMap[dash] || (this._caseMap[dash] = dash.indexOf("-") < 0 ? dash : dash.replace(this._rx.dashToCamel, function(m) {
                return m[1].toUpperCase()
            }))
        },
        camelToDashCase: function(camel) {
            return this._caseMap[camel] || (this._caseMap[camel] = camel.replace(this._rx.camelToDash, "-$1").toLowerCase())
        }
    }, Polymer.Base._addFeature({
        _addHostAttributes: function(attributes) {
            this._aggregatedAttributes || (this._aggregatedAttributes = {}), attributes && this.mixin(this._aggregatedAttributes, attributes)
        },
        _marshalHostAttributes: function() {
            this._aggregatedAttributes && this._applyAttributes(this, this._aggregatedAttributes)
        },
        _applyAttributes: function(node, attr$) {
            for (var n in attr$)
                if (!this.hasAttribute(n) && "class" !== n) {
                    var v = attr$[n];
                    this.serializeValueToAttribute(v, n, this)
                }
        },
        _marshalAttributes: function() {
            this._takeAttributesToModel(this)
        },
        _takeAttributesToModel: function(model) {
            if (this.hasAttributes())
                for (var i in this._propertyInfo) {
                    var info = this._propertyInfo[i];
                    this.hasAttribute(info.attribute) && this._setAttributeToProperty(model, info.attribute, i, info)
                }
        },
        _setAttributeToProperty: function(model, attribute, property, info) {
            if (!this._serializing && (property = property || Polymer.CaseMap.dashToCamelCase(attribute), info = info || this._propertyInfo && this._propertyInfo[property], info && !info.readOnly)) {
                var v = this.getAttribute(attribute);
                model[property] = this.deserialize(v, info.type)
            }
        },
        _serializing: !1,
        reflectPropertyToAttribute: function(property, attribute, value) {
            this._serializing = !0, value = void 0 === value ? this[property] : value, this.serializeValueToAttribute(value, attribute || Polymer.CaseMap.camelToDashCase(property)), this._serializing = !1
        },
        serializeValueToAttribute: function(value, attribute, node) {
            var str = this.serialize(value);
            node = node || this, void 0 === str ? node.removeAttribute(attribute) : node.setAttribute(attribute, str)
        },
        deserialize: function(value, type) {
            switch (type) {
                case Number:
                    value = Number(value);
                    break;
                case Boolean:
                    value = null != value;
                    break;
                case Object:
                    try {
                        value = JSON.parse(value)
                    } catch (x) {}
                    break;
                case Array:
                    try {
                        value = JSON.parse(value)
                    } catch (x) {
                        value = null, console.warn("Polymer::Attributes: couldn`t decode Array as JSON")
                    }
                    break;
                case Date:
                    value = new Date(value);
                    break;
                case String:
            }
            return value
        },
        serialize: function(value) {
            switch (typeof value) {
                case "boolean":
                    return value ? "" : void 0;
                case "object":
                    if (value instanceof Date) return value.toString();
                    if (value) try {
                        return JSON.stringify(value)
                    } catch (x) {
                        return ""
                    }
                    default: return null != value ? value : void 0
            }
        }
    }), Polymer.version = "1.9.2", Polymer.Base._addFeature({
        _registerFeatures: function() {
            this._prepIs(), this._prepBehaviors(), this._prepConstructor(), this._prepPropertyInfo()
        },
        _prepBehavior: function(b) {
            this._addHostAttributes(b.hostAttributes)
        },
        _marshalBehavior: function() {},
        _initFeatures: function() {
            this._marshalHostAttributes(), this._marshalBehaviors()
        }
    }),
    function() {
        function resolveCss(cssText, ownerDocument) {
            return cssText.replace(CSS_URL_RX, function(m, pre, url, post) {
                return pre + "'" + resolve(url.replace(/["']/g, ""), ownerDocument) + "'" + post
            })
        }

        function resolveAttrs(element, ownerDocument) {
            for (var name in URL_ATTRS)
                for (var a, at, v, a$ = URL_ATTRS[name], i = 0, l = a$.length; l > i && (a = a$[i]); i++)("*" === name || element.localName === name) && (at = element.attributes[a], v = at && at.value, v && v.search(BINDING_RX) < 0 && (at.value = "style" === a ? resolveCss(v, ownerDocument) : resolve(v, ownerDocument)))
        }

        function resolve(url, ownerDocument) {
            if (url && ABS_URL.test(url)) return url;
            var resolver = getUrlResolver(ownerDocument);
            return resolver.href = url, resolver.href || url
        }

        function resolveUrl(url, baseUri) {
            return tempDoc || (tempDoc = document.implementation.createHTMLDocument("temp"), tempDocBase = tempDoc.createElement("base"), tempDoc.head.appendChild(tempDocBase)), tempDocBase.href = baseUri, resolve(url, tempDoc)
        }

        function getUrlResolver(ownerDocument) {
            return ownerDocument.body.__urlResolver || (ownerDocument.body.__urlResolver = ownerDocument.createElement("a"))
        }

        function pathFromUrl(url) {
            return url.substring(0, url.lastIndexOf("/") + 1)
        }
        var tempDoc, tempDocBase, CSS_URL_RX = /(url\()([^)]*)(\))/g,
            URL_ATTRS = {
                "*": ["href", "src", "style", "url"],
                form: ["action"]
            },
            ABS_URL = /(^\/)|(^#)|(^[\w-\d]*:)/,
            BINDING_RX = /\{\{|\[\[/;
        Polymer.ResolveUrl = {
            resolveCss: resolveCss,
            resolveAttrs: resolveAttrs,
            resolveUrl: resolveUrl,
            pathFromUrl: pathFromUrl
        }, Polymer.rootPath = Polymer.Settings.rootPath || pathFromUrl(document.baseURI || window.location.href)
    }(), Polymer.Base._addFeature({
        _prepTemplate: function() {
            var module;
            if (void 0 === this._template && (module = Polymer.DomModule["import"](this.is), this._template = module && module.querySelector("template")), module) {
                var assetPath = module.getAttribute("assetpath") || "",
                    importURL = Polymer.ResolveUrl.resolveUrl(assetPath, module.ownerDocument.baseURI);
                this._importPath = Polymer.ResolveUrl.pathFromUrl(importURL)
            } else this._importPath = "";
            this._template && this._template.hasAttribute("is") && this._warn(this._logf("_prepTemplate", "top-level Polymer template must not be a type-extension, found", this._template, "Move inside simple <template>.")), this._template && !this._template.content && window.HTMLTemplateElement && HTMLTemplateElement.decorate && HTMLTemplateElement.decorate(this._template)
        },
        _stampTemplate: function() {
            this._template && (this.root = this.instanceTemplate(this._template))
        },
        instanceTemplate: function(template) {
            var dom = document.importNode(template._content || template.content, !0);
            return dom
        }
    }),
    function() {
        var baseAttachedCallback = Polymer.Base.attachedCallback,
            baseDetachedCallback = Polymer.Base.detachedCallback;
        Polymer.Base._addFeature({
            _hostStack: [],
            ready: function() {},
            _registerHost: function(host) {
                this.dataHost = host = host || Polymer.Base._hostStack[Polymer.Base._hostStack.length - 1], host && host._clients && host._clients.push(this), this._clients = null, this._clientsReadied = !1
            },
            _beginHosting: function() {
                Polymer.Base._hostStack.push(this), this._clients || (this._clients = [])
            },
            _endHosting: function() {
                Polymer.Base._hostStack.pop()
            },
            _tryReady: function() {
                this._readied = !1, this._canReady() && this._ready()
            },
            _canReady: function() {
                return !this.dataHost || this.dataHost._clientsReadied
            },
            _ready: function() {
                this._beforeClientsReady(), this._template && (this._setupRoot(), this._readyClients()), this._clientsReadied = !0, this._clients = null, this._afterClientsReady(), this._readySelf()
            },
            _readyClients: function() {
                this._beginDistribute();
                var c$ = this._clients;
                if (c$)
                    for (var c, i = 0, l = c$.length; l > i && (c = c$[i]); i++) c._ready();
                this._finishDistribute()
            },
            _readySelf: function() {
                for (var b, i = 0; i < this.behaviors.length; i++) b = this.behaviors[i], b.ready && b.ready.call(this);
                this.ready && this.ready(), this._readied = !0, this._attachedPending && (this._attachedPending = !1, this.attachedCallback())
            },
            _beforeClientsReady: function() {},
            _afterClientsReady: function() {},
            _beforeAttached: function() {},
            attachedCallback: function() {
                this._readied ? (this._beforeAttached(), baseAttachedCallback.call(this)) : this._attachedPending = !0
            },
            detachedCallback: function() {
                this._readied ? baseDetachedCallback.call(this) : this._attachedPending = !1
            }
        })
    }(), Polymer.ArraySplice = function() {
        function newSplice(index, removed, addedCount) {
            return {
                index: index,
                removed: removed,
                addedCount: addedCount
            }
        }

        function ArraySplice() {}
        var EDIT_LEAVE = 0,
            EDIT_UPDATE = 1,
            EDIT_ADD = 2,
            EDIT_DELETE = 3;
        return ArraySplice.prototype = {
            calcEditDistances: function(current, currentStart, currentEnd, old, oldStart, oldEnd) {
                for (var rowCount = oldEnd - oldStart + 1, columnCount = currentEnd - currentStart + 1, distances = new Array(rowCount), i = 0; rowCount > i; i++) distances[i] = new Array(columnCount), distances[i][0] = i;
                for (var j = 0; columnCount > j; j++) distances[0][j] = j;
                for (i = 1; rowCount > i; i++)
                    for (j = 1; columnCount > j; j++)
                        if (this.equals(current[currentStart + j - 1], old[oldStart + i - 1])) distances[i][j] = distances[i - 1][j - 1];
                        else {
                            var north = distances[i - 1][j] + 1,
                                west = distances[i][j - 1] + 1;
                            distances[i][j] = west > north ? north : west
                        }
                return distances
            },
            spliceOperationsFromEditDistances: function(distances) {
                for (var i = distances.length - 1, j = distances[0].length - 1, current = distances[i][j], edits = []; i > 0 || j > 0;)
                    if (0 != i)
                        if (0 != j) {
                            var min, northWest = distances[i - 1][j - 1],
                                west = distances[i - 1][j],
                                north = distances[i][j - 1];
                            min = north > west ? northWest > west ? west : northWest : northWest > north ? north : northWest, min == northWest ? (northWest == current ? edits.push(EDIT_LEAVE) : (edits.push(EDIT_UPDATE), current = northWest), i--, j--) : min == west ? (edits.push(EDIT_DELETE), i--, current = west) : (edits.push(EDIT_ADD), j--, current = north)
                        } else edits.push(EDIT_DELETE), i--;
                else edits.push(EDIT_ADD), j--;
                return edits.reverse(), edits
            },
            calcSplices: function(current, currentStart, currentEnd, old, oldStart, oldEnd) {
                var prefixCount = 0,
                    suffixCount = 0,
                    minLength = Math.min(currentEnd - currentStart, oldEnd - oldStart);
                if (0 == currentStart && 0 == oldStart && (prefixCount = this.sharedPrefix(current, old, minLength)), currentEnd == current.length && oldEnd == old.length && (suffixCount = this.sharedSuffix(current, old, minLength - prefixCount)), currentStart += prefixCount, oldStart += prefixCount, currentEnd -= suffixCount, oldEnd -= suffixCount, currentEnd - currentStart == 0 && oldEnd - oldStart == 0) return [];
                if (currentStart == currentEnd) {
                    for (var splice = newSplice(currentStart, [], 0); oldEnd > oldStart;) splice.removed.push(old[oldStart++]);
                    return [splice]
                }
                if (oldStart == oldEnd) return [newSplice(currentStart, [], currentEnd - currentStart)];
                var ops = this.spliceOperationsFromEditDistances(this.calcEditDistances(current, currentStart, currentEnd, old, oldStart, oldEnd));
                splice = void 0;
                for (var splices = [], index = currentStart, oldIndex = oldStart, i = 0; i < ops.length; i++) switch (ops[i]) {
                    case EDIT_LEAVE:
                        splice && (splices.push(splice), splice = void 0), index++, oldIndex++;
                        break;
                    case EDIT_UPDATE:
                        splice || (splice = newSplice(index, [], 0)), splice.addedCount++, index++, splice.removed.push(old[oldIndex]), oldIndex++;
                        break;
                    case EDIT_ADD:
                        splice || (splice = newSplice(index, [], 0)), splice.addedCount++, index++;
                        break;
                    case EDIT_DELETE:
                        splice || (splice = newSplice(index, [], 0)), splice.removed.push(old[oldIndex]), oldIndex++
                }
                return splice && splices.push(splice), splices
            },
            sharedPrefix: function(current, old, searchLength) {
                for (var i = 0; searchLength > i; i++)
                    if (!this.equals(current[i], old[i])) return i;
                return searchLength
            },
            sharedSuffix: function(current, old, searchLength) {
                for (var index1 = current.length, index2 = old.length, count = 0; searchLength > count && this.equals(current[--index1], old[--index2]);) count++;
                return count
            },
            calculateSplices: function(current, previous) {
                return this.calcSplices(current, 0, current.length, previous, 0, previous.length)
            },
            equals: function(currentValue, previousValue) {
                return currentValue === previousValue
            }
        }, new ArraySplice
    }(), Polymer.domInnerHTML = function() {
        function escapeReplace(c) {
            switch (c) {
                case "&":
                    return "&amp;";
                case "<":
                    return "&lt;";
                case ">":
                    return "&gt;";
                case '"':
                    return "&quot;";
                case " ":
                    return "&nbsp;"
            }
        }

        function escapeAttr(s) {
            return s.replace(escapeAttrRegExp, escapeReplace)
        }

        function escapeData(s) {
            return s.replace(escapeDataRegExp, escapeReplace)
        }

        function makeSet(arr) {
            for (var set = {}, i = 0; i < arr.length; i++) set[arr[i]] = !0;
            return set
        }

        function getOuterHTML(node, parentNode, composed) {
            switch (node.nodeType) {
                case Node.ELEMENT_NODE:
                    for (var attr, tagName = node.localName, s = "<" + tagName, attrs = node.attributes, i = 0; attr = attrs[i]; i++) s += " " + attr.name + '="' + escapeAttr(attr.value) + '"';
                    return s += ">", voidElements[tagName] ? s : s + getInnerHTML(node, composed) + "</" + tagName + ">";
                case Node.TEXT_NODE:
                    var data = node.data;
                    return parentNode && plaintextParents[parentNode.localName] ? data : escapeData(data);
                case Node.COMMENT_NODE:
                    return "<!--" + node.data + "-->";
                default:
                    throw console.error(node), new Error("not implemented")
            }
        }

        function getInnerHTML(node, composed) {
            node instanceof HTMLTemplateElement && (node = node.content);
            for (var child, s = "", c$ = Polymer.dom(node).childNodes, i = 0, l = c$.length; l > i && (child = c$[i]); i++) s += getOuterHTML(child, node, composed);
            return s
        }
        var escapeAttrRegExp = /[&\u00A0"]/g,
            escapeDataRegExp = /[&\u00A0<>]/g,
            voidElements = makeSet(["area", "base", "br", "col", "command", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr"]),
            plaintextParents = makeSet(["style", "script", "xmp", "iframe", "noembed", "noframes", "plaintext", "noscript"]);
        return {
            getInnerHTML: getInnerHTML
        }
    }(),
    function() {
        "use strict";
        var nativeInsertBefore = Element.prototype.insertBefore,
            nativeAppendChild = Element.prototype.appendChild,
            nativeRemoveChild = Element.prototype.removeChild;
        Polymer.TreeApi = {
            arrayCopyChildNodes: function(parent) {
                for (var copy = [], i = 0, n = parent.firstChild; n; n = n.nextSibling) copy[i++] = n;
                return copy
            },
            arrayCopyChildren: function(parent) {
                for (var copy = [], i = 0, n = parent.firstElementChild; n; n = n.nextElementSibling) copy[i++] = n;
                return copy
            },
            arrayCopy: function(a$) {
                for (var l = a$.length, copy = new Array(l), i = 0; l > i; i++) copy[i] = a$[i];
                return copy
            }
        }, Polymer.TreeApi.Logical = {
            hasParentNode: function(node) {
                return Boolean(node.__dom && node.__dom.parentNode)
            },
            hasChildNodes: function(node) {
                return Boolean(node.__dom && void 0 !== node.__dom.childNodes)
            },
            getChildNodes: function(node) {
                return this.hasChildNodes(node) ? this._getChildNodes(node) : node.childNodes
            },
            _getChildNodes: function(node) {
                if (!node.__dom.childNodes) {
                    node.__dom.childNodes = [];
                    for (var n = node.__dom.firstChild; n; n = n.__dom.nextSibling) node.__dom.childNodes.push(n)
                }
                return node.__dom.childNodes
            },
            getParentNode: function(node) {
                return node.__dom && void 0 !== node.__dom.parentNode ? node.__dom.parentNode : node.parentNode
            },
            getFirstChild: function(node) {
                return node.__dom && void 0 !== node.__dom.firstChild ? node.__dom.firstChild : node.firstChild
            },
            getLastChild: function(node) {
                return node.__dom && void 0 !== node.__dom.lastChild ? node.__dom.lastChild : node.lastChild
            },
            getNextSibling: function(node) {
                return node.__dom && void 0 !== node.__dom.nextSibling ? node.__dom.nextSibling : node.nextSibling
            },
            getPreviousSibling: function(node) {
                return node.__dom && void 0 !== node.__dom.previousSibling ? node.__dom.previousSibling : node.previousSibling
            },
            getFirstElementChild: function(node) {
                return node.__dom && void 0 !== node.__dom.firstChild ? this._getFirstElementChild(node) : node.firstElementChild
            },
            _getFirstElementChild: function(node) {
                for (var n = node.__dom.firstChild; n && n.nodeType !== Node.ELEMENT_NODE;) n = n.__dom.nextSibling;
                return n
            },
            getLastElementChild: function(node) {
                return node.__dom && void 0 !== node.__dom.lastChild ? this._getLastElementChild(node) : node.lastElementChild
            },
            _getLastElementChild: function(node) {
                for (var n = node.__dom.lastChild; n && n.nodeType !== Node.ELEMENT_NODE;) n = n.__dom.previousSibling;
                return n
            },
            getNextElementSibling: function(node) {
                return node.__dom && void 0 !== node.__dom.nextSibling ? this._getNextElementSibling(node) : node.nextElementSibling
            },
            _getNextElementSibling: function(node) {
                for (var n = node.__dom.nextSibling; n && n.nodeType !== Node.ELEMENT_NODE;) n = n.__dom.nextSibling;
                return n
            },
            getPreviousElementSibling: function(node) {
                return node.__dom && void 0 !== node.__dom.previousSibling ? this._getPreviousElementSibling(node) : node.previousElementSibling
            },
            _getPreviousElementSibling: function(node) {
                for (var n = node.__dom.previousSibling; n && n.nodeType !== Node.ELEMENT_NODE;) n = n.__dom.previousSibling;
                return n
            },
            saveChildNodes: function(node) {
                if (!this.hasChildNodes(node)) {
                    node.__dom = node.__dom || {}, node.__dom.firstChild = node.firstChild, node.__dom.lastChild = node.lastChild, node.__dom.childNodes = [];
                    for (var n = node.firstChild; n; n = n.nextSibling) n.__dom = n.__dom || {}, n.__dom.parentNode = node, node.__dom.childNodes.push(n), n.__dom.nextSibling = n.nextSibling, n.__dom.previousSibling = n.previousSibling
                }
            },
            recordInsertBefore: function(node, container, ref_node) {
                if (container.__dom.childNodes = null, node.nodeType === Node.DOCUMENT_FRAGMENT_NODE)
                    for (var n = node.firstChild; n; n = n.nextSibling) this._linkNode(n, container, ref_node);
                else this._linkNode(node, container, ref_node)
            },
            _linkNode: function(node, container, ref_node) {
                node.__dom = node.__dom || {}, container.__dom = container.__dom || {}, ref_node && (ref_node.__dom = ref_node.__dom || {}), node.__dom.previousSibling = ref_node ? ref_node.__dom.previousSibling : container.__dom.lastChild, node.__dom.previousSibling && (node.__dom.previousSibling.__dom.nextSibling = node), node.__dom.nextSibling = ref_node || null, node.__dom.nextSibling && (node.__dom.nextSibling.__dom.previousSibling = node), node.__dom.parentNode = container, ref_node ? ref_node === container.__dom.firstChild && (container.__dom.firstChild = node) : (container.__dom.lastChild = node, container.__dom.firstChild || (container.__dom.firstChild = node)), container.__dom.childNodes = null
            },
            recordRemoveChild: function(node, container) {
                node.__dom = node.__dom || {}, container.__dom = container.__dom || {}, node === container.__dom.firstChild && (container.__dom.firstChild = node.__dom.nextSibling), node === container.__dom.lastChild && (container.__dom.lastChild = node.__dom.previousSibling);
                var p = node.__dom.previousSibling,
                    n = node.__dom.nextSibling;
                p && (p.__dom.nextSibling = n), n && (n.__dom.previousSibling = p), node.__dom.parentNode = node.__dom.previousSibling = node.__dom.nextSibling = void 0, container.__dom.childNodes = null
            }
        }, Polymer.TreeApi.Composed = {
            getChildNodes: function(node) {
                return Polymer.TreeApi.arrayCopyChildNodes(node)
            },
            getParentNode: function(node) {
                return node.parentNode
            },
            clearChildNodes: function(node) {
                node.textContent = ""
            },
            insertBefore: function(parentNode, newChild, refChild) {
                return nativeInsertBefore.call(parentNode, newChild, refChild || null)
            },
            appendChild: function(parentNode, newChild) {
                return nativeAppendChild.call(parentNode, newChild)
            },
            removeChild: function(parentNode, node) {
                return nativeRemoveChild.call(parentNode, node)
            }
        }
    }(), Polymer.DomApi = function() {
        "use strict";
        var Settings = Polymer.Settings,
            TreeApi = Polymer.TreeApi,
            DomApi = function(node) {
                this.node = needsToWrap ? DomApi.wrap(node) : node
            },
            needsToWrap = Settings.hasShadow && !Settings.nativeShadow;
        DomApi.wrap = window.wrap ? window.wrap : function(node) {
            return node
        }, DomApi.prototype = {
            flush: function() {
                Polymer.dom.flush()
            },
            deepContains: function(node) {
                if (this.node.contains(node)) return !0;
                for (var n = node, doc = node.ownerDocument; n && n !== doc && n !== this.node;) n = Polymer.dom(n).parentNode || n.host;
                return n === this.node
            },
            queryDistributedElements: function(selector) {
                for (var c, c$ = this.getEffectiveChildNodes(), list = [], i = 0, l = c$.length; l > i && (c = c$[i]); i++) c.nodeType === Node.ELEMENT_NODE && DomApi.matchesSelector.call(c, selector) && list.push(c);

                return list
            },
            getEffectiveChildNodes: function() {
                for (var c, list = [], c$ = this.childNodes, i = 0, l = c$.length; l > i && (c = c$[i]); i++)
                    if (c.localName === CONTENT)
                        for (var d$ = dom(c).getDistributedNodes(), j = 0; j < d$.length; j++) list.push(d$[j]);
                    else list.push(c);
                return list
            },
            observeNodes: function(callback) {
                return callback ? (this.observer || (this.observer = this.node.localName === CONTENT ? new DomApi.DistributedNodesObserver(this) : new DomApi.EffectiveNodesObserver(this)), this.observer.addListener(callback)) : void 0
            },
            unobserveNodes: function(handle) {
                this.observer && this.observer.removeListener(handle)
            },
            notifyObserver: function() {
                this.observer && this.observer.notify()
            },
            _query: function(matcher, node, halter) {
                node = node || this.node;
                var list = [];
                return this._queryElements(TreeApi.Logical.getChildNodes(node), matcher, halter, list), list
            },
            _queryElements: function(elements, matcher, halter, list) {
                for (var c, i = 0, l = elements.length; l > i && (c = elements[i]); i++)
                    if (c.nodeType === Node.ELEMENT_NODE && this._queryElement(c, matcher, halter, list)) return !0
            },
            _queryElement: function(node, matcher, halter, list) {
                var result = matcher(node);
                return result && list.push(node), halter && halter(result) ? result : void this._queryElements(TreeApi.Logical.getChildNodes(node), matcher, halter, list)
            }
        };
        var CONTENT = DomApi.CONTENT = "content",
            dom = DomApi.factory = function(node) {
                return node = node || document, node.__domApi || (node.__domApi = new DomApi.ctor(node)), node.__domApi
            };
        DomApi.hasApi = function(node) {
            return Boolean(node.__domApi)
        }, DomApi.ctor = DomApi, Polymer.dom = function(obj, patch) {
            return obj instanceof Event ? Polymer.EventApi.factory(obj) : DomApi.factory(obj, patch)
        };
        var p = Element.prototype;
        return DomApi.matchesSelector = p.matches || p.matchesSelector || p.mozMatchesSelector || p.msMatchesSelector || p.oMatchesSelector || p.webkitMatchesSelector, DomApi
    }(),
    function() {
        "use strict";
        var Settings = Polymer.Settings,
            DomApi = Polymer.DomApi,
            dom = DomApi.factory,
            TreeApi = Polymer.TreeApi,
            getInnerHTML = Polymer.domInnerHTML.getInnerHTML,
            CONTENT = DomApi.CONTENT;
        if (!Settings.useShadow) {
            var nativeCloneNode = Element.prototype.cloneNode,
                nativeImportNode = Document.prototype.importNode;
            Polymer.Base.mixin(DomApi.prototype, {
                _lazyDistribute: function(host) {
                    host.shadyRoot && host.shadyRoot._distributionClean && (host.shadyRoot._distributionClean = !1, Polymer.dom.addDebouncer(host.debounce("_distribute", host._distributeContent)))
                },
                appendChild: function(node) {
                    return this.insertBefore(node)
                },
                insertBefore: function(node, ref_node) {
                    if (ref_node && TreeApi.Logical.getParentNode(ref_node) !== this.node) throw Error("The ref_node to be inserted before is not a child of this node");
                    if (node.nodeType !== Node.DOCUMENT_FRAGMENT_NODE) {
                        var parent = TreeApi.Logical.getParentNode(node);
                        parent ? (DomApi.hasApi(parent) && dom(parent).notifyObserver(), this._removeNode(node)) : this._removeOwnerShadyRoot(node)
                    }
                    if (!this._addNode(node, ref_node)) {
                        ref_node && (ref_node = ref_node.localName === CONTENT ? this._firstComposedNode(ref_node) : ref_node);
                        var container = this.node._isShadyRoot ? this.node.host : this.node;
                        ref_node ? TreeApi.Composed.insertBefore(container, node, ref_node) : TreeApi.Composed.appendChild(container, node)
                    }
                    return this.notifyObserver(), node
                },
                _addNode: function(node, ref_node) {
                    var root = this.getOwnerRoot();
                    if (root) {
                        var ipAdded = this._maybeAddInsertionPoint(node, this.node);
                        root._invalidInsertionPoints || (root._invalidInsertionPoints = ipAdded), this._addNodeToHost(root.host, node)
                    }
                    TreeApi.Logical.hasChildNodes(this.node) && TreeApi.Logical.recordInsertBefore(node, this.node, ref_node);
                    var handled = this._maybeDistribute(node) || this.node.shadyRoot;
                    if (handled)
                        if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE)
                            for (; node.firstChild;) TreeApi.Composed.removeChild(node, node.firstChild);
                        else {
                            var parent = TreeApi.Composed.getParentNode(node);
                            parent && TreeApi.Composed.removeChild(parent, node)
                        }
                    return handled
                },
                removeChild: function(node) {
                    if (TreeApi.Logical.getParentNode(node) !== this.node) throw Error("The node to be removed is not a child of this node: " + node);
                    if (!this._removeNode(node)) {
                        var container = this.node._isShadyRoot ? this.node.host : this.node,
                            parent = TreeApi.Composed.getParentNode(node);
                        container === parent && TreeApi.Composed.removeChild(container, node)
                    }
                    return this.notifyObserver(), node
                },
                _removeNode: function(node) {
                    var distributed, logicalParent = TreeApi.Logical.hasParentNode(node) && TreeApi.Logical.getParentNode(node),
                        root = this._ownerShadyRootForNode(node);
                    return logicalParent && (distributed = dom(node)._maybeDistributeParent(), TreeApi.Logical.recordRemoveChild(node, logicalParent), root && this._removeDistributedChildren(root, node) && (root._invalidInsertionPoints = !0, this._lazyDistribute(root.host))), this._removeOwnerShadyRoot(node), root && this._removeNodeFromHost(root.host, node), distributed
                },
                replaceChild: function(node, ref_node) {
                    return this.insertBefore(node, ref_node), this.removeChild(ref_node), node
                },
                _hasCachedOwnerRoot: function(node) {
                    return Boolean(void 0 !== node._ownerShadyRoot)
                },
                getOwnerRoot: function() {
                    return this._ownerShadyRootForNode(this.node)
                },
                _ownerShadyRootForNode: function(node) {
                    if (node) {
                        var root = node._ownerShadyRoot;
                        if (void 0 === root) {
                            if (node._isShadyRoot) root = node;
                            else {
                                var parent = TreeApi.Logical.getParentNode(node);
                                root = parent ? parent._isShadyRoot ? parent : this._ownerShadyRootForNode(parent) : null
                            }(root || document.documentElement.contains(node)) && (node._ownerShadyRoot = root)
                        }
                        return root
                    }
                },
                _maybeDistribute: function(node) {
                    var fragContent = node.nodeType === Node.DOCUMENT_FRAGMENT_NODE && !node.__noContent && dom(node).querySelector(CONTENT),
                        wrappedContent = fragContent && TreeApi.Logical.getParentNode(fragContent).nodeType !== Node.DOCUMENT_FRAGMENT_NODE,
                        hasContent = fragContent || node.localName === CONTENT;
                    if (hasContent) {
                        var root = this.getOwnerRoot();
                        root && this._lazyDistribute(root.host)
                    }
                    var needsDist = this._nodeNeedsDistribution(this.node);
                    return needsDist && this._lazyDistribute(this.node), needsDist || hasContent && !wrappedContent
                },
                _maybeAddInsertionPoint: function(node, parent) {
                    var added;
                    if (node.nodeType !== Node.DOCUMENT_FRAGMENT_NODE || node.__noContent) node.localName === CONTENT && (TreeApi.Logical.saveChildNodes(parent), TreeApi.Logical.saveChildNodes(node), added = !0);
                    else
                        for (var n, np, na, c$ = dom(node).querySelectorAll(CONTENT), i = 0; i < c$.length && (n = c$[i]); i++) np = TreeApi.Logical.getParentNode(n), np === node && (np = parent), na = this._maybeAddInsertionPoint(n, np), added = added || na;
                    return added
                },
                _updateInsertionPoints: function(host) {
                    for (var c, i$ = host.shadyRoot._insertionPoints = dom(host.shadyRoot).querySelectorAll(CONTENT), i = 0; i < i$.length; i++) c = i$[i], TreeApi.Logical.saveChildNodes(c), TreeApi.Logical.saveChildNodes(TreeApi.Logical.getParentNode(c))
                },
                _nodeNeedsDistribution: function(node) {
                    return node && node.shadyRoot && DomApi.hasInsertionPoint(node.shadyRoot)
                },
                _addNodeToHost: function(host, node) {
                    host._elementAdd && host._elementAdd(node)
                },
                _removeNodeFromHost: function(host, node) {
                    host._elementRemove && host._elementRemove(node)
                },
                _removeDistributedChildren: function(root, container) {
                    for (var hostNeedsDist, ip$ = root._insertionPoints, i = 0; i < ip$.length; i++) {
                        var content = ip$[i];
                        if (this._contains(container, content))
                            for (var dc$ = dom(content).getDistributedNodes(), j = 0; j < dc$.length; j++) {
                                hostNeedsDist = !0;
                                var node = dc$[j],
                                    parent = TreeApi.Composed.getParentNode(node);
                                parent && TreeApi.Composed.removeChild(parent, node)
                            }
                    }
                    return hostNeedsDist
                },
                _contains: function(container, node) {
                    for (; node;) {
                        if (node == container) return !0;
                        node = TreeApi.Logical.getParentNode(node)
                    }
                },
                _removeOwnerShadyRoot: function(node) {
                    if (this._hasCachedOwnerRoot(node))
                        for (var n, c$ = TreeApi.Logical.getChildNodes(node), i = 0, l = c$.length; l > i && (n = c$[i]); i++) this._removeOwnerShadyRoot(n);
                    node._ownerShadyRoot = void 0
                },
                _firstComposedNode: function(content) {
                    for (var n, p$, n$ = dom(content).getDistributedNodes(), i = 0, l = n$.length; l > i && (n = n$[i]); i++)
                        if (p$ = dom(n).getDestinationInsertionPoints(), p$[p$.length - 1] === content) return n
                },
                querySelector: function(selector) {
                    var result = this._query(function(n) {
                        return DomApi.matchesSelector.call(n, selector)
                    }, this.node, function(n) {
                        return Boolean(n)
                    })[0];
                    return result || null
                },
                querySelectorAll: function(selector) {
                    return this._query(function(n) {
                        return DomApi.matchesSelector.call(n, selector)
                    }, this.node)
                },
                getDestinationInsertionPoints: function() {
                    return this.node._destinationInsertionPoints || []
                },
                getDistributedNodes: function() {
                    return this.node._distributedNodes || []
                },
                _clear: function() {
                    for (; this.childNodes.length;) this.removeChild(this.childNodes[0])
                },
                setAttribute: function(name, value) {
                    this.node.setAttribute(name, value), this._maybeDistributeParent()
                },
                removeAttribute: function(name) {
                    this.node.removeAttribute(name), this._maybeDistributeParent()
                },
                _maybeDistributeParent: function() {
                    return this._nodeNeedsDistribution(this.parentNode) ? (this._lazyDistribute(this.parentNode), !0) : void 0
                },
                cloneNode: function(deep) {
                    var n = nativeCloneNode.call(this.node, !1);
                    if (deep)
                        for (var nc, c$ = this.childNodes, d = dom(n), i = 0; i < c$.length; i++) nc = dom(c$[i]).cloneNode(!0), d.appendChild(nc);
                    return n
                },
                importNode: function(externalNode, deep) {
                    var doc = this.node instanceof Document ? this.node : this.node.ownerDocument,
                        n = nativeImportNode.call(doc, externalNode, !1);
                    if (deep)
                        for (var nc, c$ = TreeApi.Logical.getChildNodes(externalNode), d = dom(n), i = 0; i < c$.length; i++) nc = dom(doc).importNode(c$[i], !0), d.appendChild(nc);
                    return n
                },
                _getComposedInnerHTML: function() {
                    return getInnerHTML(this.node, !0)
                }
            }), Object.defineProperties(DomApi.prototype, {
                activeElement: {
                    get: function() {
                        var active = document.activeElement;
                        if (!active) return null;
                        var isShadyRoot = !!this.node._isShadyRoot;
                        if (this.node !== document) {
                            if (!isShadyRoot) return null;
                            if (this.node.host === active || !this.node.host.contains(active)) return null
                        }
                        for (var activeRoot = dom(active).getOwnerRoot(); activeRoot && activeRoot !== this.node;) active = activeRoot.host, activeRoot = dom(active).getOwnerRoot();
                        return this.node === document ? activeRoot ? null : active : activeRoot === this.node ? active : null
                    },
                    configurable: !0
                },
                childNodes: {
                    get: function() {
                        var c$ = TreeApi.Logical.getChildNodes(this.node);
                        return Array.isArray(c$) ? c$ : TreeApi.arrayCopyChildNodes(this.node)
                    },
                    configurable: !0
                },
                children: {
                    get: function() {
                        return TreeApi.Logical.hasChildNodes(this.node) ? Array.prototype.filter.call(this.childNodes, function(n) {
                            return n.nodeType === Node.ELEMENT_NODE
                        }) : TreeApi.arrayCopyChildren(this.node)
                    },
                    configurable: !0
                },
                parentNode: {
                    get: function() {
                        return TreeApi.Logical.getParentNode(this.node)
                    },
                    configurable: !0
                },
                firstChild: {
                    get: function() {
                        return TreeApi.Logical.getFirstChild(this.node)
                    },
                    configurable: !0
                },
                lastChild: {
                    get: function() {
                        return TreeApi.Logical.getLastChild(this.node)
                    },
                    configurable: !0
                },
                nextSibling: {
                    get: function() {
                        return TreeApi.Logical.getNextSibling(this.node)
                    },
                    configurable: !0
                },
                previousSibling: {
                    get: function() {
                        return TreeApi.Logical.getPreviousSibling(this.node)
                    },
                    configurable: !0
                },
                firstElementChild: {
                    get: function() {
                        return TreeApi.Logical.getFirstElementChild(this.node)
                    },
                    configurable: !0
                },
                lastElementChild: {
                    get: function() {
                        return TreeApi.Logical.getLastElementChild(this.node)
                    },
                    configurable: !0
                },
                nextElementSibling: {
                    get: function() {
                        return TreeApi.Logical.getNextElementSibling(this.node)
                    },
                    configurable: !0
                },
                previousElementSibling: {
                    get: function() {
                        return TreeApi.Logical.getPreviousElementSibling(this.node)
                    },
                    configurable: !0
                },
                textContent: {
                    get: function() {
                        var nt = this.node.nodeType;
                        if (nt === Node.TEXT_NODE || nt === Node.COMMENT_NODE) return this.node.textContent;
                        for (var c, tc = [], i = 0, cn = this.childNodes; c = cn[i]; i++) c.nodeType !== Node.COMMENT_NODE && tc.push(c.textContent);
                        return tc.join("")
                    },
                    set: function(text) {
                        var nt = this.node.nodeType;
                        nt === Node.TEXT_NODE || nt === Node.COMMENT_NODE ? this.node.textContent = text : (this._clear(), text && this.appendChild(document.createTextNode(text)))
                    },
                    configurable: !0
                },
                innerHTML: {
                    get: function() {
                        var nt = this.node.nodeType;
                        return nt === Node.TEXT_NODE || nt === Node.COMMENT_NODE ? null : getInnerHTML(this.node)
                    },
                    set: function(text) {
                        var nt = this.node.nodeType;
                        if (nt !== Node.TEXT_NODE || nt !== Node.COMMENT_NODE) {
                            this._clear();
                            var d = document.createElement("div");
                            d.innerHTML = text;
                            for (var c$ = TreeApi.arrayCopyChildNodes(d), i = 0; i < c$.length; i++) this.appendChild(c$[i])
                        }
                    },
                    configurable: !0
                }
            }), DomApi.hasInsertionPoint = function(root) {
                return Boolean(root && root._insertionPoints.length)
            }
        }
    }(),
    function() {
        "use strict";
        var Settings = Polymer.Settings,
            TreeApi = Polymer.TreeApi,
            DomApi = Polymer.DomApi;
        if (Settings.useShadow) {
            Polymer.Base.mixin(DomApi.prototype, {
                querySelectorAll: function(selector) {
                    return TreeApi.arrayCopy(this.node.querySelectorAll(selector))
                },
                getOwnerRoot: function() {
                    for (var n = this.node; n;) {
                        if (n.nodeType === Node.DOCUMENT_FRAGMENT_NODE && n.host) return n;
                        n = n.parentNode
                    }
                },
                importNode: function(externalNode, deep) {
                    var doc = this.node instanceof Document ? this.node : this.node.ownerDocument;
                    return doc.importNode(externalNode, deep)
                },
                getDestinationInsertionPoints: function() {
                    var n$ = this.node.getDestinationInsertionPoints && this.node.getDestinationInsertionPoints();
                    return n$ ? TreeApi.arrayCopy(n$) : []
                },
                getDistributedNodes: function() {
                    var n$ = this.node.getDistributedNodes && this.node.getDistributedNodes();
                    return n$ ? TreeApi.arrayCopy(n$) : []
                }
            }), Object.defineProperties(DomApi.prototype, {
                activeElement: {
                    get: function() {
                        var node = DomApi.wrap(this.node),
                            activeElement = node.activeElement;
                        return node.contains(activeElement) ? activeElement : null
                    },
                    configurable: !0
                },
                childNodes: {
                    get: function() {
                        return TreeApi.arrayCopyChildNodes(this.node)
                    },
                    configurable: !0
                },
                children: {
                    get: function() {
                        return TreeApi.arrayCopyChildren(this.node)
                    },
                    configurable: !0
                },
                textContent: {
                    get: function() {
                        return this.node.textContent
                    },
                    set: function(value) {
                        return this.node.textContent = value
                    },
                    configurable: !0
                },
                innerHTML: {
                    get: function() {
                        return this.node.innerHTML
                    },
                    set: function(value) {
                        return this.node.innerHTML = value
                    },
                    configurable: !0
                }
            });
            var forwardMethods = function(m$) {
                    for (var i = 0; i < m$.length; i++) forwardMethod(m$[i])
                },
                forwardMethod = function(method) {
                    DomApi.prototype[method] = function() {
                        return this.node[method].apply(this.node, arguments)
                    }
                };
            forwardMethods(["cloneNode", "appendChild", "insertBefore", "removeChild", "replaceChild", "setAttribute", "removeAttribute", "querySelector"]);
            var forwardProperties = function(f$) {
                    for (var i = 0; i < f$.length; i++) forwardProperty(f$[i])
                },
                forwardProperty = function(name) {
                    Object.defineProperty(DomApi.prototype, name, {
                        get: function() {
                            return this.node[name]
                        },
                        configurable: !0
                    })
                };
            forwardProperties(["parentNode", "firstChild", "lastChild", "nextSibling", "previousSibling", "firstElementChild", "lastElementChild", "nextElementSibling", "previousElementSibling"])
        }
    }(), Polymer.Base.mixin(Polymer.dom, {
        _flushGuard: 0,
        _FLUSH_MAX: 100,
        _needsTakeRecords: !Polymer.Settings.useNativeCustomElements,
        _debouncers: [],
        _staticFlushList: [],
        _finishDebouncer: null,
        flush: function() {
            for (this._flushGuard = 0, this._prepareFlush(); this._debouncers.length && this._flushGuard < this._FLUSH_MAX;) {
                for (; this._debouncers.length;) this._debouncers.shift().complete();
                this._finishDebouncer && this._finishDebouncer.complete(), this._prepareFlush(), this._flushGuard++
            }
            this._flushGuard >= this._FLUSH_MAX && console.warn("Polymer.dom.flush aborted. Flush may not be complete.")
        },
        _prepareFlush: function() {
            this._needsTakeRecords && CustomElements.takeRecords();
            for (var i = 0; i < this._staticFlushList.length; i++) this._staticFlushList[i]()
        },
        addStaticFlush: function(fn) {
            this._staticFlushList.push(fn)
        },
        removeStaticFlush: function(fn) {
            var i = this._staticFlushList.indexOf(fn);
            i >= 0 && this._staticFlushList.splice(i, 1)
        },
        addDebouncer: function(debouncer) {
            this._debouncers.push(debouncer), this._finishDebouncer = Polymer.Debounce(this._finishDebouncer, this._finishFlush)
        },
        _finishFlush: function() {
            Polymer.dom._debouncers = []
        }
    }), Polymer.EventApi = function() {
        "use strict";
        var DomApi = Polymer.DomApi.ctor,
            Settings = Polymer.Settings;
        DomApi.Event = function(event) {
            this.event = event
        }, DomApi.Event.prototype = Settings.useShadow ? {
            get rootTarget() {
                return this.event.path[0]
            },
            get localTarget() {
                return this.event.target
            },
            get path() {
                var path = this.event.path;
                return Array.isArray(path) || (path = Array.prototype.slice.call(path)), path
            }
        } : {
            get rootTarget() {
                return this.event.target
            },
            get localTarget() {
                for (var current = this.event.currentTarget, currentRoot = current && Polymer.dom(current).getOwnerRoot(), p$ = this.path, i = 0; i < p$.length; i++)
                    if (Polymer.dom(p$[i]).getOwnerRoot() === currentRoot) return p$[i]
            },
            get path() {
                if (!this.event._path) {
                    for (var path = [], current = this.rootTarget; current;) {
                        path.push(current);
                        var insertionPoints = Polymer.dom(current).getDestinationInsertionPoints();
                        if (insertionPoints.length) {
                            for (var i = 0; i < insertionPoints.length - 1; i++) path.push(insertionPoints[i]);
                            current = insertionPoints[insertionPoints.length - 1]
                        } else current = Polymer.dom(current).parentNode || current.host
                    }
                    path.push(window), this.event._path = path
                }
                return this.event._path
            }
        };
        var factory = function(event) {
            return event.__eventApi || (event.__eventApi = new DomApi.Event(event)), event.__eventApi
        };
        return {
            factory: factory
        }
    }(),
    function() {
        "use strict";
        var DomApi = Polymer.DomApi.ctor,
            useShadow = Polymer.Settings.useShadow;
        Object.defineProperty(DomApi.prototype, "classList", {
            get: function() {
                return this._classList || (this._classList = new DomApi.ClassList(this)), this._classList
            },
            configurable: !0
        }), DomApi.ClassList = function(host) {
            this.domApi = host, this.node = host.node
        }, DomApi.ClassList.prototype = {
            add: function() {
                this.node.classList.add.apply(this.node.classList, arguments), this._distributeParent()
            },
            remove: function() {
                this.node.classList.remove.apply(this.node.classList, arguments), this._distributeParent()
            },
            toggle: function() {
                this.node.classList.toggle.apply(this.node.classList, arguments), this._distributeParent()
            },
            _distributeParent: function() {
                useShadow || this.domApi._maybeDistributeParent()
            },
            contains: function() {
                return this.node.classList.contains.apply(this.node.classList, arguments)
            }
        }
    }(),
    function() {
        "use strict";
        var DomApi = Polymer.DomApi.ctor,
            Settings = Polymer.Settings;
        if (DomApi.EffectiveNodesObserver = function(domApi) {
                this.domApi = domApi, this.node = this.domApi.node, this._listeners = []
            }, DomApi.EffectiveNodesObserver.prototype = {
                addListener: function(callback) {
                    this._isSetup || (this._setup(), this._isSetup = !0);
                    var listener = {
                        fn: callback,
                        _nodes: []
                    };
                    return this._listeners.push(listener), this._scheduleNotify(), listener
                },
                removeListener: function(handle) {
                    var i = this._listeners.indexOf(handle);
                    i >= 0 && (this._listeners.splice(i, 1), handle._nodes = []), this._hasListeners() || (this._cleanup(), this._isSetup = !1)
                },
                _setup: function() {
                    this._observeContentElements(this.domApi.childNodes)
                },
                _cleanup: function() {
                    this._unobserveContentElements(this.domApi.childNodes)
                },
                _hasListeners: function() {
                    return Boolean(this._listeners.length)
                },
                _scheduleNotify: function() {
                    this._debouncer && this._debouncer.stop(), this._debouncer = Polymer.Debounce(this._debouncer, this._notify), this._debouncer.context = this, Polymer.dom.addDebouncer(this._debouncer)
                },
                notify: function() {
                    this._hasListeners() && this._scheduleNotify()
                },
                _notify: function() {
                    this._beforeCallListeners(), this._callListeners()
                },
                _beforeCallListeners: function() {
                    this._updateContentElements()
                },
                _updateContentElements: function() {
                    this._observeContentElements(this.domApi.childNodes)
                },
                _observeContentElements: function(elements) {
                    for (var n, i = 0; i < elements.length && (n = elements[i]); i++) this._isContent(n) && (n.__observeNodesMap = n.__observeNodesMap || new WeakMap, n.__observeNodesMap.has(this) || n.__observeNodesMap.set(this, this._observeContent(n)))
                },
                _observeContent: function(content) {
                    var self = this,
                        h = Polymer.dom(content).observeNodes(function() {
                            self._scheduleNotify()
                        });
                    return h._avoidChangeCalculation = !0, h
                },
                _unobserveContentElements: function(elements) {
                    for (var n, h, i = 0; i < elements.length && (n = elements[i]); i++) this._isContent(n) && (h = n.__observeNodesMap.get(this), h && (Polymer.dom(n).unobserveNodes(h), n.__observeNodesMap["delete"](this)))
                },
                _isContent: function(node) {
                    return "content" === node.localName
                },
                _callListeners: function() {
                    for (var o, o$ = this._listeners, nodes = this._getEffectiveNodes(), i = 0; i < o$.length && (o = o$[i]); i++) {
                        var info = this._generateListenerInfo(o, nodes);
                        (info || o._alwaysNotify) && this._callListener(o, info)
                    }
                },
                _getEffectiveNodes: function() {
                    return this.domApi.getEffectiveChildNodes()
                },
                _generateListenerInfo: function(listener, newNodes) {
                    if (listener._avoidChangeCalculation) return !0;
                    for (var s, oldNodes = listener._nodes, info = {
                            target: this.node,
                            addedNodes: [],
                            removedNodes: []
                        }, splices = Polymer.ArraySplice.calculateSplices(newNodes, oldNodes), i = 0; i < splices.length && (s = splices[i]); i++)
                        for (var n, j = 0; j < s.removed.length && (n = s.removed[j]); j++) info.removedNodes.push(n);
                    for (i = 0, s; i < splices.length && (s = splices[i]); i++)
                        for (j = s.index; j < s.index + s.addedCount; j++) info.addedNodes.push(newNodes[j]);
                    return listener._nodes = newNodes, info.addedNodes.length || info.removedNodes.length ? info : void 0
                },
                _callListener: function(listener, info) {
                    return listener.fn.call(this.node, info)
                },
                enableShadowAttributeTracking: function() {}
            }, Settings.useShadow) {
            var baseSetup = DomApi.EffectiveNodesObserver.prototype._setup,
                baseCleanup = DomApi.EffectiveNodesObserver.prototype._cleanup;
            Polymer.Base.mixin(DomApi.EffectiveNodesObserver.prototype, {
                _setup: function() {
                    if (!this._observer) {
                        var self = this;
                        this._mutationHandler = function(mxns) {
                            mxns && mxns.length && self._scheduleNotify()
                        }, this._observer = new MutationObserver(this._mutationHandler), this._boundFlush = function() {
                            self._flush()
                        }, Polymer.dom.addStaticFlush(this._boundFlush), this._observer.observe(this.node, {
                            childList: !0
                        })
                    }
                    baseSetup.call(this)
                },
                _cleanup: function() {
                    this._observer.disconnect(), this._observer = null, this._mutationHandler = null, Polymer.dom.removeStaticFlush(this._boundFlush), baseCleanup.call(this)
                },
                _flush: function() {
                    this._observer && this._mutationHandler(this._observer.takeRecords())
                },
                enableShadowAttributeTracking: function() {
                    if (this._observer) {
                        this._makeContentListenersAlwaysNotify(), this._observer.disconnect(), this._observer.observe(this.node, {
                            childList: !0,
                            attributes: !0,
                            subtree: !0
                        });
                        var root = this.domApi.getOwnerRoot(),
                            host = root && root.host;
                        host && Polymer.dom(host).observer && Polymer.dom(host).observer.enableShadowAttributeTracking()
                    }
                },
                _makeContentListenersAlwaysNotify: function() {
                    for (var h, i = 0; i < this._listeners.length; i++) h = this._listeners[i], h._alwaysNotify = h._isContentListener
                }
            })
        }
    }(),
    function() {
        "use strict";
        var DomApi = Polymer.DomApi.ctor,
            Settings = Polymer.Settings;
        DomApi.DistributedNodesObserver = function(domApi) {
            DomApi.EffectiveNodesObserver.call(this, domApi)
        }, DomApi.DistributedNodesObserver.prototype = Object.create(DomApi.EffectiveNodesObserver.prototype), Polymer.Base.mixin(DomApi.DistributedNodesObserver.prototype, {
            _setup: function() {},
            _cleanup: function() {},
            _beforeCallListeners: function() {},
            _getEffectiveNodes: function() {
                return this.domApi.getDistributedNodes()
            }
        }), Settings.useShadow && Polymer.Base.mixin(DomApi.DistributedNodesObserver.prototype, {
            _setup: function() {
                if (!this._observer) {
                    var root = this.domApi.getOwnerRoot(),
                        host = root && root.host;
                    if (host) {
                        var self = this;
                        this._observer = Polymer.dom(host).observeNodes(function() {
                            self._scheduleNotify()
                        }), this._observer._isContentListener = !0, this._hasAttrSelect() && Polymer.dom(host).observer.enableShadowAttributeTracking()
                    }
                }
            },
            _hasAttrSelect: function() {
                var select = this.node.getAttribute("select");
                return select && select.match(/[[.]+/)
            },
            _cleanup: function() {
                var root = this.domApi.getOwnerRoot(),
                    host = root && root.host;
                host && Polymer.dom(host).unobserveNodes(this._observer), this._observer = null
            }
        })
    }(),
    function() {
        function distributeNodeInto(child, insertionPoint) {
            insertionPoint._distributedNodes.push(child);
            var points = child._destinationInsertionPoints;
            points ? points.push(insertionPoint) : child._destinationInsertionPoints = [insertionPoint]
        }

        function clearDistributedDestinationInsertionPoints(content) {
            var e$ = content._distributedNodes;
            if (e$)
                for (var i = 0; i < e$.length; i++) {
                    var d = e$[i]._destinationInsertionPoints;
                    d && d.splice(d.indexOf(content) + 1, d.length)
                }
        }

        function maybeRedistributeParent(content, host) {
            var parent = TreeApi.Logical.getParentNode(content);
            parent && parent.shadyRoot && DomApi.hasInsertionPoint(parent.shadyRoot) && parent.shadyRoot._distributionClean && (parent.shadyRoot._distributionClean = !1, host.shadyRoot._dirtyRoots.push(parent))
        }

        function isFinalDestination(insertionPoint, node) {
            var points = node._destinationInsertionPoints;
            return points && points[points.length - 1] === insertionPoint
        }

        function isInsertionPoint(node) {
            return "content" == node.localName
        }

        function getTopDistributingHost(host) {
            for (; host && hostNeedsRedistribution(host);) host = host.domHost;
            return host
        }

        function hostNeedsRedistribution(host) {
            for (var c, c$ = TreeApi.Logical.getChildNodes(host), i = 0; i < c$.length; i++)
                if (c = c$[i], c.localName && "content" === c.localName) return host.domHost
        }

        function notifyContentObservers(root) {
            for (var c, i = 0; i < root._insertionPoints.length; i++) c = root._insertionPoints[i], DomApi.hasApi(c) && Polymer.dom(c).notifyObserver()
        }

        function notifyInitialDistribution(host) {
            DomApi.hasApi(host) && Polymer.dom(host).notifyObserver()
        }

        function upgradeLogicalChildren(children) {
            if (needsUpgrade && children)
                for (var i = 0; i < children.length; i++) CustomElements.upgrade(children[i])
        }
        var DomApi = Polymer.DomApi,
            TreeApi = Polymer.TreeApi;
        Polymer.Base._addFeature({
            _prepShady: function() {
                this._useContent = this._useContent || Boolean(this._template)
            },
            _setupShady: function() {
                this.shadyRoot = null, this.__domApi || (this.__domApi = null), this.__dom || (this.__dom = null), this._ownerShadyRoot || (this._ownerShadyRoot = void 0)
            },
            _poolContent: function() {
                this._useContent && TreeApi.Logical.saveChildNodes(this)
            },
            _setupRoot: function() {
                this._useContent && (this._createLocalRoot(), this.dataHost || upgradeLogicalChildren(TreeApi.Logical.getChildNodes(this)))
            },
            _createLocalRoot: function() {
                this.shadyRoot = this.root, this.shadyRoot._distributionClean = !1, this.shadyRoot._hasDistributed = !1, this.shadyRoot._isShadyRoot = !0, this.shadyRoot._dirtyRoots = [];
                var i$ = this.shadyRoot._insertionPoints = !this._notes || this._notes._hasContent ? this.shadyRoot.querySelectorAll("content") : [];
                TreeApi.Logical.saveChildNodes(this.shadyRoot);
                for (var c, i = 0; i < i$.length; i++) c = i$[i], TreeApi.Logical.saveChildNodes(c), TreeApi.Logical.saveChildNodes(c.parentNode);
                this.shadyRoot.host = this
            },
            distributeContent: function(updateInsertionPoints) {
                if (this.shadyRoot) {
                    this.shadyRoot._invalidInsertionPoints = this.shadyRoot._invalidInsertionPoints || updateInsertionPoints;
                    var host = getTopDistributingHost(this);
                    Polymer.dom(this)._lazyDistribute(host)
                }
            },
            _distributeContent: function() {
                this._useContent && !this.shadyRoot._distributionClean && (this.shadyRoot._invalidInsertionPoints && (Polymer.dom(this)._updateInsertionPoints(this), this.shadyRoot._invalidInsertionPoints = !1), this._beginDistribute(), this._distributeDirtyRoots(), this._finishDistribute())
            },
            _beginDistribute: function() {
                this._useContent && DomApi.hasInsertionPoint(this.shadyRoot) && (this._resetDistribution(), this._distributePool(this.shadyRoot, this._collectPool()))
            },
            _distributeDirtyRoots: function() {
                for (var c, c$ = this.shadyRoot._dirtyRoots, i = 0, l = c$.length; l > i && (c = c$[i]); i++) c._distributeContent();
                this.shadyRoot._dirtyRoots = []
            },
            _finishDistribute: function() {
                if (this._useContent) {
                    if (this.shadyRoot._distributionClean = !0, DomApi.hasInsertionPoint(this.shadyRoot)) this._composeTree(), notifyContentObservers(this.shadyRoot);
                    else if (this.shadyRoot._hasDistributed) {
                        var children = this._composeNode(this);
                        this._updateChildNodes(this, children)
                    } else TreeApi.Composed.clearChildNodes(this), this.appendChild(this.shadyRoot);
                    this.shadyRoot._hasDistributed || notifyInitialDistribution(this), this.shadyRoot._hasDistributed = !0
                }
            },
            elementMatches: function(selector, node) {
                return node = node || this, DomApi.matchesSelector.call(node, selector)
            },
            _resetDistribution: function() {
                for (var children = TreeApi.Logical.getChildNodes(this), i = 0; i < children.length; i++) {
                    var child = children[i];
                    child._destinationInsertionPoints && (child._destinationInsertionPoints = void 0), isInsertionPoint(child) && clearDistributedDestinationInsertionPoints(child)
                }
                for (var root = this.shadyRoot, p$ = root._insertionPoints, j = 0; j < p$.length; j++) p$[j]._distributedNodes = []
            },
            _collectPool: function() {
                for (var pool = [], children = TreeApi.Logical.getChildNodes(this), i = 0; i < children.length; i++) {
                    var child = children[i];
                    isInsertionPoint(child) ? pool.push.apply(pool, child._distributedNodes) : pool.push(child)
                }
                return pool
            },
            _distributePool: function(node, pool) {
                for (var p, p$ = node._insertionPoints, i = 0, l = p$.length; l > i && (p = p$[i]); i++) this._distributeInsertionPoint(p, pool), maybeRedistributeParent(p, this)
            },
            _distributeInsertionPoint: function(content, pool) {
                for (var node, anyDistributed = !1, i = 0, l = pool.length; l > i; i++) node = pool[i], node && this._matchesContentSelect(node, content) && (distributeNodeInto(node, content), pool[i] = void 0, anyDistributed = !0);
                if (!anyDistributed)
                    for (var children = TreeApi.Logical.getChildNodes(content), j = 0; j < children.length; j++) distributeNodeInto(children[j], content)
            },
            _composeTree: function() {
                this._updateChildNodes(this, this._composeNode(this));
                for (var p, parent, p$ = this.shadyRoot._insertionPoints, i = 0, l = p$.length; l > i && (p = p$[i]); i++) parent = TreeApi.Logical.getParentNode(p), parent._useContent || parent === this || parent === this.shadyRoot || this._updateChildNodes(parent, this._composeNode(parent))
            },
            _composeNode: function(node) {
                for (var children = [], c$ = TreeApi.Logical.getChildNodes(node.shadyRoot || node), i = 0; i < c$.length; i++) {
                    var child = c$[i];
                    if (isInsertionPoint(child))
                        for (var distributedNodes = child._distributedNodes, j = 0; j < distributedNodes.length; j++) {
                            var distributedNode = distributedNodes[j];
                            isFinalDestination(child, distributedNode) && children.push(distributedNode)
                        } else children.push(child)
                }
                return children
            },
            _updateChildNodes: function(container, children) {
                for (var s, composed = TreeApi.Composed.getChildNodes(container), splices = Polymer.ArraySplice.calculateSplices(children, composed), i = 0, d = 0; i < splices.length && (s = splices[i]); i++) {
                    for (var n, j = 0; j < s.removed.length && (n = s.removed[j]); j++) TreeApi.Composed.getParentNode(n) === container && TreeApi.Composed.removeChild(container, n), composed.splice(s.index + d, 1);
                    d -= s.addedCount
                }
                for (var s, next, i = 0; i < splices.length && (s = splices[i]); i++)
                    for (next = composed[s.index], j = s.index, n; j < s.index + s.addedCount; j++) n = children[j], TreeApi.Composed.insertBefore(container, n, next), composed.splice(j, 0, n)
            },
            _matchesContentSelect: function(node, contentElement) {
                var select = contentElement.getAttribute("select");
                if (!select) return !0;
                if (select = select.trim(), !select) return !0;
                if (!(node instanceof Element)) return !1;
                var validSelectors = /^(:not\()?[*.#[a-zA-Z_|]/;
                return validSelectors.test(select) ? this.elementMatches(select, node) : !1
            },
            _elementAdd: function() {},
            _elementRemove: function() {}
        });
        var domHostDesc = {
            get: function() {
                var root = Polymer.dom(this).getOwnerRoot();
                return root && root.host
            },
            configurable: !0
        };
        Object.defineProperty(Polymer.Base, "domHost", domHostDesc), Polymer.BaseDescriptors.domHost = domHostDesc;
        var needsUpgrade = window.CustomElements && !CustomElements.useNative
    }(), Polymer.Settings.useShadow && Polymer.Base._addFeature({
        _poolContent: function() {},
        _beginDistribute: function() {},
        distributeContent: function() {},
        _distributeContent: function() {},
        _finishDistribute: function() {},
        _createLocalRoot: function() {
            this.createShadowRoot(), this.shadowRoot.appendChild(this.root), this.root = this.shadowRoot
        }
    }), Polymer.Async = {
        _currVal: 0,
        _lastVal: 0,
        _callbacks: [],
        _twiddleContent: 0,
        _twiddle: document.createTextNode(""),
        run: function(callback, waitTime) {
            return waitTime > 0 ? ~setTimeout(callback, waitTime) : (this._twiddle.textContent = this._twiddleContent++, this._callbacks.push(callback), this._currVal++)
        },
        cancel: function(handle) {
            if (0 > handle) clearTimeout(~handle);
            else {
                var idx = handle - this._lastVal;
                if (idx >= 0) {
                    if (!this._callbacks[idx]) throw "invalid async handle: " + handle;
                    this._callbacks[idx] = null
                }
            }
        },
        _atEndOfMicrotask: function() {
            for (var len = this._callbacks.length, i = 0; len > i; i++) {
                var cb = this._callbacks[i];
                if (cb) try {
                    cb()
                } catch (e) {
                    throw i++, this._callbacks.splice(0, i), this._lastVal += i, this._twiddle.textContent = this._twiddleContent++, e
                }
            }
            this._callbacks.splice(0, len), this._lastVal += len
        }
    }, new window.MutationObserver(function() {
        Polymer.Async._atEndOfMicrotask()
    }).observe(Polymer.Async._twiddle, {
        characterData: !0
    }), Polymer.Debounce = function() {
        function debounce(debouncer, callback, wait) {
            return debouncer ? debouncer.stop() : debouncer = new Debouncer(this), debouncer.go(callback, wait), debouncer
        }
        var Async = Polymer.Async,
            Debouncer = function(context) {
                this.context = context;
                var self = this;
                this.boundComplete = function() {
                    self.complete()
                }
            };
        return Debouncer.prototype = {
            go: function(callback, wait) {
                var h;
                this.finish = function() {
                    Async.cancel(h)
                }, h = Async.run(this.boundComplete, wait), this.callback = callback
            },
            stop: function() {
                this.finish && (this.finish(), this.finish = null, this.callback = null)
            },
            complete: function() {
                if (this.finish) {
                    var callback = this.callback;
                    this.stop(),
                        callback.call(this.context)
                }
            }
        }, debounce
    }(), Polymer.Base._addFeature({
        _setupDebouncers: function() {
            this._debouncers = {}
        },
        debounce: function(jobName, callback, wait) {
            return this._debouncers[jobName] = Polymer.Debounce.call(this, this._debouncers[jobName], callback, wait)
        },
        isDebouncerActive: function(jobName) {
            var debouncer = this._debouncers[jobName];
            return !(!debouncer || !debouncer.finish)
        },
        flushDebouncer: function(jobName) {
            var debouncer = this._debouncers[jobName];
            debouncer && debouncer.complete()
        },
        cancelDebouncer: function(jobName) {
            var debouncer = this._debouncers[jobName];
            debouncer && debouncer.stop()
        }
    }), Polymer.DomModule = document.createElement("dom-module"), Polymer.Base._addFeature({
        _registerFeatures: function() {
            this._prepIs(), this._prepBehaviors(), this._prepConstructor(), this._prepTemplate(), this._prepShady(), this._prepPropertyInfo()
        },
        _prepBehavior: function(b) {
            this._addHostAttributes(b.hostAttributes)
        },
        _initFeatures: function() {
            this._registerHost(), this._template && (this._poolContent(), this._beginHosting(), this._stampTemplate(), this._endHosting()), this._marshalHostAttributes(), this._setupDebouncers(), this._marshalBehaviors(), this._tryReady()
        },
        _marshalBehavior: function() {}
    }),
    function() {
        Polymer.nar = [];
        var disableUpgradeEnabled = Polymer.Settings.disableUpgradeEnabled;
        Polymer.Annotations = {
            parseAnnotations: function(template, stripWhiteSpace) {
                var list = [],
                    content = template._content || template.content;
                return this._parseNodeAnnotations(content, list, stripWhiteSpace || template.hasAttribute("strip-whitespace")), list
            },
            _parseNodeAnnotations: function(node, list, stripWhiteSpace) {
                return node.nodeType === Node.TEXT_NODE ? this._parseTextNodeAnnotation(node, list) : this._parseElementAnnotations(node, list, stripWhiteSpace)
            },
            _bindingRegex: function() {
                var IDENT = "(?:[a-zA-Z_$][\\w.:$\\-*]*)",
                    NUMBER = "(?:[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?)",
                    SQUOTE_STRING = "(?:'(?:[^'\\\\]|\\\\.)*')",
                    DQUOTE_STRING = '(?:"(?:[^"\\\\]|\\\\.)*")',
                    STRING = "(?:" + SQUOTE_STRING + "|" + DQUOTE_STRING + ")",
                    ARGUMENT = "(?:" + IDENT + "|" + NUMBER + "|" + STRING + "\\s*)",
                    ARGUMENTS = "(?:" + ARGUMENT + "(?:,\\s*" + ARGUMENT + ")*)",
                    ARGUMENT_LIST = "(?:\\(\\s*(?:" + ARGUMENTS + "?)\\)\\s*)",
                    BINDING = "(" + IDENT + "\\s*" + ARGUMENT_LIST + "?)",
                    OPEN_BRACKET = "(\\[\\[|{{)\\s*",
                    CLOSE_BRACKET = "(?:]]|}})",
                    NEGATE = "(?:(!)\\s*)?",
                    EXPRESSION = OPEN_BRACKET + NEGATE + BINDING + CLOSE_BRACKET;
                return new RegExp(EXPRESSION, "g")
            }(),
            _parseBindings: function(text) {
                for (var m, re = this._bindingRegex, parts = [], lastIndex = 0; null !== (m = re.exec(text));) {
                    m.index > lastIndex && parts.push({
                        literal: text.slice(lastIndex, m.index)
                    });
                    var customEvent, notifyEvent, colon, mode = m[1][0],
                        negate = Boolean(m[2]),
                        value = m[3].trim();
                    "{" == mode && (colon = value.indexOf("::")) > 0 && (notifyEvent = value.substring(colon + 2), value = value.substring(0, colon), customEvent = !0), parts.push({
                        compoundIndex: parts.length,
                        value: value,
                        mode: mode,
                        negate: negate,
                        event: notifyEvent,
                        customEvent: customEvent
                    }), lastIndex = re.lastIndex
                }
                if (lastIndex && lastIndex < text.length) {
                    var literal = text.substring(lastIndex);
                    literal && parts.push({
                        literal: literal
                    })
                }
                return parts.length ? parts : void 0
            },
            _literalFromParts: function(parts) {
                for (var s = "", i = 0; i < parts.length; i++) {
                    var literal = parts[i].literal;
                    s += literal || ""
                }
                return s
            },
            _parseTextNodeAnnotation: function(node, list) {
                var parts = this._parseBindings(node.textContent);
                if (parts) {
                    node.textContent = this._literalFromParts(parts) || " ";
                    var annote = {
                        bindings: [{
                            kind: "text",
                            name: "textContent",
                            parts: parts,
                            isCompound: 1 !== parts.length
                        }]
                    };
                    return list.push(annote), annote
                }
            },
            _parseElementAnnotations: function(element, list, stripWhiteSpace) {
                var annote = {
                    bindings: [],
                    events: []
                };
                return "content" === element.localName && (list._hasContent = !0), this._parseChildNodesAnnotations(element, annote, list, stripWhiteSpace), element.attributes && (this._parseNodeAttributeAnnotations(element, annote, list), this.prepElement && this.prepElement(element)), (annote.bindings.length || annote.events.length || annote.id) && list.push(annote), annote
            },
            _parseChildNodesAnnotations: function(root, annote, list, stripWhiteSpace) {
                if (root.firstChild)
                    for (var node = root.firstChild, i = 0; node;) {
                        var next = node.nextSibling;
                        if ("template" !== node.localName || node.hasAttribute("preserve-content") || this._parseTemplate(node, i, list, annote, stripWhiteSpace), "slot" == node.localName && (node = this._replaceSlotWithContent(node)), node.nodeType === Node.TEXT_NODE) {
                            for (var n = next; n && n.nodeType === Node.TEXT_NODE;) node.textContent += n.textContent, next = n.nextSibling, root.removeChild(n), n = next;
                            stripWhiteSpace && !node.textContent.trim() && (root.removeChild(node), i--)
                        }
                        if (node.parentNode) {
                            var childAnnotation = this._parseNodeAnnotations(node, list, stripWhiteSpace);
                            childAnnotation && (childAnnotation.parent = annote, childAnnotation.index = i)
                        }
                        node = next, i++
                    }
            },
            _replaceSlotWithContent: function(slot) {
                for (var content = slot.ownerDocument.createElement("content"); slot.firstChild;) content.appendChild(slot.firstChild);
                for (var attrs = slot.attributes, i = 0; i < attrs.length; i++) {
                    var attr = attrs[i];
                    content.setAttribute(attr.name, attr.value)
                }
                var name = slot.getAttribute("name");
                return name && content.setAttribute("select", "[slot='" + name + "']"), slot.parentNode.replaceChild(content, slot), content
            },
            _parseTemplate: function(node, index, list, parent, stripWhiteSpace) {
                var content = document.createDocumentFragment();
                content._notes = this.parseAnnotations(node, stripWhiteSpace), content.appendChild(node.content), list.push({
                    bindings: Polymer.nar,
                    events: Polymer.nar,
                    templateContent: content,
                    parent: parent,
                    index: index
                })
            },
            _parseNodeAttributeAnnotations: function(node, annotation) {
                for (var a, attrs = Array.prototype.slice.call(node.attributes), i = attrs.length - 1; a = attrs[i]; i--) {
                    var b, n = a.name,
                        v = a.value;
                    "on-" === n.slice(0, 3) ? (node.removeAttribute(n), annotation.events.push({
                        name: n.slice(3),
                        value: v
                    })) : (b = this._parseNodeAttributeAnnotation(node, n, v)) ? annotation.bindings.push(b) : "id" === n && (annotation.id = v)
                }
            },
            _parseNodeAttributeAnnotation: function(node, name, value) {
                var parts = this._parseBindings(value);
                if (parts) {
                    var origName = name,
                        kind = "property";
                    "$" == name[name.length - 1] && (name = name.slice(0, -1), kind = "attribute");
                    var literal = this._literalFromParts(parts);
                    literal && "attribute" == kind && node.setAttribute(name, literal), "input" === node.localName && "value" === origName && node.setAttribute(origName, ""), disableUpgradeEnabled && "disable-upgrade$" === origName && node.setAttribute(name, ""), node.removeAttribute(origName);
                    var propertyName = Polymer.CaseMap.dashToCamelCase(name);
                    return "property" === kind && (name = propertyName), {
                        kind: kind,
                        name: name,
                        propertyName: propertyName,
                        parts: parts,
                        literal: literal,
                        isCompound: 1 !== parts.length
                    }
                }
            },
            findAnnotatedNode: function(root, annote) {
                var parent = annote.parent && Polymer.Annotations.findAnnotatedNode(root, annote.parent);
                if (!parent) return root;
                for (var n = parent.firstChild, i = 0; n; n = n.nextSibling)
                    if (annote.index === i++) return n
            }
        }
    }(), Polymer.Path = {
        root: function(path) {
            var dotIndex = path.indexOf(".");
            return -1 === dotIndex ? path : path.slice(0, dotIndex)
        },
        isDeep: function(path) {
            return -1 !== path.indexOf(".")
        },
        isAncestor: function(base, path) {
            return 0 === base.indexOf(path + ".")
        },
        isDescendant: function(base, path) {
            return 0 === path.indexOf(base + ".")
        },
        translate: function(base, newBase, path) {
            return newBase + path.slice(base.length)
        },
        matches: function(base, wildcard, path) {
            return base === path || this.isAncestor(base, path) || Boolean(wildcard) && this.isDescendant(base, path)
        }
    }, Polymer.Base._addFeature({
        _prepAnnotations: function() {
            if (this._template) {
                var self = this;
                Polymer.Annotations.prepElement = function(element) {
                    self._prepElement(element)
                }, this._template._content && this._template._content._notes ? this._notes = this._template._content._notes : (this._notes = Polymer.Annotations.parseAnnotations(this._template), this._processAnnotations(this._notes)), Polymer.Annotations.prepElement = null
            } else this._notes = []
        },
        _processAnnotations: function(notes) {
            for (var i = 0; i < notes.length; i++) {
                for (var note = notes[i], j = 0; j < note.bindings.length; j++)
                    for (var b = note.bindings[j], k = 0; k < b.parts.length; k++) {
                        var p = b.parts[k];
                        if (!p.literal) {
                            var signature = this._parseMethod(p.value);
                            signature ? p.signature = signature : p.model = Polymer.Path.root(p.value)
                        }
                    }
                if (note.templateContent) {
                    this._processAnnotations(note.templateContent._notes);
                    var pp = note.templateContent._parentProps = this._discoverTemplateParentProps(note.templateContent._notes),
                        bindings = [];
                    for (var prop in pp) {
                        var name = "_parent_" + prop;
                        bindings.push({
                            index: note.index,
                            kind: "property",
                            name: name,
                            propertyName: name,
                            parts: [{
                                mode: "{",
                                model: prop,
                                value: prop
                            }]
                        })
                    }
                    note.bindings = note.bindings.concat(bindings)
                }
            }
        },
        _discoverTemplateParentProps: function(notes) {
            for (var n, pp = {}, i = 0; i < notes.length && (n = notes[i]); i++) {
                for (var b, j = 0, b$ = n.bindings; j < b$.length && (b = b$[j]); j++)
                    for (var p, k = 0, p$ = b.parts; k < p$.length && (p = p$[k]); k++)
                        if (p.signature) {
                            for (var args = p.signature.args, kk = 0; kk < args.length; kk++) {
                                var model = args[kk].model;
                                model && (pp[model] = !0)
                            }
                            p.signature.dynamicFn && (pp[p.signature.method] = !0)
                        } else p.model && (pp[p.model] = !0);
                if (n.templateContent) {
                    var tpp = n.templateContent._parentProps;
                    Polymer.Base.mixin(pp, tpp)
                }
            }
            return pp
        },
        _prepElement: function(element) {
            Polymer.ResolveUrl.resolveAttrs(element, this._template.ownerDocument)
        },
        _findAnnotatedNode: Polymer.Annotations.findAnnotatedNode,
        _marshalAnnotationReferences: function() {
            this._template && (this._marshalIdNodes(), this._marshalAnnotatedNodes(), this._marshalAnnotatedListeners())
        },
        _configureAnnotationReferences: function() {
            for (var notes = this._notes, nodes = this._nodes, i = 0; i < notes.length; i++) {
                var note = notes[i],
                    node = nodes[i];
                this._configureTemplateContent(note, node), this._configureCompoundBindings(note, node)
            }
        },
        _configureTemplateContent: function(note, node) {
            note.templateContent && (node._content = note.templateContent)
        },
        _configureCompoundBindings: function(note, node) {
            for (var bindings = note.bindings, i = 0; i < bindings.length; i++) {
                var binding = bindings[i];
                if (binding.isCompound) {
                    for (var storage = node.__compoundStorage__ || (node.__compoundStorage__ = {}), parts = binding.parts, literals = new Array(parts.length), j = 0; j < parts.length; j++) literals[j] = parts[j].literal;
                    var name = binding.name;
                    storage[name] = literals, binding.literal && "property" == binding.kind && (node._configValue ? node._configValue(name, binding.literal) : node[name] = binding.literal)
                }
            }
        },
        _marshalIdNodes: function() {
            this.$ = {};
            for (var a, i = 0, l = this._notes.length; l > i && (a = this._notes[i]); i++) a.id && (this.$[a.id] = this._findAnnotatedNode(this.root, a))
        },
        _marshalAnnotatedNodes: function() {
            if (this._notes && this._notes.length) {
                for (var r = new Array(this._notes.length), i = 0; i < this._notes.length; i++) r[i] = this._findAnnotatedNode(this.root, this._notes[i]);
                this._nodes = r
            }
        },
        _marshalAnnotatedListeners: function() {
            for (var a, i = 0, l = this._notes.length; l > i && (a = this._notes[i]); i++)
                if (a.events && a.events.length)
                    for (var e, node = this._findAnnotatedNode(this.root, a), j = 0, e$ = a.events; j < e$.length && (e = e$[j]); j++) this.listen(node, e.name, e.value)
        }
    }), Polymer.Base._addFeature({
        listeners: {},
        _listenListeners: function(listeners) {
            var node, name, eventName;
            for (eventName in listeners) eventName.indexOf(".") < 0 ? (node = this, name = eventName) : (name = eventName.split("."), node = this.$[name[0]], name = name[1]), this.listen(node, name, listeners[eventName])
        },
        listen: function(node, eventName, methodName) {
            var handler = this._recallEventHandler(this, eventName, node, methodName);
            handler || (handler = this._createEventHandler(node, eventName, methodName)), handler._listening || (this._listen(node, eventName, handler), handler._listening = !0)
        },
        _boundListenerKey: function(eventName, methodName) {
            return eventName + ":" + methodName
        },
        _recordEventHandler: function(host, eventName, target, methodName, handler) {
            var hbl = host.__boundListeners;
            hbl || (hbl = host.__boundListeners = new WeakMap);
            var bl = hbl.get(target);
            bl || (bl = {}, Polymer.Settings.isIE && target == window || hbl.set(target, bl));
            var key = this._boundListenerKey(eventName, methodName);
            bl[key] = handler
        },
        _recallEventHandler: function(host, eventName, target, methodName) {
            var hbl = host.__boundListeners;
            if (hbl) {
                var bl = hbl.get(target);
                if (bl) {
                    var key = this._boundListenerKey(eventName, methodName);
                    return bl[key]
                }
            }
        },
        _createEventHandler: function(node, eventName, methodName) {
            var host = this,
                handler = function(e) {
                    host[methodName] ? host[methodName](e, e.detail) : host._warn(host._logf("_createEventHandler", "listener method `" + methodName + "` not defined"))
                };
            return handler._listening = !1, this._recordEventHandler(host, eventName, node, methodName, handler), handler
        },
        unlisten: function(node, eventName, methodName) {
            var handler = this._recallEventHandler(this, eventName, node, methodName);
            handler && (this._unlisten(node, eventName, handler), handler._listening = !1)
        },
        _listen: function(node, eventName, handler) {
            node.addEventListener(eventName, handler)
        },
        _unlisten: function(node, eventName, handler) {
            node.removeEventListener(eventName, handler)
        }
    }),
    function() {
        "use strict";

        function setupTeardownMouseCanceller(setup) {
            for (var en, events = IS_TOUCH_ONLY ? ["click"] : MOUSE_EVENTS, i = 0; i < events.length; i++) en = events[i], setup ? document.addEventListener(en, mouseCanceller, !0) : document.removeEventListener(en, mouseCanceller, !0)
        }

        function ignoreMouse(ev) {
            POINTERSTATE.mouse.mouseIgnoreJob || setupTeardownMouseCanceller(!0);
            var unset = function() {
                setupTeardownMouseCanceller(), POINTERSTATE.mouse.target = null, POINTERSTATE.mouse.mouseIgnoreJob = null
            };
            POINTERSTATE.mouse.target = Polymer.dom(ev).rootTarget, POINTERSTATE.mouse.mouseIgnoreJob = Polymer.Debounce(POINTERSTATE.mouse.mouseIgnoreJob, unset, MOUSE_TIMEOUT)
        }

        function hasLeftMouseButton(ev) {
            var type = ev.type;
            if (-1 === MOUSE_EVENTS.indexOf(type)) return !1;
            if ("mousemove" === type) {
                var buttons = void 0 === ev.buttons ? 1 : ev.buttons;
                return ev instanceof window.MouseEvent && !MOUSE_HAS_BUTTONS && (buttons = MOUSE_WHICH_TO_BUTTONS[ev.which] || 0), Boolean(1 & buttons)
            }
            var button = void 0 === ev.button ? 0 : ev.button;
            return 0 === button
        }

        function isSyntheticClick(ev) {
            if ("click" === ev.type) {
                if (0 === ev.detail) return !0;
                var t = Gestures.findOriginalTarget(ev),
                    bcr = t.getBoundingClientRect(),
                    x = ev.pageX,
                    y = ev.pageY;
                return !(x >= bcr.left && x <= bcr.right && y >= bcr.top && y <= bcr.bottom)
            }
            return !1
        }

        function firstTouchAction(ev) {
            for (var n, path = Polymer.dom(ev).path, ta = "auto", i = 0; i < path.length; i++)
                if (n = path[i], n[TOUCH_ACTION]) {
                    ta = n[TOUCH_ACTION];
                    break
                }
            return ta
        }

        function trackDocument(stateObj, movefn, upfn) {
            stateObj.movefn = movefn, stateObj.upfn = upfn, document.addEventListener("mousemove", movefn), document.addEventListener("mouseup", upfn)
        }

        function untrackDocument(stateObj) {
            document.removeEventListener("mousemove", stateObj.movefn), document.removeEventListener("mouseup", stateObj.upfn), stateObj.movefn = null, stateObj.upfn = null
        }
        var wrap = Polymer.DomApi.wrap,
            HAS_NATIVE_TA = "string" == typeof document.head.style.touchAction,
            GESTURE_KEY = "__polymerGestures",
            HANDLED_OBJ = "__polymerGesturesHandled",
            TOUCH_ACTION = "__polymerGesturesTouchAction",
            TAP_DISTANCE = 25,
            TRACK_DISTANCE = 5,
            TRACK_LENGTH = 2,
            MOUSE_TIMEOUT = 2500,
            MOUSE_EVENTS = ["mousedown", "mousemove", "mouseup", "click"],
            MOUSE_WHICH_TO_BUTTONS = [0, 1, 4, 2],
            MOUSE_HAS_BUTTONS = function() {
                try {
                    return 1 === new MouseEvent("test", {
                        buttons: 1
                    }).buttons
                } catch (e) {
                    return !1
                }
            }(),
            SUPPORTS_PASSIVE = !1;
        ! function() {
            try {
                var opts = Object.defineProperty({}, "passive", {
                    get: function() {
                        SUPPORTS_PASSIVE = !0
                    }
                });
                window.addEventListener("test", null, opts), window.removeEventListener("test", null, opts)
            } catch (e) {}
        }();
        var IS_TOUCH_ONLY = navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/),
            mouseCanceller = function(mouseEvent) {
                var sc = mouseEvent.sourceCapabilities;
                if ((!sc || sc.firesTouchEvents) && (mouseEvent[HANDLED_OBJ] = {
                        skip: !0
                    }, "click" === mouseEvent.type)) {
                    for (var path = Polymer.dom(mouseEvent).path, i = 0; i < path.length; i++)
                        if (path[i] === POINTERSTATE.mouse.target) return;
                    mouseEvent.preventDefault(), mouseEvent.stopPropagation()
                }
            },
            POINTERSTATE = {
                mouse: {
                    target: null,
                    mouseIgnoreJob: null
                },
                touch: {
                    x: 0,
                    y: 0,
                    id: -1,
                    scrollDecided: !1
                }
            };
        document.addEventListener("touchend", ignoreMouse, SUPPORTS_PASSIVE ? {
            passive: !0
        } : !1);
        var Gestures = {
            gestures: {},
            recognizers: [],
            deepTargetFind: function(x, y) {
                for (var node = document.elementFromPoint(x, y), next = node; next && next.shadowRoot;) next = next.shadowRoot.elementFromPoint(x, y), next && (node = next);
                return node
            },
            findOriginalTarget: function(ev) {
                return ev.path ? ev.path[0] : ev.target
            },
            handleNative: function(ev) {
                var handled, type = ev.type,
                    node = wrap(ev.currentTarget),
                    gobj = node[GESTURE_KEY];
                if (gobj) {
                    var gs = gobj[type];
                    if (gs) {
                        if (!ev[HANDLED_OBJ] && (ev[HANDLED_OBJ] = {}, "touch" === type.slice(0, 5))) {
                            var t = ev.changedTouches[0];
                            if ("touchstart" === type && 1 === ev.touches.length && (POINTERSTATE.touch.id = t.identifier), POINTERSTATE.touch.id !== t.identifier) return;
                            HAS_NATIVE_TA || ("touchstart" === type || "touchmove" === type) && Gestures.handleTouchAction(ev)
                        }
                        if (handled = ev[HANDLED_OBJ], !handled.skip) {
                            for (var r, recognizers = Gestures.recognizers, i = 0; i < recognizers.length; i++) r = recognizers[i], gs[r.name] && !handled[r.name] && r.flow && r.flow.start.indexOf(ev.type) > -1 && r.reset && r.reset();
                            for (i = 0, r; i < recognizers.length; i++) r = recognizers[i], gs[r.name] && !handled[r.name] && (handled[r.name] = !0, r[type](ev))
                        }
                    }
                }
            },
            handleTouchAction: function(ev) {
                var t = ev.changedTouches[0],
                    type = ev.type;
                if ("touchstart" === type) POINTERSTATE.touch.x = t.clientX, POINTERSTATE.touch.y = t.clientY, POINTERSTATE.touch.scrollDecided = !1;
                else if ("touchmove" === type) {
                    if (POINTERSTATE.touch.scrollDecided) return;
                    POINTERSTATE.touch.scrollDecided = !0;
                    var ta = firstTouchAction(ev),
                        prevent = !1,
                        dx = Math.abs(POINTERSTATE.touch.x - t.clientX),
                        dy = Math.abs(POINTERSTATE.touch.y - t.clientY);
                    ev.cancelable && ("none" === ta ? prevent = !0 : "pan-x" === ta ? prevent = dy > dx : "pan-y" === ta && (prevent = dx > dy)), prevent ? ev.preventDefault() : Gestures.prevent("track")
                }
            },
            add: function(node, evType, handler) {
                node = wrap(node);
                var recognizer = this.gestures[evType],
                    deps = recognizer.deps,
                    name = recognizer.name,
                    gobj = node[GESTURE_KEY];
                gobj || (node[GESTURE_KEY] = gobj = {});
                for (var dep, gd, i = 0; i < deps.length; i++) dep = deps[i], IS_TOUCH_ONLY && MOUSE_EVENTS.indexOf(dep) > -1 && "click" !== dep || (gd = gobj[dep], gd || (gobj[dep] = gd = {
                    _count: 0
                }), 0 === gd._count && node.addEventListener(dep, this.handleNative), gd[name] = (gd[name] || 0) + 1, gd._count = (gd._count || 0) + 1);
                node.addEventListener(evType, handler), recognizer.touchAction && this.setTouchAction(node, recognizer.touchAction)
            },
            remove: function(node, evType, handler) {
                node = wrap(node);
                var recognizer = this.gestures[evType],
                    deps = recognizer.deps,
                    name = recognizer.name,
                    gobj = node[GESTURE_KEY];
                if (gobj)
                    for (var dep, gd, i = 0; i < deps.length; i++) dep = deps[i], gd = gobj[dep], gd && gd[name] && (gd[name] = (gd[name] || 1) - 1, gd._count = (gd._count || 1) - 1, 0 === gd._count && node.removeEventListener(dep, this.handleNative));
                node.removeEventListener(evType, handler)
            },
            register: function(recog) {
                this.recognizers.push(recog);
                for (var i = 0; i < recog.emits.length; i++) this.gestures[recog.emits[i]] = recog
            },
            findRecognizerByEvent: function(evName) {
                for (var r, i = 0; i < this.recognizers.length; i++) {
                    r = this.recognizers[i];
                    for (var n, j = 0; j < r.emits.length; j++)
                        if (n = r.emits[j], n === evName) return r
                }
                return null
            },
            setTouchAction: function(node, value) {
                HAS_NATIVE_TA && (node.style.touchAction = value), node[TOUCH_ACTION] = value
            },
            fire: function(target, type, detail) {
                var ev = Polymer.Base.fire(type, detail, {
                    node: target,
                    bubbles: !0,
                    cancelable: !0
                });
                if (ev.defaultPrevented) {
                    var preventer = detail.preventer || detail.sourceEvent;
                    preventer && preventer.preventDefault && preventer.preventDefault()
                }
            },
            prevent: function(evName) {
                var recognizer = this.findRecognizerByEvent(evName);
                recognizer.info && (recognizer.info.prevent = !0)
            },
            resetMouseCanceller: function() {
                POINTERSTATE.mouse.mouseIgnoreJob && POINTERSTATE.mouse.mouseIgnoreJob.complete()
            }
        };
        Gestures.register({
            name: "downup",
            deps: ["mousedown", "touchstart", "touchend"],
            flow: {
                start: ["mousedown", "touchstart"],
                end: ["mouseup", "touchend"]
            },
            emits: ["down", "up"],
            info: {
                movefn: null,
                upfn: null
            },
            reset: function() {
                untrackDocument(this.info)
            },
            mousedown: function(e) {
                if (hasLeftMouseButton(e)) {
                    var t = Gestures.findOriginalTarget(e),
                        self = this,
                        movefn = function(e) {
                            hasLeftMouseButton(e) || (self.fire("up", t, e), untrackDocument(self.info))
                        },
                        upfn = function(e) {
                            hasLeftMouseButton(e) && self.fire("up", t, e), untrackDocument(self.info)
                        };
                    trackDocument(this.info, movefn, upfn), this.fire("down", t, e)
                }
            },
            touchstart: function(e) {
                this.fire("down", Gestures.findOriginalTarget(e), e.changedTouches[0], e)
            },
            touchend: function(e) {
                this.fire("up", Gestures.findOriginalTarget(e), e.changedTouches[0], e)
            },
            fire: function(type, target, event, preventer) {
                Gestures.fire(target, type, {
                    x: event.clientX,
                    y: event.clientY,
                    sourceEvent: event,
                    preventer: preventer,
                    prevent: function(e) {
                        return Gestures.prevent(e)
                    }
                })
            }
        }), Gestures.register({
            name: "track",
            touchAction: "none",
            deps: ["mousedown", "touchstart", "touchmove", "touchend"],
            flow: {
                start: ["mousedown", "touchstart"],
                end: ["mouseup", "touchend"]
            },
            emits: ["track"],
            info: {
                x: 0,
                y: 0,
                state: "start",
                started: !1,
                moves: [],
                addMove: function(move) {
                    this.moves.length > TRACK_LENGTH && this.moves.shift(), this.moves.push(move)
                },
                movefn: null,
                upfn: null,
                prevent: !1
            },
            reset: function() {
                this.info.state = "start", this.info.started = !1, this.info.moves = [], this.info.x = 0, this.info.y = 0, this.info.prevent = !1, untrackDocument(this.info)
            },
            hasMovedEnough: function(x, y) {
                if (this.info.prevent) return !1;
                if (this.info.started) return !0;
                var dx = Math.abs(this.info.x - x),
                    dy = Math.abs(this.info.y - y);
                return dx >= TRACK_DISTANCE || dy >= TRACK_DISTANCE
            },
            mousedown: function(e) {
                if (hasLeftMouseButton(e)) {
                    var t = Gestures.findOriginalTarget(e),
                        self = this,
                        movefn = function(e) {
                            var x = e.clientX,
                                y = e.clientY;
                            self.hasMovedEnough(x, y) && (self.info.state = self.info.started ? "mouseup" === e.type ? "end" : "track" : "start", "start" === self.info.state && Gestures.prevent("tap"), self.info.addMove({
                                x: x,
                                y: y
                            }), hasLeftMouseButton(e) || (self.info.state = "end", untrackDocument(self.info)), self.fire(t, e), self.info.started = !0)
                        },
                        upfn = function(e) {
                            self.info.started && movefn(e), untrackDocument(self.info)
                        };
                    trackDocument(this.info, movefn, upfn), this.info.x = e.clientX, this.info.y = e.clientY
                }
            },
            touchstart: function(e) {
                var ct = e.changedTouches[0];
                this.info.x = ct.clientX, this.info.y = ct.clientY
            },
            touchmove: function(e) {
                var t = Gestures.findOriginalTarget(e),
                    ct = e.changedTouches[0],
                    x = ct.clientX,
                    y = ct.clientY;
                this.hasMovedEnough(x, y) && ("start" === this.info.state && Gestures.prevent("tap"), this.info.addMove({
                    x: x,
                    y: y
                }), this.fire(t, ct), this.info.state = "track", this.info.started = !0)
            },
            touchend: function(e) {
                var t = Gestures.findOriginalTarget(e),
                    ct = e.changedTouches[0];
                this.info.started && (this.info.state = "end", this.info.addMove({
                    x: ct.clientX,
                    y: ct.clientY
                }), this.fire(t, ct, e))
            },
            fire: function(target, touch, preventer) {
                var ddx, secondlast = this.info.moves[this.info.moves.length - 2],
                    lastmove = this.info.moves[this.info.moves.length - 1],
                    dx = lastmove.x - this.info.x,
                    dy = lastmove.y - this.info.y,
                    ddy = 0;
                return secondlast && (ddx = lastmove.x - secondlast.x, ddy = lastmove.y - secondlast.y), Gestures.fire(target, "track", {
                    state: this.info.state,
                    x: touch.clientX,
                    y: touch.clientY,
                    dx: dx,
                    dy: dy,
                    ddx: ddx,
                    ddy: ddy,
                    sourceEvent: touch,
                    preventer: preventer,
                    hover: function() {
                        return Gestures.deepTargetFind(touch.clientX, touch.clientY)
                    }
                })
            }
        }), Gestures.register({
            name: "tap",
            deps: ["mousedown", "click", "touchstart", "touchend"],
            flow: {
                start: ["mousedown", "touchstart"],
                end: ["click", "touchend"]
            },
            emits: ["tap"],
            info: {
                x: 0 / 0,
                y: 0 / 0,
                prevent: !1
            },
            reset: function() {
                this.info.x = 0 / 0, this.info.y = 0 / 0, this.info.prevent = !1
            },
            save: function(e) {
                this.info.x = e.clientX, this.info.y = e.clientY
            },
            mousedown: function(e) {
                hasLeftMouseButton(e) && this.save(e)
            },
            click: function(e) {
                hasLeftMouseButton(e) && this.forward(e)
            },
            touchstart: function(e) {
                this.save(e.changedTouches[0], e)
            },
            touchend: function(e) {
                this.forward(e.changedTouches[0], e)
            },
            forward: function(e, preventer) {
                var dx = Math.abs(e.clientX - this.info.x),
                    dy = Math.abs(e.clientY - this.info.y),
                    t = Gestures.findOriginalTarget(e);
                (isNaN(dx) || isNaN(dy) || TAP_DISTANCE >= dx && TAP_DISTANCE >= dy || isSyntheticClick(e)) && (this.info.prevent || Gestures.fire(t, "tap", {
                    x: e.clientX,
                    y: e.clientY,
                    sourceEvent: e,
                    preventer: preventer
                }))
            }
        });
        var DIRECTION_MAP = {
            x: "pan-x",
            y: "pan-y",
            none: "none",
            all: "auto"
        };
        Polymer.Base._addFeature({
            _setupGestures: function() {
                this.__polymerGestures = null
            },
            _listen: function(node, eventName, handler) {
                Gestures.gestures[eventName] ? Gestures.add(node, eventName, handler) : node.addEventListener(eventName, handler)
            },
            _unlisten: function(node, eventName, handler) {
                Gestures.gestures[eventName] ? Gestures.remove(node, eventName, handler) : node.removeEventListener(eventName, handler)
            },
            setScrollDirection: function(direction, node) {
                node = node || this, Gestures.setTouchAction(node, DIRECTION_MAP[direction] || "auto")
            }
        }), Polymer.Gestures = Gestures
    }(),
    function() {
        "use strict";
        if (Polymer.Base._addFeature({
                $$: function(slctr) {
                    return Polymer.dom(this.root).querySelector(slctr)
                },
                toggleClass: function(name, bool, node) {
                    node = node || this, 1 == arguments.length && (bool = !node.classList.contains(name)), bool ? Polymer.dom(node).classList.add(name) : Polymer.dom(node).classList.remove(name)
                },
                toggleAttribute: function(name, bool, node) {
                    node = node || this, 1 == arguments.length && (bool = !node.hasAttribute(name)), bool ? Polymer.dom(node).setAttribute(name, "") : Polymer.dom(node).removeAttribute(name)
                },
                classFollows: function(name, toElement, fromElement) {
                    fromElement && Polymer.dom(fromElement).classList.remove(name), toElement && Polymer.dom(toElement).classList.add(name)
                },
                attributeFollows: function(name, toElement, fromElement) {
                    fromElement && Polymer.dom(fromElement).removeAttribute(name), toElement && Polymer.dom(toElement).setAttribute(name, "")
                },
                getEffectiveChildNodes: function() {
                    return Polymer.dom(this).getEffectiveChildNodes()
                },
                getEffectiveChildren: function() {
                    var list = Polymer.dom(this).getEffectiveChildNodes();
                    return list.filter(function(n) {
                        return n.nodeType === Node.ELEMENT_NODE
                    })
                },
                getEffectiveTextContent: function() {
                    for (var c, cn = this.getEffectiveChildNodes(), tc = [], i = 0; c = cn[i]; i++) c.nodeType !== Node.COMMENT_NODE && tc.push(Polymer.dom(c).textContent);
                    return tc.join("")
                },
                queryEffectiveChildren: function(slctr) {
                    var e$ = Polymer.dom(this).queryDistributedElements(slctr);
                    return e$ && e$[0]
                },
                queryAllEffectiveChildren: function(slctr) {
                    return Polymer.dom(this).queryDistributedElements(slctr)
                },
                getContentChildNodes: function(slctr) {
                    var content = Polymer.dom(this.root).querySelector(slctr || "content");
                    return content ? Polymer.dom(content).getDistributedNodes() : []
                },
                getContentChildren: function(slctr) {
                    return this.getContentChildNodes(slctr).filter(function(n) {
                        return n.nodeType === Node.ELEMENT_NODE
                    })
                },
                fire: function(type, detail, options) {
                    options = options || Polymer.nob;
                    var node = options.node || this;
                    detail = null === detail || void 0 === detail ? {} : detail;
                    var bubbles = void 0 === options.bubbles ? !0 : options.bubbles,
                        cancelable = Boolean(options.cancelable),
                        useCache = options._useCache,
                        event = this._getEvent(type, bubbles, cancelable, useCache);
                    return event.detail = detail, useCache && (this.__eventCache[type] = null), node.dispatchEvent(event), useCache && (this.__eventCache[type] = event), event
                },
                __eventCache: {},
                _getEvent: function(type, bubbles, cancelable, useCache) {
                    var event = useCache && this.__eventCache[type];
                    return event && event.bubbles == bubbles && event.cancelable == cancelable || (event = new Event(type, {
                        bubbles: Boolean(bubbles),
                        cancelable: cancelable
                    })), event
                },
                async: function(callback, waitTime) {
                    var self = this;
                    return Polymer.Async.run(function() {
                        callback.call(self)
                    }, waitTime)
                },
                cancelAsync: function(handle) {
                    Polymer.Async.cancel(handle)
                },
                arrayDelete: function(path, item) {
                    var index;
                    if (Array.isArray(path)) {
                        if (index = path.indexOf(item), index >= 0) return path.splice(index, 1)
                    } else {
                        var arr = this._get(path);
                        if (index = arr.indexOf(item), index >= 0) return this.splice(path, index, 1)
                    }
                },
                transform: function(transform, node) {
                    node = node || this, node.style.webkitTransform = transform, node.style.transform = transform
                },
                translate3d: function(x, y, z, node) {
                    node = node || this, this.transform("translate3d(" + x + "," + y + "," + z + ")", node)
                },
                importHref: function(href, onload, onerror, optAsync) {
                    var link = document.createElement("link");
                    link.rel = "import", link.href = href;
                    var list = Polymer.Base.importHref.imported = Polymer.Base.importHref.imported || {},
                        cached = list[link.href],
                        imprt = cached || link,
                        self = this,
                        loadListener = function(e) {
                            return e.target.__firedLoad = !0, e.target.removeEventListener("load", loadListener), e.target.removeEventListener("error", errorListener), onload.call(self, e)
                        },
                        errorListener = function(e) {
                            return e.target.__firedError = !0, e.target.removeEventListener("load", loadListener), e.target.removeEventListener("error", errorListener), onerror.call(self, e)
                        };
                    return onload && imprt.addEventListener("load", loadListener), onerror && imprt.addEventListener("error", errorListener), cached ? (cached.__firedLoad && cached.dispatchEvent(new Event("load")), cached.__firedError && cached.dispatchEvent(new Event("error"))) : (list[link.href] = link, optAsync = Boolean(optAsync), optAsync && link.setAttribute("async", ""), document.head.appendChild(link)), imprt
                },
                create: function(tag, props) {
                    var elt = document.createElement(tag);
                    if (props)
                        for (var n in props) elt[n] = props[n];
                    return elt
                },
                isLightDescendant: function(node) {
                    return this !== node && this.contains(node) && Polymer.dom(this).getOwnerRoot() === Polymer.dom(node).getOwnerRoot()
                },
                isLocalDescendant: function(node) {
                    return this.root === Polymer.dom(node).getOwnerRoot()
                }
            }), !Polymer.Settings.useNativeCustomElements) {
            var importHref = Polymer.Base.importHref;
            Polymer.Base.importHref = function(href, onload, onerror, optAsync) {
                CustomElements.ready = !1;
                var loadFn = function(e) {
                    return CustomElements.upgradeDocumentTree(document), CustomElements.ready = !0, onload ? onload.call(this, e) : void 0
                };
                return importHref.call(this, href, loadFn, onerror, optAsync)
            }
        }
    }(), Polymer.Bind = {
        prepareModel: function(model) {
            Polymer.Base.mixin(model, this._modelApi)
        },
        _modelApi: {
            _notifyChange: function(source, event, value) {
                value = void 0 === value ? this[source] : value, event = event || Polymer.CaseMap.camelToDashCase(source) + "-changed", this.fire(event, {
                    value: value
                }, {
                    bubbles: !1,
                    cancelable: !1,
                    _useCache: Polymer.Settings.eventDataCache || !Polymer.Settings.isIE
                })
            },
            _propertySetter: function(property, value, effects, fromAbove) {
                var old = this.__data__[property];
                return old === value || old !== old && value !== value || (this.__data__[property] = value, "object" == typeof value && this._clearPath(property), this._propertyChanged && this._propertyChanged(property, value, old), effects && this._effectEffects(property, value, effects, old, fromAbove)), old
            },
            __setProperty: function(property, value, quiet, node) {
                node = node || this;
                var effects = node._propertyEffects && node._propertyEffects[property];
                effects ? node._propertySetter(property, value, effects, quiet) : node[property] !== value && (node[property] = value)
            },
            _effectEffects: function(property, value, effects, old, fromAbove) {
                for (var fx, i = 0, l = effects.length; l > i && (fx = effects[i]); i++) fx.fn.call(this, property, this[property], fx.effect, old, fromAbove)
            },
            _clearPath: function(path) {
                for (var prop in this.__data__) Polymer.Path.isDescendant(path, prop) && (this.__data__[prop] = void 0)
            }
        },
        ensurePropertyEffects: function(model, property) {
            model._propertyEffects || (model._propertyEffects = {});
            var fx = model._propertyEffects[property];
            return fx || (fx = model._propertyEffects[property] = []), fx
        },
        addPropertyEffect: function(model, property, kind, effect) {
            var fx = this.ensurePropertyEffects(model, property),
                propEffect = {
                    kind: kind,
                    effect: effect,
                    fn: Polymer.Bind["_" + kind + "Effect"]
                };
            return fx.push(propEffect), propEffect
        },
        createBindings: function(model) {
            var fx$ = model._propertyEffects;
            if (fx$)
                for (var n in fx$) {
                    var fx = fx$[n];
                    fx.sort(this._sortPropertyEffects), this._createAccessors(model, n, fx)
                }
        },
        _sortPropertyEffects: function() {
            var EFFECT_ORDER = {
                compute: 0,
                annotation: 1,
                annotatedComputation: 2,
                reflect: 3,
                notify: 4,
                observer: 5,
                complexObserver: 6,
                "function": 7
            };
            return function(a, b) {
                return EFFECT_ORDER[a.kind] - EFFECT_ORDER[b.kind]
            }
        }(),
        _createAccessors: function(model, property, effects) {
            var defun = {
                    get: function() {
                        return this.__data__[property]
                    }
                },
                setter = function(value) {
                    this._propertySetter(property, value, effects)
                },
                info = model.getPropertyInfo && model.getPropertyInfo(property);
            info && info.readOnly ? info.computed || (model["_set" + this.upper(property)] = setter) : defun.set = setter, Object.defineProperty(model, property, defun)
        },
        upper: function(name) {
            return name[0].toUpperCase() + name.substring(1)
        },
        _addAnnotatedListener: function(model, index, property, path, event, negated) {
            model._bindListeners || (model._bindListeners = []);
            var fn = this._notedListenerFactory(property, path, Polymer.Path.isDeep(path), negated),
                eventName = event || Polymer.CaseMap.camelToDashCase(property) + "-changed";
            model._bindListeners.push({
                index: index,
                property: property,
                path: path,
                changedFn: fn,
                event: eventName
            })
        },
        _isEventBogus: function(e, target) {
            return e.path && e.path[0] !== target
        },
        _notedListenerFactory: function(property, path, isStructured, negated) {
            return function(target, value, targetPath) {
                if (targetPath) {
                    var newPath = Polymer.Path.translate(property, path, targetPath);
                    this._notifyPath(newPath, value)
                } else value = target[property], negated && (value = !value), isStructured ? this.__data__[path] != value && this.set(path, value) : this[path] = value;

            }
        },
        prepareInstance: function(inst) {
            inst.__data__ = Object.create(null)
        },
        setupBindListeners: function(inst) {
            for (var info, b$ = inst._bindListeners, i = 0, l = b$.length; l > i && (info = b$[i]); i++) {
                var node = inst._nodes[info.index];
                this._addNotifyListener(node, inst, info.event, info.changedFn)
            }
        },
        _addNotifyListener: function(element, context, event, changedFn) {
            element.addEventListener(event, function(e) {
                return context._notifyListener(changedFn, e)
            })
        }
    }, Polymer.Base.mixin(Polymer.Bind, {
        _shouldAddListener: function(effect) {
            return effect.name && "attribute" != effect.kind && "text" != effect.kind && !effect.isCompound && "{" === effect.parts[0].mode
        },
        _annotationEffect: function(source, value, effect) {
            source != effect.value && (value = this._get(effect.value), this.__data__[effect.value] = value), this._applyEffectValue(effect, value)
        },
        _reflectEffect: function(source, value, effect) {
            this.reflectPropertyToAttribute(source, effect.attribute, value)
        },
        _notifyEffect: function(source, value, effect, old, fromAbove) {
            fromAbove || this._notifyChange(source, effect.event, value)
        },
        _functionEffect: function(source, value, fn, old, fromAbove) {
            fn.call(this, source, value, old, fromAbove)
        },
        _observerEffect: function(source, value, effect, old) {
            var fn = this[effect.method];
            fn ? fn.call(this, value, old) : this._warn(this._logf("_observerEffect", "observer method `" + effect.method + "` not defined"))
        },
        _complexObserverEffect: function(source, value, effect) {
            var fn = this[effect.method];
            if (fn) {
                var args = Polymer.Bind._marshalArgs(this.__data__, effect, source, value);
                args && fn.apply(this, args)
            } else effect.dynamicFn || this._warn(this._logf("_complexObserverEffect", "observer method `" + effect.method + "` not defined"))
        },
        _computeEffect: function(source, value, effect) {
            var fn = this[effect.method];
            if (fn) {
                var args = Polymer.Bind._marshalArgs(this.__data__, effect, source, value);
                if (args) {
                    var computedvalue = fn.apply(this, args);
                    this.__setProperty(effect.name, computedvalue)
                }
            } else effect.dynamicFn || this._warn(this._logf("_computeEffect", "compute method `" + effect.method + "` not defined"))
        },
        _annotatedComputationEffect: function(source, value, effect) {
            var computedHost = this._rootDataHost || this,
                fn = computedHost[effect.method];
            if (fn) {
                var args = Polymer.Bind._marshalArgs(this.__data__, effect, source, value);
                if (args) {
                    var computedvalue = fn.apply(computedHost, args);
                    this._applyEffectValue(effect, computedvalue)
                }
            } else effect.dynamicFn || computedHost._warn(computedHost._logf("_annotatedComputationEffect", "compute method `" + effect.method + "` not defined"))
        },
        _marshalArgs: function(model, effect, path, value) {
            for (var values = [], args = effect.args, bailoutEarly = args.length > 1 || effect.dynamicFn, i = 0, l = args.length; l > i; i++) {
                var v, arg = args[i],
                    name = arg.name;
                if (arg.literal ? v = arg.value : path === name ? v = value : (v = model[name], void 0 === v && arg.structured && (v = Polymer.Base._get(name, model))), bailoutEarly && void 0 === v) return;
                if (arg.wildcard) {
                    var matches = Polymer.Path.isAncestor(path, name);
                    values[i] = {
                        path: matches ? path : name,
                        value: matches ? value : v,
                        base: v
                    }
                } else values[i] = v
            }
            return values
        }
    }), Polymer.Base._addFeature({
        _addPropertyEffect: function(property, kind, effect) {
            var prop = Polymer.Bind.addPropertyEffect(this, property, kind, effect);
            prop.pathFn = this["_" + prop.kind + "PathEffect"]
        },
        _prepEffects: function() {
            Polymer.Bind.prepareModel(this), this._addAnnotationEffects(this._notes)
        },
        _prepBindings: function() {
            Polymer.Bind.createBindings(this)
        },
        _addPropertyEffects: function(properties) {
            if (properties)
                for (var p in properties) {
                    var prop = properties[p];
                    if (prop.observer && this._addObserverEffect(p, prop.observer), prop.computed && (prop.readOnly = !0, this._addComputedEffect(p, prop.computed)), prop.notify && this._addPropertyEffect(p, "notify", {
                            event: Polymer.CaseMap.camelToDashCase(p) + "-changed"
                        }), prop.reflectToAttribute) {
                        var attr = Polymer.CaseMap.camelToDashCase(p);
                        "-" === attr[0] ? this._warn(this._logf("_addPropertyEffects", "Property " + p + " cannot be reflected to attribute " + attr + ' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.')) : this._addPropertyEffect(p, "reflect", {
                            attribute: attr
                        })
                    }
                    prop.readOnly && Polymer.Bind.ensurePropertyEffects(this, p)
                }
        },
        _addComputedEffect: function(name, expression) {
            for (var arg, sig = this._parseMethod(expression), dynamicFn = sig.dynamicFn, i = 0; i < sig.args.length && (arg = sig.args[i]); i++) this._addPropertyEffect(arg.model, "compute", {
                method: sig.method,
                args: sig.args,
                trigger: arg,
                name: name,
                dynamicFn: dynamicFn
            });
            dynamicFn && this._addPropertyEffect(sig.method, "compute", {
                method: sig.method,
                args: sig.args,
                trigger: null,
                name: name,
                dynamicFn: dynamicFn
            })
        },
        _addObserverEffect: function(property, observer) {
            this._addPropertyEffect(property, "observer", {
                method: observer,
                property: property
            })
        },
        _addComplexObserverEffects: function(observers) {
            if (observers)
                for (var o, i = 0; i < observers.length && (o = observers[i]); i++) this._addComplexObserverEffect(o)
        },
        _addComplexObserverEffect: function(observer) {
            var sig = this._parseMethod(observer);
            if (!sig) throw new Error("Malformed observer expression '" + observer + "'");
            for (var arg, dynamicFn = sig.dynamicFn, i = 0; i < sig.args.length && (arg = sig.args[i]); i++) this._addPropertyEffect(arg.model, "complexObserver", {
                method: sig.method,
                args: sig.args,
                trigger: arg,
                dynamicFn: dynamicFn
            });
            dynamicFn && this._addPropertyEffect(sig.method, "complexObserver", {
                method: sig.method,
                args: sig.args,
                trigger: null,
                dynamicFn: dynamicFn
            })
        },
        _addAnnotationEffects: function(notes) {
            for (var note, i = 0; i < notes.length && (note = notes[i]); i++)
                for (var binding, b$ = note.bindings, j = 0; j < b$.length && (binding = b$[j]); j++) this._addAnnotationEffect(binding, i)
        },
        _addAnnotationEffect: function(note, index) {
            Polymer.Bind._shouldAddListener(note) && Polymer.Bind._addAnnotatedListener(this, index, note.name, note.parts[0].value, note.parts[0].event, note.parts[0].negate);
            for (var i = 0; i < note.parts.length; i++) {
                var part = note.parts[i];
                part.signature ? this._addAnnotatedComputationEffect(note, part, index) : part.literal || ("attribute" === note.kind && "-" === note.name[0] ? this._warn(this._logf("_addAnnotationEffect", "Cannot set attribute " + note.name + ' because "-" is not a valid attribute starting character')) : this._addPropertyEffect(part.model, "annotation", {
                    kind: note.kind,
                    index: index,
                    name: note.name,
                    propertyName: note.propertyName,
                    value: part.value,
                    isCompound: note.isCompound,
                    compoundIndex: part.compoundIndex,
                    event: part.event,
                    customEvent: part.customEvent,
                    negate: part.negate
                }))
            }
        },
        _addAnnotatedComputationEffect: function(note, part, index) {
            var sig = part.signature;
            if (sig["static"]) this.__addAnnotatedComputationEffect("__static__", index, note, part, null);
            else {
                for (var arg, i = 0; i < sig.args.length && (arg = sig.args[i]); i++) arg.literal || this.__addAnnotatedComputationEffect(arg.model, index, note, part, arg);
                sig.dynamicFn && this.__addAnnotatedComputationEffect(sig.method, index, note, part, null)
            }
        },
        __addAnnotatedComputationEffect: function(property, index, note, part, trigger) {
            this._addPropertyEffect(property, "annotatedComputation", {
                index: index,
                isCompound: note.isCompound,
                compoundIndex: part.compoundIndex,
                kind: note.kind,
                name: note.name,
                negate: part.negate,
                method: part.signature.method,
                args: part.signature.args,
                trigger: trigger,
                dynamicFn: part.signature.dynamicFn
            })
        },
        _parseMethod: function(expression) {
            var m = expression.match(/([^\s]+?)\(([\s\S]*)\)/);
            if (m) {
                var sig = {
                    method: m[1],
                    "static": !0
                };
                if (this.getPropertyInfo(sig.method) !== Polymer.nob && (sig["static"] = !1, sig.dynamicFn = !0), m[2].trim()) {
                    var args = m[2].replace(/\\,/g, "&comma;").split(",");
                    return this._parseArgs(args, sig)
                }
                return sig.args = Polymer.nar, sig
            }
        },
        _parseArgs: function(argList, sig) {
            return sig.args = argList.map(function(rawArg) {
                var arg = this._parseArg(rawArg);
                return arg.literal || (sig["static"] = !1), arg
            }, this), sig
        },
        _parseArg: function(rawArg) {
            var arg = rawArg.trim().replace(/&comma;/g, ",").replace(/\\(.)/g, "$1"),
                a = {
                    name: arg
                },
                fc = arg[0];
            switch ("-" === fc && (fc = arg[1]), fc >= "0" && "9" >= fc && (fc = "#"), fc) {
                case "'":
                case '"':
                    a.value = arg.slice(1, -1), a.literal = !0;
                    break;
                case "#":
                    a.value = Number(arg), a.literal = !0
            }
            return a.literal || (a.model = Polymer.Path.root(arg), a.structured = Polymer.Path.isDeep(arg), a.structured && (a.wildcard = ".*" == arg.slice(-2), a.wildcard && (a.name = arg.slice(0, -2)))), a
        },
        _marshalInstanceEffects: function() {
            Polymer.Bind.prepareInstance(this), this._bindListeners && Polymer.Bind.setupBindListeners(this)
        },
        _applyEffectValue: function(info, value) {
            var node = this._nodes[info.index],
                property = info.name;
            if (value = this._computeFinalAnnotationValue(node, property, value, info), "attribute" == info.kind) this.serializeValueToAttribute(value, property, node);
            else {
                var pinfo = node._propertyInfo && node._propertyInfo[property];
                if (pinfo && pinfo.readOnly) return;
                this.__setProperty(property, value, Polymer.Settings.suppressBindingNotifications, node)
            }
        },
        _computeFinalAnnotationValue: function(node, property, value, info) {
            if (info.negate && (value = !value), info.isCompound) {
                var storage = node.__compoundStorage__[property];
                storage[info.compoundIndex] = value, value = storage.join("")
            }
            return "attribute" !== info.kind && ("className" === property && (value = this._scopeElementClass(node, value)), ("textContent" === property || "input" == node.localName && "value" == property) && (value = void 0 == value ? "" : value)), value
        },
        _executeStaticEffects: function() {
            this._propertyEffects && this._propertyEffects.__static__ && this._effectEffects("__static__", null, this._propertyEffects.__static__)
        }
    }),
    function() {
        var usePolyfillProto = Polymer.Settings.usePolyfillProto,
            avoidInstanceProperties = Boolean(Object.getOwnPropertyDescriptor(document.documentElement, "properties"));
        Polymer.Base._addFeature({
            _setupConfigure: function(initialConfig) {
                if (this._config = {}, this._handlers = [], this._aboveConfig = null, initialConfig)
                    for (var i in initialConfig) void 0 !== initialConfig[i] && (this._config[i] = initialConfig[i])
            },
            _marshalAttributes: function() {
                this._takeAttributesToModel(this._config)
            },
            _attributeChangedImpl: function(name) {
                var model = this._clientsReadied ? this : this._config;
                this._setAttributeToProperty(model, name)
            },
            _configValue: function(name, value) {
                var info = this._propertyInfo[name];
                info && info.readOnly || (this._config[name] = value)
            },
            _beforeClientsReady: function() {
                this._configure()
            },
            _configure: function() {
                this._configureAnnotationReferences(), this._configureInstanceProperties(), this._aboveConfig = this.mixin({}, this._config);
                for (var config = {}, i = 0; i < this.behaviors.length; i++) this._configureProperties(this.behaviors[i].properties, config);
                this._configureProperties(avoidInstanceProperties ? this.__proto__.properties : this.properties, config), this.mixin(config, this._aboveConfig), this._config = config, this._clients && this._clients.length && this._distributeConfig(this._config)
            },
            _configureInstanceProperties: function() {
                for (var i in this._propertyEffects) !usePolyfillProto && this.hasOwnProperty(i) && (this._configValue(i, this[i]), delete this[i])
            },
            _configureProperties: function(properties, config) {
                for (var i in properties) {
                    var c = properties[i];
                    if (void 0 !== c.value) {
                        var value = c.value;
                        "function" == typeof value && (value = value.call(this, this._config)), config[i] = value
                    }
                }
            },
            _distributeConfig: function(config) {
                var fx$ = this._propertyEffects;
                if (fx$)
                    for (var p in config) {
                        var fx = fx$[p];
                        if (fx)
                            for (var x, i = 0, l = fx.length; l > i && (x = fx[i]); i++)
                                if ("annotation" === x.kind) {
                                    var node = this._nodes[x.effect.index],
                                        name = x.effect.propertyName,
                                        isAttr = "attribute" == x.effect.kind,
                                        hasEffect = node._propertyEffects && node._propertyEffects[name];
                                    if (node._configValue && (hasEffect || !isAttr)) {
                                        var value = p === x.effect.value ? config[p] : this._get(x.effect.value, config);
                                        value = this._computeFinalAnnotationValue(node, name, value, x.effect), isAttr && (value = node.deserialize(this.serialize(value), node._propertyInfo[name].type)), node._configValue(name, value)
                                    }
                                }
                    }
            },
            _afterClientsReady: function() {
                this.importPath = this._importPath, this.rootPath = Polymer.rootPath, this._executeStaticEffects(), this._applyConfig(this._config, this._aboveConfig), this._flushHandlers()
            },
            _applyConfig: function(config, aboveConfig) {
                for (var n in config) void 0 === this[n] && this.__setProperty(n, config[n], n in aboveConfig)
            },
            _notifyListener: function(fn, e) {
                if (!Polymer.Bind._isEventBogus(e, e.target)) {
                    var value, path;
                    if (e.detail && (value = e.detail.value, path = e.detail.path), this._clientsReadied) return fn.call(this, e.target, value, path);
                    this._queueHandler([fn, e.target, value, path])
                }
            },
            _queueHandler: function(args) {
                this._handlers.push(args)
            },
            _flushHandlers: function() {
                for (var h, h$ = this._handlers, i = 0, l = h$.length; l > i && (h = h$[i]); i++) h[0].call(this, h[1], h[2], h[3]);
                this._handlers = []
            }
        })
    }(),
    function() {
        "use strict";
        var Path = Polymer.Path;
        Polymer.Base._addFeature({
            notifyPath: function(path, value, fromAbove) {
                var info = {},
                    v = this._get(path, this, info);
                1 === arguments.length && (value = v), info.path && this._notifyPath(info.path, value, fromAbove)
            },
            _notifyPath: function(path, value, fromAbove) {
                var old = this._propertySetter(path, value);
                return old === value || old !== old && value !== value ? void 0 : (this._pathEffector(path, value), fromAbove || this._notifyPathUp(path, value), !0)
            },
            _getPathParts: function(path) {
                if (Array.isArray(path)) {
                    for (var parts = [], i = 0; i < path.length; i++)
                        for (var args = path[i].toString().split("."), j = 0; j < args.length; j++) parts.push(args[j]);
                    return parts
                }
                return path.toString().split(".")
            },
            set: function(path, value, root) {
                var array, prop = root || this,
                    parts = this._getPathParts(path),
                    last = parts[parts.length - 1];
                if (parts.length > 1) {
                    for (var i = 0; i < parts.length - 1; i++) {
                        var part = parts[i];
                        if (array && "#" == part[0] ? prop = Polymer.Collection.get(array).getItem(part) : (prop = prop[part], array && parseInt(part, 10) == part && (parts[i] = Polymer.Collection.get(array).getKey(prop))), !prop) return;
                        array = Array.isArray(prop) ? prop : null
                    }
                    if (array) {
                        var old, key, coll = Polymer.Collection.get(array);
                        "#" == last[0] ? (key = last, old = coll.getItem(key), last = array.indexOf(old), coll.setItem(key, value)) : parseInt(last, 10) == last && (old = prop[last], key = coll.getKey(old), parts[i] = key, coll.setItem(key, value))
                    }
                    prop[last] = value, root || this._notifyPath(parts.join("."), value)
                } else prop[path] = value
            },
            get: function(path, root) {
                return this._get(path, root)
            },
            _get: function(path, root, info) {
                for (var array, prop = root || this, parts = this._getPathParts(path), i = 0; i < parts.length; i++) {
                    if (!prop) return;
                    var part = parts[i];
                    array && "#" == part[0] ? prop = Polymer.Collection.get(array).getItem(part) : (prop = prop[part], info && array && parseInt(part, 10) == part && (parts[i] = Polymer.Collection.get(array).getKey(prop))), array = Array.isArray(prop) ? prop : null
                }
                return info && (info.path = parts.join(".")), prop
            },
            _pathEffector: function(path, value) {
                var model = Path.root(path),
                    fx$ = this._propertyEffects && this._propertyEffects[model];
                if (fx$)
                    for (var fx, i = 0; i < fx$.length && (fx = fx$[i]); i++) {
                        var fxFn = fx.pathFn;
                        fxFn && fxFn.call(this, path, value, fx.effect)
                    }
                this._boundPaths && this._notifyBoundPaths(path, value)
            },
            _annotationPathEffect: function(path, value, effect) {
                if (Path.matches(effect.value, !1, path)) Polymer.Bind._annotationEffect.call(this, path, value, effect);
                else if (!effect.negate && Path.isDescendant(effect.value, path)) {
                    var node = this._nodes[effect.index];
                    if (node && node._notifyPath) {
                        var newPath = Path.translate(effect.value, effect.name, path);
                        node._notifyPath(newPath, value, !0)
                    }
                }
            },
            _complexObserverPathEffect: function(path, value, effect) {
                Path.matches(effect.trigger.name, effect.trigger.wildcard, path) && Polymer.Bind._complexObserverEffect.call(this, path, value, effect)
            },
            _computePathEffect: function(path, value, effect) {
                Path.matches(effect.trigger.name, effect.trigger.wildcard, path) && Polymer.Bind._computeEffect.call(this, path, value, effect)
            },
            _annotatedComputationPathEffect: function(path, value, effect) {
                Path.matches(effect.trigger.name, effect.trigger.wildcard, path) && Polymer.Bind._annotatedComputationEffect.call(this, path, value, effect)
            },
            linkPaths: function(to, from) {
                this._boundPaths = this._boundPaths || {}, from ? this._boundPaths[to] = from : this.unlinkPaths(to)
            },
            unlinkPaths: function(path) {
                this._boundPaths && delete this._boundPaths[path]
            },
            _notifyBoundPaths: function(path, value) {
                for (var a in this._boundPaths) {
                    var b = this._boundPaths[a];
                    Path.isDescendant(a, path) ? this._notifyPath(Path.translate(a, b, path), value) : Path.isDescendant(b, path) && this._notifyPath(Path.translate(b, a, path), value)
                }
            },
            _notifyPathUp: function(path, value) {
                var rootName = Path.root(path),
                    dashCaseName = Polymer.CaseMap.camelToDashCase(rootName),
                    eventName = dashCaseName + this._EVENT_CHANGED;
                this.fire(eventName, {
                    path: path,
                    value: value
                }, {
                    bubbles: !1,
                    _useCache: Polymer.Settings.eventDataCache || !Polymer.Settings.isIE
                })
            },
            _EVENT_CHANGED: "-changed",
            notifySplices: function(path, splices) {
                var info = {},
                    array = this._get(path, this, info);
                this._notifySplices(array, info.path, splices)
            },
            _notifySplices: function(array, path, splices) {
                var change = {
                        keySplices: Polymer.Collection.applySplices(array, splices),
                        indexSplices: splices
                    },
                    splicesPath = path + ".splices";
                this._notifyPath(splicesPath, change), this._notifyPath(path + ".length", array.length), this.__data__[splicesPath] = {
                    keySplices: null,
                    indexSplices: null
                }
            },
            _notifySplice: function(array, path, index, added, removed) {
                this._notifySplices(array, path, [{
                    index: index,
                    addedCount: added,
                    removed: removed,
                    object: array,
                    type: "splice"
                }])
            },
            push: function(path) {
                var info = {},
                    array = this._get(path, this, info),
                    args = Array.prototype.slice.call(arguments, 1),
                    len = array.length,
                    ret = array.push.apply(array, args);
                return args.length && this._notifySplice(array, info.path, len, args.length, []), ret
            },
            pop: function(path) {
                var info = {},
                    array = this._get(path, this, info),
                    hadLength = Boolean(array.length),
                    args = Array.prototype.slice.call(arguments, 1),
                    ret = array.pop.apply(array, args);
                return hadLength && this._notifySplice(array, info.path, array.length, 0, [ret]), ret
            },
            splice: function(path, start) {
                var info = {},
                    array = this._get(path, this, info);
                start = 0 > start ? array.length - Math.floor(-start) : Math.floor(start), start || (start = 0);
                var args = Array.prototype.slice.call(arguments, 1),
                    ret = array.splice.apply(array, args),
                    addedCount = Math.max(args.length - 2, 0);
                return (addedCount || ret.length) && this._notifySplice(array, info.path, start, addedCount, ret), ret
            },
            shift: function(path) {
                var info = {},
                    array = this._get(path, this, info),
                    hadLength = Boolean(array.length),
                    args = Array.prototype.slice.call(arguments, 1),
                    ret = array.shift.apply(array, args);
                return hadLength && this._notifySplice(array, info.path, 0, 0, [ret]), ret
            },
            unshift: function(path) {
                var info = {},
                    array = this._get(path, this, info),
                    args = Array.prototype.slice.call(arguments, 1),
                    ret = array.unshift.apply(array, args);
                return args.length && this._notifySplice(array, info.path, 0, args.length, []), ret
            },
            prepareModelNotifyPath: function(model) {
                this.mixin(model, {
                    fire: Polymer.Base.fire,
                    _getEvent: Polymer.Base._getEvent,
                    __eventCache: Polymer.Base.__eventCache,
                    notifyPath: Polymer.Base.notifyPath,
                    _get: Polymer.Base._get,
                    _EVENT_CHANGED: Polymer.Base._EVENT_CHANGED,
                    _notifyPath: Polymer.Base._notifyPath,
                    _notifyPathUp: Polymer.Base._notifyPathUp,
                    _pathEffector: Polymer.Base._pathEffector,
                    _annotationPathEffect: Polymer.Base._annotationPathEffect,
                    _complexObserverPathEffect: Polymer.Base._complexObserverPathEffect,
                    _annotatedComputationPathEffect: Polymer.Base._annotatedComputationPathEffect,
                    _computePathEffect: Polymer.Base._computePathEffect,
                    _notifyBoundPaths: Polymer.Base._notifyBoundPaths,
                    _getPathParts: Polymer.Base._getPathParts
                })
            }
        })
    }(), Polymer.Base._addFeature({
        resolveUrl: function(url) {
            return Polymer.ResolveUrl.resolveUrl(url, this._importPath)
        }
    }), Polymer.CssParse = function() {
        return {
            parse: function(text) {
                return text = this._clean(text), this._parseCss(this._lex(text), text)
            },
            _clean: function(cssText) {
                return cssText.replace(this._rx.comments, "").replace(this._rx.port, "")
            },
            _lex: function(text) {
                for (var root = {
                        start: 0,
                        end: text.length
                    }, n = root, i = 0, l = text.length; l > i; i++) switch (text[i]) {
                    case this.OPEN_BRACE:
                        n.rules || (n.rules = []);
                        var p = n,
                            previous = p.rules[p.rules.length - 1];
                        n = {
                            start: i + 1,
                            parent: p,
                            previous: previous
                        }, p.rules.push(n);
                        break;
                    case this.CLOSE_BRACE:
                        n.end = i + 1, n = n.parent || root
                }
                return root
            },
            _parseCss: function(node, text) {
                var t = text.substring(node.start, node.end - 1);
                if (node.parsedCssText = node.cssText = t.trim(), node.parent) {
                    var ss = node.previous ? node.previous.end : node.parent.start;
                    t = text.substring(ss, node.start - 1), t = this._expandUnicodeEscapes(t), t = t.replace(this._rx.multipleSpaces, " "), t = t.substring(t.lastIndexOf(";") + 1);
                    var s = node.parsedSelector = node.selector = t.trim();
                    node.atRule = 0 === s.indexOf(this.AT_START), node.atRule ? 0 === s.indexOf(this.MEDIA_START) ? node.type = this.types.MEDIA_RULE : s.match(this._rx.keyframesRule) && (node.type = this.types.KEYFRAMES_RULE, node.keyframesName = node.selector.split(this._rx.multipleSpaces).pop()) : node.type = 0 === s.indexOf(this.VAR_START) ? this.types.MIXIN_RULE : this.types.STYLE_RULE
                }
                var r$ = node.rules;
                if (r$)
                    for (var r, i = 0, l = r$.length; l > i && (r = r$[i]); i++) this._parseCss(r, text);
                return node
            },
            _expandUnicodeEscapes: function(s) {
                return s.replace(/\\([0-9a-f]{1,6})\s/gi, function() {
                    for (var code = arguments[1], repeat = 6 - code.length; repeat--;) code = "0" + code;
                    return "\\" + code
                })
            },
            stringify: function(node, preserveProperties, text) {
                text = text || "";
                var cssText = "";
                if (node.cssText || node.rules) {
                    var r$ = node.rules;
                    if (r$ && !this._hasMixinRules(r$))
                        for (var r, i = 0, l = r$.length; l > i && (r = r$[i]); i++) cssText = this.stringify(r, preserveProperties, cssText);
                    else cssText = preserveProperties ? node.cssText : this.removeCustomProps(node.cssText), cssText = cssText.trim(), cssText && (cssText = "  " + cssText + "\n")
                }
                return cssText && (node.selector && (text += node.selector + " " + this.OPEN_BRACE + "\n"), text += cssText, node.selector && (text += this.CLOSE_BRACE + "\n\n")), text
            },
            _hasMixinRules: function(rules) {
                return 0 === rules[0].selector.indexOf(this.VAR_START)
            },
            removeCustomProps: function(cssText) {
                return cssText = this.removeCustomPropAssignment(cssText), this.removeCustomPropApply(cssText)
            },
            removeCustomPropAssignment: function(cssText) {
                return cssText.replace(this._rx.customProp, "").replace(this._rx.mixinProp, "")
            },
            removeCustomPropApply: function(cssText) {
                return cssText.replace(this._rx.mixinApply, "").replace(this._rx.varApply, "")
            },
            types: {
                STYLE_RULE: 1,
                KEYFRAMES_RULE: 7,
                MEDIA_RULE: 4,
                MIXIN_RULE: 1e3
            },
            OPEN_BRACE: "{",
            CLOSE_BRACE: "}",
            _rx: {
                comments: /\/\*[^*]*\*+([^\/*][^*]*\*+)*\//gim,
                port: /@import[^;]*;/gim,
                customProp: /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim,
                mixinProp: /(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim,
                mixinApply: /@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim,
                varApply: /[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim,
                keyframesRule: /^@[^\s]*keyframes/,
                multipleSpaces: /\s+/g
            },
            VAR_START: "--",
            MEDIA_START: "@media",
            AT_START: "@"
        }
    }(), Polymer.StyleUtil = function() {
        var settings = Polymer.Settings;
        return {
            NATIVE_VARIABLES: Polymer.Settings.useNativeCSSProperties,
            MODULE_STYLES_SELECTOR: "style, link[rel=import][type~=css], template",
            INCLUDE_ATTR: "include",
            toCssText: function(rules, callback) {
                return "string" == typeof rules && (rules = this.parser.parse(rules)), callback && this.forEachRule(rules, callback), this.parser.stringify(rules, this.NATIVE_VARIABLES)
            },
            forRulesInStyles: function(styles, styleRuleCallback, keyframesRuleCallback) {
                if (styles)
                    for (var s, i = 0, l = styles.length; l > i && (s = styles[i]); i++) this.forEachRuleInStyle(s, styleRuleCallback, keyframesRuleCallback)
            },
            forActiveRulesInStyles: function(styles, styleRuleCallback, keyframesRuleCallback) {
                if (styles)
                    for (var s, i = 0, l = styles.length; l > i && (s = styles[i]); i++) this.forEachRuleInStyle(s, styleRuleCallback, keyframesRuleCallback, !0)
            },
            rulesForStyle: function(style) {
                return !style.__cssRules && style.textContent && (style.__cssRules = this.parser.parse(style.textContent)), style.__cssRules
            },
            isKeyframesSelector: function(rule) {
                return rule.parent && rule.parent.type === this.ruleTypes.KEYFRAMES_RULE
            },
            forEachRuleInStyle: function(style, styleRuleCallback, keyframesRuleCallback, onlyActiveRules) {
                var styleCallback, keyframeCallback, rules = this.rulesForStyle(style);
                styleRuleCallback && (styleCallback = function(rule) {
                    styleRuleCallback(rule, style)
                }), keyframesRuleCallback && (keyframeCallback = function(rule) {
                    keyframesRuleCallback(rule, style)
                }), this.forEachRule(rules, styleCallback, keyframeCallback, onlyActiveRules)
            },
            forEachRule: function(node, styleRuleCallback, keyframesRuleCallback, onlyActiveRules) {
                if (node) {
                    var skipRules = !1;
                    if (onlyActiveRules && node.type === this.ruleTypes.MEDIA_RULE) {
                        var matchMedia = node.selector.match(this.rx.MEDIA_MATCH);
                        matchMedia && (window.matchMedia(matchMedia[1]).matches || (skipRules = !0))
                    }
                    node.type === this.ruleTypes.STYLE_RULE ? styleRuleCallback(node) : keyframesRuleCallback && node.type === this.ruleTypes.KEYFRAMES_RULE ? keyframesRuleCallback(node) : node.type === this.ruleTypes.MIXIN_RULE && (skipRules = !0);
                    var r$ = node.rules;
                    if (r$ && !skipRules)
                        for (var r, i = 0, l = r$.length; l > i && (r = r$[i]); i++) this.forEachRule(r, styleRuleCallback, keyframesRuleCallback, onlyActiveRules)
                }
            },
            applyCss: function(cssText, moniker, target, contextNode) {
                var style = this.createScopeStyle(cssText, moniker);
                return this.applyStyle(style, target, contextNode)
            },
            applyStyle: function(style, target, contextNode) {
                target = target || document.head;
                var after = contextNode && contextNode.nextSibling || target.firstChild;
                return this.__lastHeadApplyNode = style, target.insertBefore(style, after)
            },
            createScopeStyle: function(cssText, moniker) {
                var style = document.createElement("style");
                return moniker && style.setAttribute("scope", moniker), style.textContent = cssText, style
            },
            __lastHeadApplyNode: null,
            applyStylePlaceHolder: function(moniker) {
                var placeHolder = document.createComment(" Shady DOM styles for " + moniker + " "),
                    after = this.__lastHeadApplyNode ? this.__lastHeadApplyNode.nextSibling : null,
                    scope = document.head;
                return scope.insertBefore(placeHolder, after || scope.firstChild), this.__lastHeadApplyNode = placeHolder, placeHolder
            },
            cssFromModules: function(moduleIds, warnIfNotFound) {
                for (var modules = moduleIds.trim().split(" "), cssText = "", i = 0; i < modules.length; i++) cssText += this.cssFromModule(modules[i], warnIfNotFound);
                return cssText
            },
            cssFromModule: function(moduleId, warnIfNotFound) {
                var m = Polymer.DomModule["import"](moduleId);
                return m && !m._cssText && (m._cssText = this.cssFromElement(m)), !m && warnIfNotFound && console.warn("Could not find style data in module named", moduleId), m && m._cssText || ""
            },
            cssFromElement: function(element) {
                for (var e, cssText = "", content = element.content || element, e$ = Polymer.TreeApi.arrayCopy(content.querySelectorAll(this.MODULE_STYLES_SELECTOR)), i = 0; i < e$.length; i++)
                    if (e = e$[i], "template" === e.localName) e.hasAttribute("preserve-content") || (cssText += this.cssFromElement(e));
                    else if ("style" === e.localName) {
                    var include = e.getAttribute(this.INCLUDE_ATTR);
                    include && (cssText += this.cssFromModules(include, !0)), e = e.__appliedElement || e, e.parentNode.removeChild(e), cssText += this.resolveCss(e.textContent, element.ownerDocument)
                } else e["import"] && e["import"].body && (cssText += this.resolveCss(e["import"].body.textContent, e["import"]));
                return cssText
            },
            styleIncludesToTemplate: function(targetTemplate) {
                for (var s, styles = targetTemplate.content.querySelectorAll("style[include]"), i = 0; i < styles.length; i++) s = styles[i], s.parentNode.insertBefore(this._includesToFragment(s.getAttribute("include")), s)
            },
            _includesToFragment: function(styleIncludes) {
                for (var includeArray = styleIncludes.trim().split(" "), frag = document.createDocumentFragment(), i = 0; i < includeArray.length; i++) {
                    var t = Polymer.DomModule["import"](includeArray[i], "template");
                    t && this._addStylesToFragment(frag, t.content)
                }
                return frag
            },
            _addStylesToFragment: function(frag, source) {
                for (var s, s$ = source.querySelectorAll("style"), i = 0; i < s$.length; i++) {
                    s = s$[i];
                    var include = s.getAttribute("include");
                    include && frag.appendChild(this._includesToFragment(include)), s.textContent && frag.appendChild(s.cloneNode(!0))
                }
            },
            isTargetedBuild: function(buildType) {
                return settings.useNativeShadow ? "shadow" === buildType : "shady" === buildType
            },
            cssBuildTypeForModule: function(module) {
                var dm = Polymer.DomModule["import"](module);
                return dm ? this.getCssBuildType(dm) : void 0
            },
            getCssBuildType: function(element) {
                return element.getAttribute("css-build")
            },
            _findMatchingParen: function(text, start) {
                for (var level = 0, i = start, l = text.length; l > i; i++) switch (text[i]) {
                    case "(":
                        level++;
                        break;
                    case ")":
                        if (0 === --level) return i
                }
                return -1
            },
            processVariableAndFallback: function(str, callback) {
                var start = str.indexOf("var(");
                if (-1 === start) return callback(str, "", "", "");
                var end = this._findMatchingParen(str, start + 3),
                    inner = str.substring(start + 4, end),
                    prefix = str.substring(0, start),
                    suffix = this.processVariableAndFallback(str.substring(end + 1), callback),
                    comma = inner.indexOf(",");
                if (-1 === comma) return callback(prefix, inner.trim(), "", suffix);
                var value = inner.substring(0, comma).trim(),
                    fallback = inner.substring(comma + 1).trim();
                return callback(prefix, value, fallback, suffix)
            },
            rx: {
                VAR_ASSIGN: /(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:([^;{]*)|{([^}]*)})(?:(?=[;\s}])|$)/gi,
                MIXIN_MATCH: /(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi,
                VAR_CONSUMED: /(--[\w-]+)\s*([:,;)]|$)/gi,
                ANIMATION_MATCH: /(animation\s*:)|(animation-name\s*:)/,
                MEDIA_MATCH: /@media[^(]*(\([^)]*\))/,
                IS_VAR: /^--/,
                BRACKETED: /\{[^}]*\}/g,
                HOST_PREFIX: "(?:^|[^.#[:])",
                HOST_SUFFIX: "($|[.:[\\s>+~])"
            },
            resolveCss: Polymer.ResolveUrl.resolveCss,
            parser: Polymer.CssParse,
            ruleTypes: Polymer.CssParse.types
        }
    }(), Polymer.StyleTransformer = function() {
        var styleUtil = Polymer.StyleUtil,
            settings = Polymer.Settings,
            api = {
                dom: function(node, scope, useAttr, shouldRemoveScope) {
                    this._transformDom(node, scope || "", useAttr, shouldRemoveScope)
                },
                _transformDom: function(node, selector, useAttr, shouldRemoveScope) {
                    node.setAttribute && this.element(node, selector, useAttr, shouldRemoveScope);
                    for (var c$ = Polymer.dom(node).childNodes, i = 0; i < c$.length; i++) this._transformDom(c$[i], selector, useAttr, shouldRemoveScope)
                },
                element: function(element, scope, useAttr, shouldRemoveScope) {
                    if (useAttr) shouldRemoveScope ? element.removeAttribute(SCOPE_NAME) : element.setAttribute(SCOPE_NAME, scope);
                    else if (scope)
                        if (element.classList) shouldRemoveScope ? (element.classList.remove(SCOPE_NAME), element.classList.remove(scope)) : (element.classList.add(SCOPE_NAME), element.classList.add(scope));
                        else if (element.getAttribute) {
                        var c = element.getAttribute(CLASS);
                        shouldRemoveScope ? c && element.setAttribute(CLASS, c.replace(SCOPE_NAME, "").replace(scope, "")) : element.setAttribute(CLASS, (c ? c + " " : "") + SCOPE_NAME + " " + scope)
                    }
                },
                elementStyles: function(element, callback) {
                    var cb, styles = element._styles,
                        cssText = "",
                        cssBuildType = element.__cssBuild,
                        passthrough = settings.useNativeShadow || "shady" === cssBuildType;
                    if (passthrough) {
                        var self = this;
                        cb = function(rule) {
                            rule.selector = self._slottedToContent(rule.selector), rule.selector = rule.selector.replace(ROOT, ":host > *"), callback && callback(rule)
                        }
                    }
                    for (var s, i = 0, l = styles.length; l > i && (s = styles[i]); i++) {
                        var rules = styleUtil.rulesForStyle(s);
                        cssText += passthrough ? styleUtil.toCssText(rules, cb) : this.css(rules, element.is, element["extends"], callback, element._scopeCssViaAttr) + "\n\n"
                    }
                    return cssText.trim()
                },
                css: function(rules, scope, ext, callback, useAttr) {
                    var hostScope = this._calcHostScope(scope, ext);
                    scope = this._calcElementScope(scope, useAttr);
                    var self = this;
                    return styleUtil.toCssText(rules, function(rule) {
                        rule.isScoped || (self.rule(rule, scope, hostScope), rule.isScoped = !0), callback && callback(rule, scope, hostScope)
                    })
                },
                _calcElementScope: function(scope, useAttr) {
                    return scope ? useAttr ? CSS_ATTR_PREFIX + scope + CSS_ATTR_SUFFIX : CSS_CLASS_PREFIX + scope : ""
                },
                _calcHostScope: function(scope, ext) {
                    return ext ? "[is=" + scope + "]" : scope
                },
                rule: function(rule, scope, hostScope) {
                    this._transformRule(rule, this._transformComplexSelector, scope, hostScope)
                },
                _transformRule: function(rule, transformer, scope, hostScope) {
                    rule.selector = rule.transformedSelector = this._transformRuleCss(rule, transformer, scope, hostScope)
                },
                _transformRuleCss: function(rule, transformer, scope, hostScope) {
                    var p$ = rule.selector.split(COMPLEX_SELECTOR_SEP);
                    if (!styleUtil.isKeyframesSelector(rule))
                        for (var p, i = 0, l = p$.length; l > i && (p = p$[i]); i++) p$[i] = transformer.call(this, p, scope, hostScope);
                    return p$.join(COMPLEX_SELECTOR_SEP)
                },
                _transformComplexSelector: function(selector, scope, hostScope) {
                    var stop = !1,
                        hostContext = !1,
                        self = this;
                    return selector = selector.trim(), selector = this._slottedToContent(selector), selector = selector.replace(ROOT, ":host > *"), selector = selector.replace(CONTENT_START, HOST + " $1"), selector = selector.replace(SIMPLE_SELECTOR_SEP, function(m, c, s) {
                        if (stop) s = s.replace(SCOPE_JUMP, " ");
                        else {
                            var info = self._transformCompoundSelector(s, c, scope, hostScope);
                            stop = stop || info.stop, hostContext = hostContext || info.hostContext, c = info.combinator, s = info.value
                        }
                        return c + s
                    }), hostContext && (selector = selector.replace(HOST_CONTEXT_PAREN, function(m, pre, paren, post) {
                        return pre + paren + " " + hostScope + post + COMPLEX_SELECTOR_SEP + " " + pre + hostScope + paren + post
                    })), selector
                },
                _transformCompoundSelector: function(selector, combinator, scope, hostScope) {
                    var jumpIndex = selector.search(SCOPE_JUMP),
                        hostContext = !1;
                    selector.indexOf(HOST_CONTEXT) >= 0 ? hostContext = !0 : selector.indexOf(HOST) >= 0 ? selector = this._transformHostSelector(selector, hostScope) : 0 !== jumpIndex && (selector = scope ? this._transformSimpleSelector(selector, scope) : selector), selector.indexOf(CONTENT) >= 0 && (combinator = "");

                    var stop;
                    return jumpIndex >= 0 && (selector = selector.replace(SCOPE_JUMP, " "), stop = !0), {
                        value: selector,
                        combinator: combinator,
                        stop: stop,
                        hostContext: hostContext
                    }
                },
                _transformSimpleSelector: function(selector, scope) {
                    var p$ = selector.split(PSEUDO_PREFIX);
                    return p$[0] += scope, p$.join(PSEUDO_PREFIX)
                },
                _transformHostSelector: function(selector, hostScope) {
                    var m = selector.match(HOST_PAREN),
                        paren = m && m[2].trim() || "";
                    if (paren) {
                        if (paren[0].match(SIMPLE_SELECTOR_PREFIX)) return selector.replace(HOST_PAREN, function(m, host, paren) {
                            return hostScope + paren
                        });
                        var typeSelector = paren.split(SIMPLE_SELECTOR_PREFIX)[0];
                        return typeSelector === hostScope ? paren : SELECTOR_NO_MATCH
                    }
                    return selector.replace(HOST, hostScope)
                },
                documentRule: function(rule) {
                    rule.selector = rule.parsedSelector, this.normalizeRootSelector(rule), settings.useNativeShadow || this._transformRule(rule, this._transformDocumentSelector)
                },
                normalizeRootSelector: function(rule) {
                    rule.selector = rule.selector.replace(ROOT, "html")
                },
                _transformDocumentSelector: function(selector) {
                    return selector.match(SCOPE_JUMP) ? this._transformComplexSelector(selector, SCOPE_DOC_SELECTOR) : this._transformSimpleSelector(selector.trim(), SCOPE_DOC_SELECTOR)
                },
                _slottedToContent: function(cssText) {
                    return cssText.replace(SLOTTED_PAREN, CONTENT + "> $1")
                },
                SCOPE_NAME: "style-scope"
            },
            SCOPE_NAME = api.SCOPE_NAME,
            SCOPE_DOC_SELECTOR = ":not([" + SCOPE_NAME + "]):not(." + SCOPE_NAME + ")",
            COMPLEX_SELECTOR_SEP = ",",
            SIMPLE_SELECTOR_SEP = /(^|[\s>+~]+)((?:\[.+?\]|[^\s>+~=\[])+)/g,
            SIMPLE_SELECTOR_PREFIX = /[[.:#*]/,
            HOST = ":host",
            ROOT = ":root",
            HOST_PAREN = /(:host)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))/,
            HOST_CONTEXT = ":host-context",
            HOST_CONTEXT_PAREN = /(.*)(?::host-context)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))(.*)/,
            CONTENT = "::content",
            SCOPE_JUMP = /::content|::shadow|\/deep\//,
            CSS_CLASS_PREFIX = ".",
            CSS_ATTR_PREFIX = "[" + SCOPE_NAME + "~=",
            CSS_ATTR_SUFFIX = "]",
            PSEUDO_PREFIX = ":",
            CLASS = "class",
            CONTENT_START = new RegExp("^(" + CONTENT + ")"),
            SELECTOR_NO_MATCH = "should_not_match",
            SLOTTED_PAREN = /(?:::slotted)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))/g;
        return api
    }(), Polymer.StyleExtends = function() {
        var styleUtil = Polymer.StyleUtil;
        return {
            hasExtends: function(cssText) {
                return Boolean(cssText.match(this.rx.EXTEND))
            },
            transform: function(style) {
                var rules = styleUtil.rulesForStyle(style),
                    self = this;
                return styleUtil.forEachRule(rules, function(rule) {
                    if (self._mapRuleOntoParent(rule), rule.parent)
                        for (var m; m = self.rx.EXTEND.exec(rule.cssText);) {
                            var extend = m[1],
                                extendor = self._findExtendor(extend, rule);
                            extendor && self._extendRule(rule, extendor)
                        }
                    rule.cssText = rule.cssText.replace(self.rx.EXTEND, "")
                }), styleUtil.toCssText(rules, function(rule) {
                    rule.selector.match(self.rx.STRIP) && (rule.cssText = "")
                }, !0)
            },
            _mapRuleOntoParent: function(rule) {
                if (rule.parent) {
                    for (var p, map = rule.parent.map || (rule.parent.map = {}), parts = rule.selector.split(","), i = 0; i < parts.length; i++) p = parts[i], map[p.trim()] = rule;
                    return map
                }
            },
            _findExtendor: function(extend, rule) {
                return rule.parent && rule.parent.map && rule.parent.map[extend] || this._findExtendor(extend, rule.parent)
            },
            _extendRule: function(target, source) {
                target.parent !== source.parent && this._cloneAndAddRuleToParent(source, target.parent), target["extends"] = target["extends"] || [], target["extends"].push(source), source.selector = source.selector.replace(this.rx.STRIP, ""), source.selector = (source.selector && source.selector + ",\n") + target.selector, source["extends"] && source["extends"].forEach(function(e) {
                    this._extendRule(target, e)
                }, this)
            },
            _cloneAndAddRuleToParent: function(rule, parent) {
                rule = Object.create(rule), rule.parent = parent, rule["extends"] && (rule["extends"] = rule["extends"].slice()), parent.rules.push(rule)
            },
            rx: {
                EXTEND: /@extends\(([^)]*)\)\s*?;/gim,
                STRIP: /%[^,]*$/
            }
        }
    }(), Polymer.ApplyShim = function() {
        "use strict";

        function mapSet(name, props) {
            name = name.trim(), mixinMap[name] = {
                properties: props,
                dependants: {}
            }
        }

        function mapGet(name) {
            return name = name.trim(), mixinMap[name]
        }

        function replaceInitialOrInherit(property, value) {
            var match = INITIAL_INHERIT.exec(value);
            return match && (value = match[1] ? ApplyShim._getInitialValueForProperty(property) : "apply-shim-inherit"), value
        }

        function cssTextToMap(text) {
            for (var property, value, p, sp, props = text.split(";"), out = {}, i = 0; i < props.length; i++) p = props[i], p && (sp = p.split(":"), sp.length > 1 && (property = sp[0].trim(), value = replaceInitialOrInherit(property, sp.slice(1).join(":")), out[property] = value));
            return out
        }

        function invalidateMixinEntry(mixinEntry) {
            var currentProto = ApplyShim.__currentElementProto,
                currentElementName = currentProto && currentProto.is;
            for (var elementName in mixinEntry.dependants) elementName !== currentElementName && (mixinEntry.dependants[elementName].__applyShimInvalid = !0)
        }

        function produceCssProperties(matchText, propertyName, valueProperty, valueMixin) {
            if (valueProperty && styleUtil.processVariableAndFallback(valueProperty, function(prefix, value) {
                    value && mapGet(value) && (valueMixin = "@apply " + value + ";")
                }), !valueMixin) return matchText;
            var mixinAsProperties = consumeCssProperties(valueMixin),
                prefix = matchText.slice(0, matchText.indexOf("--")),
                mixinValues = cssTextToMap(mixinAsProperties),
                combinedProps = mixinValues,
                mixinEntry = mapGet(propertyName),
                oldProps = mixinEntry && mixinEntry.properties;
            oldProps ? (combinedProps = Object.create(oldProps), combinedProps = Polymer.Base.mixin(combinedProps, mixinValues)) : mapSet(propertyName, combinedProps);
            var p, v, out = [],
                needToInvalidate = !1;
            for (p in combinedProps) v = mixinValues[p], void 0 === v && (v = "initial"), !oldProps || p in oldProps || (needToInvalidate = !0), out.push(propertyName + MIXIN_VAR_SEP + p + ": " + v);
            return needToInvalidate && invalidateMixinEntry(mixinEntry), mixinEntry && (mixinEntry.properties = combinedProps), valueProperty && (prefix = matchText + ";" + prefix), prefix + out.join("; ") + ";"
        }

        function fixVars(matchText, varA, varB) {
            return "var(" + varA + ",var(" + varB + "))"
        }

        function atApplyToCssProperties(mixinName, fallbacks) {
            mixinName = mixinName.replace(APPLY_NAME_CLEAN, "");
            var vars = [],
                mixinEntry = mapGet(mixinName);
            if (mixinEntry || (mapSet(mixinName, {}), mixinEntry = mapGet(mixinName)), mixinEntry) {
                var currentProto = ApplyShim.__currentElementProto;
                currentProto && (mixinEntry.dependants[currentProto.is] = currentProto);
                var p, parts, f;
                for (p in mixinEntry.properties) f = fallbacks && fallbacks[p], parts = [p, ": var(", mixinName, MIXIN_VAR_SEP, p], f && parts.push(",", f), parts.push(")"), vars.push(parts.join(""))
            }
            return vars.join("; ")
        }

        function consumeCssProperties(text) {
            for (var m; m = MIXIN_MATCH.exec(text);) {
                var matchText = m[0],
                    mixinName = m[1],
                    idx = m.index,
                    applyPos = idx + matchText.indexOf("@apply"),
                    afterApplyPos = idx + matchText.length,
                    textBeforeApply = text.slice(0, applyPos),
                    textAfterApply = text.slice(afterApplyPos),
                    defaults = cssTextToMap(textBeforeApply),
                    replacement = atApplyToCssProperties(mixinName, defaults);
                text = [textBeforeApply, replacement, textAfterApply].join(""), MIXIN_MATCH.lastIndex = idx + replacement.length
            }
            return text
        }
        var styleUtil = Polymer.StyleUtil,
            MIXIN_MATCH = styleUtil.rx.MIXIN_MATCH,
            VAR_ASSIGN = styleUtil.rx.VAR_ASSIGN,
            BAD_VAR = /var\(\s*(--[^,]*),\s*(--[^)]*)\)/g,
            APPLY_NAME_CLEAN = /;\s*/m,
            INITIAL_INHERIT = /^\s*(initial)|(inherit)\s*$/,
            MIXIN_VAR_SEP = "_-_",
            mixinMap = {},
            ApplyShim = {
                _measureElement: null,
                _map: mixinMap,
                _separator: MIXIN_VAR_SEP,
                transform: function(styles, elementProto) {
                    this.__currentElementProto = elementProto, styleUtil.forRulesInStyles(styles, this._boundFindDefinitions), styleUtil.forRulesInStyles(styles, this._boundFindApplications), elementProto && (elementProto.__applyShimInvalid = !1), this.__currentElementProto = null
                },
                _findDefinitions: function(rule) {
                    var cssText = rule.parsedCssText;
                    cssText = cssText.replace(BAD_VAR, fixVars), cssText = cssText.replace(VAR_ASSIGN, produceCssProperties), rule.cssText = cssText, ":root" === rule.selector && (rule.selector = ":host > *")
                },
                _findApplications: function(rule) {
                    rule.cssText = consumeCssProperties(rule.cssText)
                },
                transformRule: function(rule) {
                    this._findDefinitions(rule), this._findApplications(rule)
                },
                _getInitialValueForProperty: function(property) {
                    return this._measureElement || (this._measureElement = document.createElement("meta"), this._measureElement.style.all = "initial", document.head.appendChild(this._measureElement)), window.getComputedStyle(this._measureElement).getPropertyValue(property)
                }
            };
        return ApplyShim._boundTransformRule = ApplyShim.transformRule.bind(ApplyShim), ApplyShim._boundFindDefinitions = ApplyShim._findDefinitions.bind(ApplyShim), ApplyShim._boundFindApplications = ApplyShim._findApplications.bind(ApplyShim), ApplyShim
    }(),
    function() {
        var prepElement = Polymer.Base._prepElement,
            nativeShadow = Polymer.Settings.useNativeShadow,
            styleUtil = Polymer.StyleUtil,
            styleTransformer = Polymer.StyleTransformer,
            styleExtends = Polymer.StyleExtends,
            applyShim = Polymer.ApplyShim,
            settings = Polymer.Settings;
        Polymer.Base._addFeature({
            _prepElement: function(element) {
                this._encapsulateStyle && "shady" !== this.__cssBuild && styleTransformer.element(element, this.is, this._scopeCssViaAttr), prepElement.call(this, element)
            },
            _prepStyles: function() {
                void 0 === this._encapsulateStyle && (this._encapsulateStyle = !nativeShadow), nativeShadow || (this._scopeStyle = styleUtil.applyStylePlaceHolder(this.is)), this.__cssBuild = styleUtil.cssBuildTypeForModule(this.is)
            },
            _prepShimStyles: function() {
                if (this._template) {
                    var hasTargetedCssBuild = styleUtil.isTargetedBuild(this.__cssBuild);
                    if (settings.useNativeCSSProperties && "shadow" === this.__cssBuild && hasTargetedCssBuild) return void(settings.preserveStyleIncludes && styleUtil.styleIncludesToTemplate(this._template));
                    this._styles = this._styles || this._collectStyles(), settings.useNativeCSSProperties && !this.__cssBuild && applyShim.transform(this._styles, this);
                    var cssText = settings.useNativeCSSProperties && hasTargetedCssBuild ? this._styles.length && this._styles[0].textContent.trim() : styleTransformer.elementStyles(this);
                    this._prepStyleProperties(), !this._needsStyleProperties() && cssText && styleUtil.applyCss(cssText, this.is, nativeShadow ? this._template.content : null, this._scopeStyle)
                } else this._styles = []
            },
            _collectStyles: function() {
                var styles = [],
                    cssText = "",
                    m$ = this.styleModules;
                if (m$)
                    for (var m, i = 0, l = m$.length; l > i && (m = m$[i]); i++) cssText += styleUtil.cssFromModule(m);
                cssText += styleUtil.cssFromModule(this.is);
                var p = this._template && this._template.parentNode;
                if (!this._template || p && p.id.toLowerCase() === this.is || (cssText += styleUtil.cssFromElement(this._template)), cssText) {
                    var style = document.createElement("style");
                    style.textContent = cssText, styleExtends.hasExtends(style.textContent) && (cssText = styleExtends.transform(style)), styles.push(style)
                }
                return styles
            },
            _elementAdd: function(node) {
                this._encapsulateStyle && (node.__styleScoped ? node.__styleScoped = !1 : styleTransformer.dom(node, this.is, this._scopeCssViaAttr))
            },
            _elementRemove: function(node) {
                this._encapsulateStyle && styleTransformer.dom(node, this.is, this._scopeCssViaAttr, !0)
            },
            scopeSubtree: function(container, shouldObserve) {
                if (!nativeShadow) {
                    var self = this,
                        scopify = function(node) {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                var className = node.getAttribute("class");
                                node.setAttribute("class", self._scopeElementClass(node, className));
                                for (var n, n$ = node.querySelectorAll("*"), i = 0; i < n$.length && (n = n$[i]); i++) className = n.getAttribute("class"), n.setAttribute("class", self._scopeElementClass(n, className))
                            }
                        };
                    if (scopify(container), shouldObserve) {
                        var mo = new MutationObserver(function(mxns) {
                            for (var m, i = 0; i < mxns.length && (m = mxns[i]); i++)
                                if (m.addedNodes)
                                    for (var j = 0; j < m.addedNodes.length; j++) scopify(m.addedNodes[j])
                        });
                        return mo.observe(container, {
                            childList: !0,
                            subtree: !0
                        }), mo
                    }
                }
            }
        })
    }(), Polymer.StyleProperties = function() {
        "use strict";

        function addToBitMask(n, bits) {
            var o = parseInt(n / 32),
                v = 1 << n % 32;
            bits[o] = (bits[o] || 0) | v
        }
        var matchesSelector = Polymer.DomApi.matchesSelector,
            styleUtil = Polymer.StyleUtil,
            styleTransformer = Polymer.StyleTransformer,
            IS_IE = navigator.userAgent.match("Trident"),
            settings = Polymer.Settings;
        return {
            decorateStyles: function(styles, scope) {
                var self = this,
                    props = {},
                    keyframes = [],
                    ruleIndex = 0,
                    scopeSelector = styleTransformer._calcHostScope(scope.is, scope["extends"]);
                styleUtil.forRulesInStyles(styles, function(rule, style) {
                    self.decorateRule(rule), rule.index = ruleIndex++, self.whenHostOrRootRule(scope, rule, style, function(info) {
                        if (rule.parent.type === styleUtil.ruleTypes.MEDIA_RULE && (scope.__notStyleScopeCacheable = !0), info.isHost) {
                            var hostContextOrFunction = info.selector.split(" ").some(function(s) {
                                return 0 === s.indexOf(scopeSelector) && s.length !== scopeSelector.length
                            });
                            scope.__notStyleScopeCacheable = scope.__notStyleScopeCacheable || hostContextOrFunction
                        }
                    }), self.collectPropertiesInCssText(rule.propertyInfo.cssText, props)
                }, function(rule) {
                    keyframes.push(rule)
                }), styles._keyframes = keyframes;
                var names = [];
                for (var i in props) names.push(i);
                return names
            },
            decorateRule: function(rule) {
                if (rule.propertyInfo) return rule.propertyInfo;
                var info = {},
                    properties = {},
                    hasProperties = this.collectProperties(rule, properties);
                return hasProperties && (info.properties = properties, rule.rules = null), info.cssText = this.collectCssText(rule), rule.propertyInfo = info, info
            },
            collectProperties: function(rule, properties) {
                var info = rule.propertyInfo;
                if (!info) {
                    for (var m, value, any, rx = this.rx.VAR_ASSIGN, cssText = rule.parsedCssText; m = rx.exec(cssText);) value = (m[2] || m[3]).trim(), "inherit" !== value && (properties[m[1].trim()] = value), any = !0;
                    return any
                }
                return info.properties ? (Polymer.Base.mixin(properties, info.properties), !0) : void 0
            },
            collectCssText: function(rule) {
                return this.collectConsumingCssText(rule.parsedCssText)
            },
            collectConsumingCssText: function(cssText) {
                return cssText.replace(this.rx.BRACKETED, "").replace(this.rx.VAR_ASSIGN, "")
            },
            collectPropertiesInCssText: function(cssText, props) {
                for (var m; m = this.rx.VAR_CONSUMED.exec(cssText);) {
                    var name = m[1];
                    ":" !== m[2] && (props[name] = !0)
                }
            },
            reify: function(props) {
                for (var n, names = Object.getOwnPropertyNames(props), i = 0; i < names.length; i++) n = names[i], props[n] = this.valueForProperty(props[n], props)
            },
            valueForProperty: function(property, props) {
                if (property)
                    if (property.indexOf(";") >= 0) property = this.valueForProperties(property, props);
                    else {
                        var self = this,
                            fn = function(prefix, value, fallback, suffix) {
                                var propertyValue = self.valueForProperty(props[value], props);
                                return propertyValue && "initial" !== propertyValue ? "apply-shim-inherit" === propertyValue && (propertyValue = "inherit") : propertyValue = self.valueForProperty(props[fallback] || fallback, props) || fallback, prefix + (propertyValue || "") + suffix
                            };
                        property = styleUtil.processVariableAndFallback(property, fn)
                    }
                return property && property.trim() || ""
            },
            valueForProperties: function(property, props) {
                for (var p, m, parts = property.split(";"), i = 0; i < parts.length; i++)
                    if (p = parts[i]) {
                        if (this.rx.MIXIN_MATCH.lastIndex = 0, m = this.rx.MIXIN_MATCH.exec(p)) p = this.valueForProperty(props[m[1]], props);
                        else {
                            var colon = p.indexOf(":");
                            if (-1 !== colon) {
                                var pp = p.substring(colon);
                                pp = pp.trim(), pp = this.valueForProperty(pp, props) || pp, p = p.substring(0, colon) + pp
                            }
                        }
                        parts[i] = p && p.lastIndexOf(";") === p.length - 1 ? p.slice(0, -1) : p || ""
                    }
                return parts.join(";")
            },
            applyProperties: function(rule, props) {
                var output = "";
                rule.propertyInfo || this.decorateRule(rule), rule.propertyInfo.cssText && (output = this.valueForProperties(rule.propertyInfo.cssText, props)), rule.cssText = output
            },
            applyKeyframeTransforms: function(rule, keyframeTransforms) {
                var input = rule.cssText,
                    output = rule.cssText;
                if (null == rule.hasAnimations && (rule.hasAnimations = this.rx.ANIMATION_MATCH.test(input)), rule.hasAnimations) {
                    var transform;
                    if (null == rule.keyframeNamesToTransform) {
                        rule.keyframeNamesToTransform = [];
                        for (var keyframe in keyframeTransforms) transform = keyframeTransforms[keyframe], output = transform(input), input !== output && (input = output, rule.keyframeNamesToTransform.push(keyframe))
                    } else {
                        for (var i = 0; i < rule.keyframeNamesToTransform.length; ++i) transform = keyframeTransforms[rule.keyframeNamesToTransform[i]], input = transform(input);
                        output = input
                    }
                }
                rule.cssText = output
            },
            propertyDataFromStyles: function(styles, element) {
                var props = {},
                    self = this,
                    o = [];
                return styleUtil.forActiveRulesInStyles(styles, function(rule) {
                    rule.propertyInfo || self.decorateRule(rule);
                    var selectorToMatch = rule.transformedSelector || rule.parsedSelector;
                    element && rule.propertyInfo.properties && selectorToMatch && matchesSelector.call(element, selectorToMatch) && (self.collectProperties(rule, props), addToBitMask(rule.index, o))
                }), {
                    properties: props,
                    key: o
                }
            },
            _rootSelector: /:root|:host\s*>\s*\*/,
            _checkRoot: function(hostScope, selector) {
                return Boolean(selector.match(this._rootSelector)) || "html" === hostScope && selector.indexOf("html") > -1
            },
            whenHostOrRootRule: function(scope, rule, style, callback) {
                if (rule.propertyInfo || self.decorateRule(rule), rule.propertyInfo.properties) {
                    var hostScope = scope.is ? styleTransformer._calcHostScope(scope.is, scope["extends"]) : "html",
                        parsedSelector = rule.parsedSelector,
                        isRoot = this._checkRoot(hostScope, parsedSelector),
                        isHost = !isRoot && 0 === parsedSelector.indexOf(":host"),
                        cssBuild = scope.__cssBuild || style.__cssBuild;
                    if ("shady" === cssBuild && (isRoot = parsedSelector === hostScope + " > *." + hostScope || parsedSelector.indexOf("html") > -1, isHost = !isRoot && 0 === parsedSelector.indexOf(hostScope)), isRoot || isHost) {
                        var selectorToMatch = hostScope;
                        isHost && (settings.useNativeShadow && !rule.transformedSelector && (rule.transformedSelector = styleTransformer._transformRuleCss(rule, styleTransformer._transformComplexSelector, scope.is, hostScope)), selectorToMatch = rule.transformedSelector || rule.parsedSelector), isRoot && "html" === hostScope && (selectorToMatch = rule.transformedSelector || rule.parsedSelector), callback({
                            selector: selectorToMatch,
                            isHost: isHost,
                            isRoot: isRoot
                        })
                    }
                }
            },
            hostAndRootPropertiesForScope: function(scope) {
                var hostProps = {},
                    rootProps = {},
                    self = this;
                return styleUtil.forActiveRulesInStyles(scope._styles, function(rule, style) {
                    self.whenHostOrRootRule(scope, rule, style, function(info) {
                        var element = scope._element || scope;
                        matchesSelector.call(element, info.selector) && (info.isHost ? self.collectProperties(rule, hostProps) : self.collectProperties(rule, rootProps))
                    })
                }), {
                    rootProps: rootProps,
                    hostProps: hostProps
                }
            },
            transformStyles: function(element, properties, scopeSelector) {
                var self = this,
                    hostSelector = styleTransformer._calcHostScope(element.is, element["extends"]),
                    rxHostSelector = element["extends"] ? "\\" + hostSelector.slice(0, -1) + "\\]" : hostSelector,
                    hostRx = new RegExp(this.rx.HOST_PREFIX + rxHostSelector + this.rx.HOST_SUFFIX),
                    keyframeTransforms = this._elementKeyframeTransforms(element, scopeSelector);
                return styleTransformer.elementStyles(element, function(rule) {
                    self.applyProperties(rule, properties), settings.useNativeShadow || Polymer.StyleUtil.isKeyframesSelector(rule) || !rule.cssText || (self.applyKeyframeTransforms(rule, keyframeTransforms), self._scopeSelector(rule, hostRx, hostSelector, element._scopeCssViaAttr, scopeSelector))
                })
            },
            _elementKeyframeTransforms: function(element, scopeSelector) {
                var keyframesRules = element._styles._keyframes,
                    keyframeTransforms = {};
                if (!settings.useNativeShadow && keyframesRules)
                    for (var i = 0, keyframesRule = keyframesRules[i]; i < keyframesRules.length; keyframesRule = keyframesRules[++i]) this._scopeKeyframes(keyframesRule, scopeSelector), keyframeTransforms[keyframesRule.keyframesName] = this._keyframesRuleTransformer(keyframesRule);
                return keyframeTransforms
            },
            _keyframesRuleTransformer: function(keyframesRule) {
                return function(cssText) {
                    return cssText.replace(keyframesRule.keyframesNameRx, keyframesRule.transformedKeyframesName)
                }
            },
            _scopeKeyframes: function(rule, scopeId) {
                rule.keyframesNameRx = new RegExp(rule.keyframesName, "g"), rule.transformedKeyframesName = rule.keyframesName + "-" + scopeId, rule.transformedSelector = rule.transformedSelector || rule.selector, rule.selector = rule.transformedSelector.replace(rule.keyframesName, rule.transformedKeyframesName)
            },
            _scopeSelector: function(rule, hostRx, hostSelector, viaAttr, scopeId) {
                rule.transformedSelector = rule.transformedSelector || rule.selector;
                for (var p, selector = rule.transformedSelector, scope = viaAttr ? "[" + styleTransformer.SCOPE_NAME + "~=" + scopeId + "]" : "." + scopeId, parts = selector.split(","), i = 0, l = parts.length; l > i && (p = parts[i]); i++) parts[i] = p.match(hostRx) ? p.replace(hostSelector, scope) : scope + " " + p;
                rule.selector = parts.join(",")
            },
            applyElementScopeSelector: function(element, selector, old, viaAttr) {
                var c = viaAttr ? element.getAttribute(styleTransformer.SCOPE_NAME) : element.getAttribute("class") || "",
                    v = old ? c.replace(old, selector) : (c ? c + " " : "") + this.XSCOPE_NAME + " " + selector;
                c !== v && (viaAttr ? element.setAttribute(styleTransformer.SCOPE_NAME, v) : element.setAttribute("class", v))
            },
            applyElementStyle: function(element, properties, selector, style) {
                var cssText = style ? style.textContent || "" : this.transformStyles(element, properties, selector),
                    s = element._customStyle;
                return s && !settings.useNativeShadow && s !== style && (s._useCount--, s._useCount <= 0 && s.parentNode && s.parentNode.removeChild(s)), settings.useNativeShadow ? element._customStyle ? (element._customStyle.textContent = cssText, style = element._customStyle) : cssText && (style = styleUtil.applyCss(cssText, selector, element.root, element._scopeStyle)) : style ? style.parentNode || (IS_IE && cssText.indexOf("@media") > -1 && (style.textContent = cssText), styleUtil.applyStyle(style, null, element._scopeStyle)) : cssText && (style = styleUtil.applyCss(cssText, selector, null, element._scopeStyle)), style && (style._useCount = style._useCount || 0, element._customStyle != style && style._useCount++, element._customStyle = style), style
            },
            mixinCustomStyle: function(props, customStyle) {
                var v;
                for (var i in customStyle) v = customStyle[i], (v || 0 === v) && (props[i] = v)
            },
            updateNativeStyleProperties: function(element, properties) {
                var oldPropertyNames = element.__customStyleProperties;
                if (oldPropertyNames)
                    for (var i = 0; i < oldPropertyNames.length; i++) element.style.removeProperty(oldPropertyNames[i]);
                var propertyNames = [];
                for (var p in properties) null !== properties[p] && (element.style.setProperty(p, properties[p]), propertyNames.push(p));
                element.__customStyleProperties = propertyNames
            },
            rx: styleUtil.rx,
            XSCOPE_NAME: "x-scope"
        }
    }(),
    function() {
        Polymer.StyleCache = function() {
            this.cache = {}
        }, Polymer.StyleCache.prototype = {
            MAX: 100,
            store: function(is, data, keyValues, keyStyles) {
                data.keyValues = keyValues, data.styles = keyStyles;
                var s$ = this.cache[is] = this.cache[is] || [];
                s$.push(data), s$.length > this.MAX && s$.shift()
            },
            retrieve: function(is, keyValues, keyStyles) {
                var cache = this.cache[is];
                if (cache)
                    for (var data, i = cache.length - 1; i >= 0; i--)
                        if (data = cache[i], keyStyles === data.styles && this._objectsEqual(keyValues, data.keyValues)) return data
            },
            clear: function() {
                this.cache = {}
            },
            _objectsEqual: function(target, source) {
                var t, s;
                for (var i in target)
                    if (t = target[i], s = source[i], !("object" == typeof t && t ? this._objectsStrictlyEqual(t, s) : t === s)) return !1;
                return Array.isArray(target) ? target.length === source.length : !0
            },
            _objectsStrictlyEqual: function(target, source) {
                return this._objectsEqual(target, source) && this._objectsEqual(source, target)
            }
        }
    }(), Polymer.StyleDefaults = function() {
        var styleProperties = Polymer.StyleProperties,
            StyleCache = Polymer.StyleCache,
            nativeVariables = Polymer.Settings.useNativeCSSProperties,
            api = {
                _styles: [],
                _properties: null,
                customStyle: {},
                _styleCache: new StyleCache,
                _element: Polymer.DomApi.wrap(document.documentElement),
                addStyle: function(style) {
                    this._styles.push(style), this._properties = null
                },
                get _styleProperties() {
                    return this._properties || (styleProperties.decorateStyles(this._styles, this), this._styles._scopeStyleProperties = null, this._properties = styleProperties.hostAndRootPropertiesForScope(this).rootProps, styleProperties.mixinCustomStyle(this._properties, this.customStyle), styleProperties.reify(this._properties)), this._properties
                },
                hasStyleProperties: function() {
                    return Boolean(this._properties)
                },
                _needsStyleProperties: function() {},
                _computeStyleProperties: function() {
                    return this._styleProperties
                },
                updateStyles: function(properties) {
                    this._properties = null, properties && Polymer.Base.mixin(this.customStyle, properties), this._styleCache.clear();
                    for (var s, i = 0; i < this._styles.length; i++) s = this._styles[i], s = s.__importElement || s, s._apply();
                    nativeVariables && styleProperties.updateNativeStyleProperties(document.documentElement, this.customStyle)
                }
            };
        return api
    }(),
    function() {
        "use strict";
        var serializeValueToAttribute = Polymer.Base.serializeValueToAttribute,
            propertyUtils = Polymer.StyleProperties,
            styleTransformer = Polymer.StyleTransformer,
            styleDefaults = Polymer.StyleDefaults,
            nativeShadow = Polymer.Settings.useNativeShadow,
            nativeVariables = Polymer.Settings.useNativeCSSProperties;
        Polymer.Base._addFeature({
            _prepStyleProperties: function() {
                nativeVariables || (this._ownStylePropertyNames = this._styles && this._styles.length ? propertyUtils.decorateStyles(this._styles, this) : null)
            },
            customStyle: null,
            getComputedStyleValue: function(property) {
                return nativeVariables || this._styleProperties || this._computeStyleProperties(), !nativeVariables && this._styleProperties && this._styleProperties[property] || getComputedStyle(this).getPropertyValue(property)
            },
            _setupStyleProperties: function() {
                this.customStyle = {}, this._styleCache = null, this._styleProperties = null, this._scopeSelector = null, this._ownStyleProperties = null, this._customStyle = null
            },
            _needsStyleProperties: function() {
                return Boolean(!nativeVariables && this._ownStylePropertyNames && this._ownStylePropertyNames.length)
            },
            _validateApplyShim: function() {
                if (this.__applyShimInvalid) {
                    Polymer.ApplyShim.transform(this._styles, this.__proto__);
                    var cssText = styleTransformer.elementStyles(this);
                    if (nativeShadow) {
                        var templateStyle = this._template.content.querySelector("style");
                        templateStyle && (templateStyle.textContent = cssText)
                    } else {
                        var shadyStyle = this._scopeStyle && this._scopeStyle.nextSibling;
                        shadyStyle && (shadyStyle.textContent = cssText)
                    }
                }
            },
            _beforeAttached: function() {
                this._scopeSelector && !this.__stylePropertiesInvalid || !this._needsStyleProperties() || (this.__stylePropertiesInvalid = !1, this._updateStyleProperties())
            },
            _findStyleHost: function() {
                for (var root, e = this; root = Polymer.dom(e).getOwnerRoot();) {
                    if (Polymer.isInstance(root.host)) return root.host;
                    e = root.host
                }
                return styleDefaults
            },
            _updateStyleProperties: function() {
                var info, scope = this._findStyleHost();
                scope._styleProperties || scope._computeStyleProperties(), scope._styleCache || (scope._styleCache = new Polymer.StyleCache);
                var scopeData = propertyUtils.propertyDataFromStyles(scope._styles, this),
                    scopeCacheable = !this.__notStyleScopeCacheable;
                scopeCacheable && (scopeData.key.customStyle = this.customStyle, info = scope._styleCache.retrieve(this.is, scopeData.key, this._styles));
                var scopeCached = Boolean(info);
                scopeCached ? this._styleProperties = info._styleProperties : this._computeStyleProperties(scopeData.properties), this._computeOwnStyleProperties(), scopeCached || (info = styleCache.retrieve(this.is, this._ownStyleProperties, this._styles));
                var globalCached = Boolean(info) && !scopeCached,
                    style = this._applyStyleProperties(info);
                scopeCached || (style = style && nativeShadow ? style.cloneNode(!0) : style, info = {
                    style: style,
                    _scopeSelector: this._scopeSelector,
                    _styleProperties: this._styleProperties
                }, scopeCacheable && (scopeData.key.customStyle = {}, this.mixin(scopeData.key.customStyle, this.customStyle), scope._styleCache.store(this.is, info, scopeData.key, this._styles)), globalCached || styleCache.store(this.is, Object.create(info), this._ownStyleProperties, this._styles))
            },
            _computeStyleProperties: function(scopeProps) {
                var scope = this._findStyleHost();
                scope._styleProperties || scope._computeStyleProperties();
                var props = Object.create(scope._styleProperties),
                    hostAndRootProps = propertyUtils.hostAndRootPropertiesForScope(this);
                this.mixin(props, hostAndRootProps.hostProps), scopeProps = scopeProps || propertyUtils.propertyDataFromStyles(scope._styles, this).properties, this.mixin(props, scopeProps), this.mixin(props, hostAndRootProps.rootProps), propertyUtils.mixinCustomStyle(props, this.customStyle), propertyUtils.reify(props), this._styleProperties = props
            },
            _computeOwnStyleProperties: function() {
                for (var n, props = {}, i = 0; i < this._ownStylePropertyNames.length; i++) n = this._ownStylePropertyNames[i], props[n] = this._styleProperties[n];
                this._ownStyleProperties = props
            },
            _scopeCount: 0,
            _applyStyleProperties: function(info) {
                var oldScopeSelector = this._scopeSelector;
                this._scopeSelector = info ? info._scopeSelector : this.is + "-" + this.__proto__._scopeCount++;
                var style = propertyUtils.applyElementStyle(this, this._styleProperties, this._scopeSelector, info && info.style);
                return nativeShadow || propertyUtils.applyElementScopeSelector(this, this._scopeSelector, oldScopeSelector, this._scopeCssViaAttr), style
            },
            serializeValueToAttribute: function(value, attribute, node) {
                if (node = node || this, "class" === attribute && !nativeShadow) {
                    var host = node === this ? this.domHost || this.dataHost : this;
                    host && (value = host._scopeElementClass(node, value))
                }
                node = this.shadyRoot && this.shadyRoot._hasDistributed ? Polymer.dom(node) : node, serializeValueToAttribute.call(this, value, attribute, node)
            },
            _scopeElementClass: function(element, selector) {
                return nativeShadow || this._scopeCssViaAttr || (selector = (selector ? selector + " " : "") + SCOPE_NAME + " " + this.is + (element._scopeSelector ? " " + XSCOPE_NAME + " " + element._scopeSelector : "")), selector
            },
            updateStyles: function(properties) {
                properties && this.mixin(this.customStyle, properties), nativeVariables ? propertyUtils.updateNativeStyleProperties(this, this.customStyle) : (this.isAttached ? this._needsStyleProperties() ? this._updateStyleProperties() : this._styleProperties = null : this.__stylePropertiesInvalid = !0, this._styleCache && this._styleCache.clear(), this._updateRootStyles())
            },
            _updateRootStyles: function(root) {
                root = root || this.root;
                for (var c, c$ = Polymer.dom(root)._query(function(e) {
                        return e.shadyRoot || e.shadowRoot
                    }), i = 0, l = c$.length; l > i && (c = c$[i]); i++) c.updateStyles && c.updateStyles()
            }
        }), Polymer.updateStyles = function(properties) {
            styleDefaults.updateStyles(properties), Polymer.Base._updateRootStyles(document)
        };
        var styleCache = new Polymer.StyleCache;
        Polymer.customStyleCache = styleCache;
        var SCOPE_NAME = styleTransformer.SCOPE_NAME,
            XSCOPE_NAME = propertyUtils.XSCOPE_NAME
    }(), Polymer.Base._addFeature({
        _registerFeatures: function() {
            this._prepIs(), this.factoryImpl && this._prepConstructor(), this._prepStyles()
        },
        _finishRegisterFeatures: function() {
            this._prepTemplate(), this._prepShimStyles(), this._prepAnnotations(), this._prepEffects(), this._prepBehaviors(), this._prepPropertyInfo(), this._prepBindings(), this._prepShady()
        },
        _prepBehavior: function(b) {
            this._addPropertyEffects(b.properties), this._addComplexObserverEffects(b.observers), this._addHostAttributes(b.hostAttributes)
        },
        _initFeatures: function() {
            this._setupGestures(), this._setupConfigure(this.__data__), this._setupStyleProperties(), this._setupDebouncers(), this._setupShady(), this._registerHost(), this._template && (this._validateApplyShim(), this._poolContent(), this._beginHosting(), this._stampTemplate(), this._endHosting(), this._marshalAnnotationReferences()), this._marshalInstanceEffects(), this._marshalBehaviors(), this._marshalHostAttributes(), this._marshalAttributes(), this._tryReady()
        },
        _marshalBehavior: function(b) {
            b.listeners && this._listenListeners(b.listeners)
        }
    }),
    function() {
        var updateDebouncer, propertyUtils = Polymer.StyleProperties,
            styleUtil = Polymer.StyleUtil,
            cssParse = Polymer.CssParse,
            styleDefaults = Polymer.StyleDefaults,
            styleTransformer = Polymer.StyleTransformer,
            applyShim = Polymer.ApplyShim,
            debounce = Polymer.Debounce,
            settings = Polymer.Settings;
        Polymer({
            is: "custom-style",
            "extends": "style",
            _template: null,
            properties: {
                include: String
            },
            ready: function() {
                this.__appliedElement = this.__appliedElement || this, this.__cssBuild = styleUtil.getCssBuildType(this), this.__appliedElement !== this && (this.__appliedElement.__cssBuild = this.__cssBuild), this._tryApply()
            },
            attached: function() {
                this._tryApply()
            },
            _tryApply: function() {
                if (!this._appliesToDocument && this.parentNode && "dom-module" !== this.parentNode.localName) {
                    this._appliesToDocument = !0;
                    var e = this.__appliedElement;
                    if (settings.useNativeCSSProperties || (this.__needsUpdateStyles = styleDefaults.hasStyleProperties(), styleDefaults.addStyle(e)), e.textContent || this.include) this._apply(!0);
                    else {
                        var self = this,
                            observer = new MutationObserver(function() {
                                observer.disconnect(), self._apply(!0)
                            });
                        observer.observe(e, {
                            childList: !0
                        })
                    }
                }
            },
            _updateStyles: function() {
                Polymer.updateStyles()
            },
            _apply: function(initialApply) {
                var e = this.__appliedElement;
                if (this.include && (e.textContent = styleUtil.cssFromModules(this.include, !0) + e.textContent), e.textContent) {
                    var buildType = this.__cssBuild,
                        targetedBuild = styleUtil.isTargetedBuild(buildType);
                    if (!settings.useNativeCSSProperties || !targetedBuild) {
                        var styleRules = styleUtil.rulesForStyle(e);
                        if (targetedBuild || (styleUtil.forEachRule(styleRules, function(rule) {
                                styleTransformer.documentRule(rule)
                            }), settings.useNativeCSSProperties && !buildType && applyShim.transform([e])), settings.useNativeCSSProperties) e.textContent = styleUtil.toCssText(styleRules);
                        else {
                            var self = this,
                                fn = function() {
                                    self._flushCustomProperties()
                                };
                            initialApply ? Polymer.RenderStatus.whenReady(fn) : fn()
                        }
                    }
                }
            },
            _flushCustomProperties: function() {
                this.__needsUpdateStyles ? (this.__needsUpdateStyles = !1,
                    updateDebouncer = debounce(updateDebouncer, this._updateStyles)) : this._applyCustomProperties()
            },
            _applyCustomProperties: function() {
                var element = this.__appliedElement;
                this._computeStyleProperties();
                var props = this._styleProperties,
                    rules = styleUtil.rulesForStyle(element);
                rules && (element.textContent = styleUtil.toCssText(rules, function(rule) {
                    var css = rule.cssText = rule.parsedCssText;
                    rule.propertyInfo && rule.propertyInfo.cssText && (css = cssParse.removeCustomPropAssignment(css), rule.cssText = propertyUtils.valueForProperties(css, props))
                }))
            }
        })
    }(), Polymer.Templatizer = {
        properties: {
            __hideTemplateChildren__: {
                observer: "_showHideChildren"
            }
        },
        _instanceProps: Polymer.nob,
        _parentPropPrefix: "_parent_",
        templatize: function(template) {
            if (this._templatized = template, template._content || (template._content = template.content), template._content._ctor) return this.ctor = template._content._ctor, void this._prepParentProperties(this.ctor.prototype, template);
            var archetype = Object.create(Polymer.Base);
            this._customPrepAnnotations(archetype, template), this._prepParentProperties(archetype, template), archetype._prepEffects(), this._customPrepEffects(archetype), archetype._prepBehaviors(), archetype._prepPropertyInfo(), archetype._prepBindings(), archetype._notifyPathUp = this._notifyPathUpImpl, archetype._scopeElementClass = this._scopeElementClassImpl, archetype.listen = this._listenImpl, archetype._showHideChildren = this._showHideChildrenImpl, archetype.__setPropertyOrig = this.__setProperty, archetype.__setProperty = this.__setPropertyImpl;
            var _constructor = this._constructorImpl,
                ctor = function(model, host) {
                    _constructor.call(this, model, host)
                };
            ctor.prototype = archetype, archetype.constructor = ctor, template._content._ctor = ctor, this.ctor = ctor
        },
        _getRootDataHost: function() {
            return this.dataHost && this.dataHost._rootDataHost || this.dataHost
        },
        _showHideChildrenImpl: function(hide) {
            for (var c = this._children, i = 0; i < c.length; i++) {
                var n = c[i];
                Boolean(hide) != Boolean(n.__hideTemplateChildren__) && (n.nodeType === Node.TEXT_NODE ? hide ? (n.__polymerTextContent__ = n.textContent, n.textContent = "") : n.textContent = n.__polymerTextContent__ : n.style && (hide ? (n.__polymerDisplay__ = n.style.display, n.style.display = "none") : n.style.display = n.__polymerDisplay__)), n.__hideTemplateChildren__ = hide
            }
        },
        __setPropertyImpl: function(property, value, fromAbove, node) {
            node && node.__hideTemplateChildren__ && "textContent" == property && (property = "__polymerTextContent__"), this.__setPropertyOrig(property, value, fromAbove, node)
        },
        _debounceTemplate: function(fn) {
            Polymer.dom.addDebouncer(this.debounce("_debounceTemplate", fn))
        },
        _flushTemplates: function() {
            Polymer.dom.flush()
        },
        _customPrepEffects: function(archetype) {
            var parentProps = archetype._parentProps;
            for (var prop in parentProps) archetype._addPropertyEffect(prop, "function", this._createHostPropEffector(prop));
            for (prop in this._instanceProps) archetype._addPropertyEffect(prop, "function", this._createInstancePropEffector(prop))
        },
        _customPrepAnnotations: function(archetype, template) {
            archetype._template = template;
            var c = template._content;
            if (!c._notes) {
                var rootDataHost = archetype._rootDataHost;
                rootDataHost && (Polymer.Annotations.prepElement = function() {
                    rootDataHost._prepElement()
                }), c._notes = Polymer.Annotations.parseAnnotations(template), Polymer.Annotations.prepElement = null, this._processAnnotations(c._notes)
            }
            archetype._notes = c._notes, archetype._parentProps = c._parentProps
        },
        _prepParentProperties: function(archetype, template) {
            var parentProps = this._parentProps = archetype._parentProps;
            if (this._forwardParentProp && parentProps) {
                var prop, proto = archetype._parentPropProto;
                if (!proto) {
                    for (prop in this._instanceProps) delete parentProps[prop];
                    proto = archetype._parentPropProto = Object.create(null), template != this && (Polymer.Bind.prepareModel(proto), Polymer.Base.prepareModelNotifyPath(proto));
                    for (prop in parentProps) {
                        var parentProp = this._parentPropPrefix + prop,
                            effects = [{
                                kind: "function",
                                effect: this._createForwardPropEffector(prop),
                                fn: Polymer.Bind._functionEffect
                            }, {
                                kind: "notify",
                                fn: Polymer.Bind._notifyEffect,
                                effect: {
                                    event: Polymer.CaseMap.camelToDashCase(parentProp) + "-changed"
                                }
                            }];
                        proto._propertyEffects = proto._propertyEffects || {}, proto._propertyEffects[parentProp] = effects, Polymer.Bind._createAccessors(proto, parentProp, effects)
                    }
                }
                var self = this;
                template != this && (Polymer.Bind.prepareInstance(template), template._forwardParentProp = function(source, value) {
                    self._forwardParentProp(source, value)
                }), this._extendTemplate(template, proto), template._pathEffector = function(path, value, fromAbove) {
                    return self._pathEffectorImpl(path, value, fromAbove)
                }
            }
        },
        _createForwardPropEffector: function(prop) {
            return function(source, value) {
                this._forwardParentProp(prop, value)
            }
        },
        _createHostPropEffector: function(prop) {
            var prefix = this._parentPropPrefix;
            return function(source, value) {
                this.dataHost._templatized[prefix + prop] = value
            }
        },
        _createInstancePropEffector: function(prop) {
            return function(source, value, old, fromAbove) {
                fromAbove || this.dataHost._forwardInstanceProp(this, prop, value)
            }
        },
        _extendTemplate: function(template, proto) {
            var n$ = Object.getOwnPropertyNames(proto);
            proto._propertySetter && (template._propertySetter = proto._propertySetter);
            for (var n, i = 0; i < n$.length && (n = n$[i]); i++) {
                var val = template[n];
                if (val && "_propertyEffects" == n) {
                    var pe = Polymer.Base.mixin({}, val);
                    template._propertyEffects = Polymer.Base.mixin(pe, proto._propertyEffects)
                } else {
                    var pd = Object.getOwnPropertyDescriptor(proto, n);
                    Object.defineProperty(template, n, pd), void 0 !== val && template._propertySetter(n, val)
                }
            }
        },
        _showHideChildren: function() {},
        _forwardInstancePath: function() {},
        _forwardInstanceProp: function() {},
        _notifyPathUpImpl: function(path, value) {
            var dataHost = this.dataHost,
                root = Polymer.Path.root(path);
            dataHost._forwardInstancePath.call(dataHost, this, path, value), root in dataHost._parentProps && dataHost._templatized._notifyPath(dataHost._parentPropPrefix + path, value)
        },
        _pathEffectorImpl: function(path, value, fromAbove) {
            if (this._forwardParentPath && 0 === path.indexOf(this._parentPropPrefix)) {
                var subPath = path.substring(this._parentPropPrefix.length),
                    model = Polymer.Path.root(subPath);
                model in this._parentProps && this._forwardParentPath(subPath, value)
            }
            Polymer.Base._pathEffector.call(this._templatized, path, value, fromAbove)
        },
        _constructorImpl: function(model, host) {
            this._rootDataHost = host._getRootDataHost(), this._setupConfigure(model), this._registerHost(host), this._beginHosting(), this.root = this.instanceTemplate(this._template), this.root.__noContent = !this._notes._hasContent, this.root.__styleScoped = !0, this._endHosting(), this._marshalAnnotatedNodes(), this._marshalInstanceEffects(), this._marshalAnnotatedListeners();
            for (var children = [], n = this.root.firstChild; n; n = n.nextSibling) children.push(n), n._templateInstance = this;
            this._children = children, host.__hideTemplateChildren__ && this._showHideChildren(!0), this._tryReady()
        },
        _listenImpl: function(node, eventName, methodName) {
            var model = this,
                host = this._rootDataHost,
                handler = host._createEventHandler(node, eventName, methodName),
                decorated = function(e) {
                    e.model = model, handler(e)
                };
            host._listen(node, eventName, decorated)
        },
        _scopeElementClassImpl: function(node, value) {
            var host = this._rootDataHost;
            return host ? host._scopeElementClass(node, value) : value
        },
        stamp: function(model) {
            if (model = model || {}, this._parentProps) {
                var templatized = this._templatized;
                for (var prop in this._parentProps) void 0 === model[prop] && (model[prop] = templatized[this._parentPropPrefix + prop])
            }
            return new this.ctor(model, this)
        },
        modelForElement: function(el) {
            for (var model; el;)
                if (model = el._templateInstance) {
                    if (model.dataHost == this) return model;
                    el = model.dataHost
                } else el = el.parentNode
        }
    }, Polymer({
        is: "dom-template",
        "extends": "template",
        _template: null,
        behaviors: [Polymer.Templatizer],
        ready: function() {
            this.templatize(this)
        }
    }), Polymer._collections = new WeakMap, Polymer.Collection = function(userArray) {
        Polymer._collections.set(userArray, this), this.userArray = userArray, this.store = userArray.slice(), this.initMap()
    }, Polymer.Collection.prototype = {
        constructor: Polymer.Collection,
        initMap: function() {
            for (var omap = this.omap = new WeakMap, pmap = this.pmap = {}, s = this.store, i = 0; i < s.length; i++) {
                var item = s[i];
                item && "object" == typeof item ? omap.set(item, i) : pmap[item] = i
            }
        },
        add: function(item) {
            var key = this.store.push(item) - 1;
            return item && "object" == typeof item ? this.omap.set(item, key) : this.pmap[item] = key, "#" + key
        },
        removeKey: function(key) {
            (key = this._parseKey(key)) && (this._removeFromMap(this.store[key]), delete this.store[key])
        },
        _removeFromMap: function(item) {
            item && "object" == typeof item ? this.omap["delete"](item) : delete this.pmap[item]
        },
        remove: function(item) {
            var key = this.getKey(item);
            return this.removeKey(key), key
        },
        getKey: function(item) {
            var key;
            return key = item && "object" == typeof item ? this.omap.get(item) : this.pmap[item], void 0 != key ? "#" + key : void 0
        },
        getKeys: function() {
            return Object.keys(this.store).map(function(key) {
                return "#" + key
            })
        },
        _parseKey: function(key) {
            return key && "#" == key[0] ? key.slice(1) : void 0
        },
        setItem: function(key, item) {
            if (key = this._parseKey(key)) {
                var old = this.store[key];
                old && this._removeFromMap(old), item && "object" == typeof item ? this.omap.set(item, key) : this.pmap[item] = key, this.store[key] = item
            }
        },
        getItem: function(key) {
            return (key = this._parseKey(key)) ? this.store[key] : void 0
        },
        getItems: function() {
            var items = [],
                store = this.store;
            for (var key in store) items.push(store[key]);
            return items
        },
        _applySplices: function(splices) {
            for (var key, s, keyMap = {}, i = 0; i < splices.length && (s = splices[i]); i++) {
                s.addedKeys = [];
                for (var j = 0; j < s.removed.length; j++) key = this.getKey(s.removed[j]), keyMap[key] = keyMap[key] ? null : -1;
                for (j = 0; j < s.addedCount; j++) {
                    var item = this.userArray[s.index + j];
                    key = this.getKey(item), key = void 0 === key ? this.add(item) : key, keyMap[key] = keyMap[key] ? null : 1, s.addedKeys.push(key)
                }
            }
            var removed = [],
                added = [];
            for (key in keyMap) keyMap[key] < 0 && (this.removeKey(key), removed.push(key)), keyMap[key] > 0 && added.push(key);
            return [{
                removed: removed,
                added: added
            }]
        }
    }, Polymer.Collection.get = function(userArray) {
        return Polymer._collections.get(userArray) || new Polymer.Collection(userArray)
    }, Polymer.Collection.applySplices = function(userArray, splices) {
        var coll = Polymer._collections.get(userArray);
        return coll ? coll._applySplices(splices) : null
    }, Polymer({
        is: "dom-repeat",
        "extends": "template",
        _template: null,
        properties: {
            items: {
                type: Array
            },
            as: {
                type: String,
                value: "item"
            },
            indexAs: {
                type: String,
                value: "index"
            },
            sort: {
                type: Function,
                observer: "_sortChanged"
            },
            filter: {
                type: Function,
                observer: "_filterChanged"
            },
            observe: {
                type: String,
                observer: "_observeChanged"
            },
            delay: Number,
            renderedItemCount: {
                type: Number,
                notify: !Polymer.Settings.suppressTemplateNotifications,
                readOnly: !0
            },
            initialCount: {
                type: Number,
                observer: "_initializeChunking"
            },
            targetFramerate: {
                type: Number,
                value: 20
            },
            notifyDomChange: {
                type: Boolean
            },
            _targetFrameTime: {
                type: Number,
                computed: "_computeFrameTime(targetFramerate)"
            }
        },
        behaviors: [Polymer.Templatizer],
        observers: ["_itemsChanged(items.*)"],
        created: function() {
            this._instances = [], this._pool = [], this._limit = 1 / 0;
            var self = this;
            this._boundRenderChunk = function() {
                self._renderChunk()
            }
        },
        detached: function() {
            this.__isDetached = !0;
            for (var i = 0; i < this._instances.length; i++) this._detachInstance(i)
        },
        attached: function() {
            if (this.__isDetached) {
                this.__isDetached = !1;
                var refNode, parentNode = Polymer.dom(this).parentNode;
                parentNode.localName == this.is ? (refNode = parentNode, parentNode = Polymer.dom(parentNode).parentNode) : refNode = this;
                for (var parent = Polymer.dom(parentNode), i = 0; i < this._instances.length; i++) this._attachInstance(i, parent, refNode)
            }
        },
        ready: function() {
            this._instanceProps = {
                __key__: !0
            }, this._instanceProps[this.as] = !0, this._instanceProps[this.indexAs] = !0, this.ctor || this.templatize(this)
        },
        _sortChanged: function(sort) {
            var dataHost = this._getRootDataHost();
            this._sortFn = sort && ("function" == typeof sort ? sort : function() {
                return dataHost[sort].apply(dataHost, arguments)
            }), this._needFullRefresh = !0, this.items && this._debounceTemplate(this._render)
        },
        _filterChanged: function(filter) {
            var dataHost = this._getRootDataHost();
            this._filterFn = filter && ("function" == typeof filter ? filter : function() {
                return dataHost[filter].apply(dataHost, arguments)
            }), this._needFullRefresh = !0, this.items && this._debounceTemplate(this._render)
        },
        _computeFrameTime: function(rate) {
            return Math.ceil(1e3 / rate)
        },
        _initializeChunking: function() {
            this.initialCount && (this._limit = this.initialCount, this._chunkCount = this.initialCount, this._lastChunkTime = performance.now())
        },
        _tryRenderChunk: function() {
            this.items && this._limit < this.items.length && this.debounce("renderChunk", this._requestRenderChunk)
        },
        _requestRenderChunk: function() {
            requestAnimationFrame(this._boundRenderChunk)
        },
        _renderChunk: function() {
            var currChunkTime = performance.now(),
                ratio = this._targetFrameTime / (currChunkTime - this._lastChunkTime);
            this._chunkCount = Math.round(this._chunkCount * ratio) || 1, this._limit += this._chunkCount, this._lastChunkTime = currChunkTime, this._debounceTemplate(this._render)
        },
        _observeChanged: function() {
            this._observePaths = this.observe && this.observe.replace(".*", ".").split(" ")
        },
        _itemsChanged: function(change) {
            if ("items" == change.path) Array.isArray(this.items) ? this.collection = Polymer.Collection.get(this.items) : this.items ? this._error(this._logf("dom-repeat", "expected array for `items`, found", this.items)) : this.collection = null, this._keySplices = [], this._indexSplices = [], this._needFullRefresh = !0, this._initializeChunking(), this._debounceTemplate(this._render);
            else if ("items.splices" == change.path) this._keySplices = this._keySplices.concat(change.value.keySplices), this._indexSplices = this._indexSplices.concat(change.value.indexSplices), this._debounceTemplate(this._render);
            else {
                var subpath = change.path.slice(6);
                this._forwardItemPath(subpath, change.value), this._checkObservedPaths(subpath)
            }
        },
        _checkObservedPaths: function(path) {
            if (this._observePaths) {
                path = path.substring(path.indexOf(".") + 1);
                for (var paths = this._observePaths, i = 0; i < paths.length; i++)
                    if (0 === path.indexOf(paths[i])) return this._needFullRefresh = !0, void(this.delay ? this.debounce("render", this._render, this.delay) : this._debounceTemplate(this._render))
            }
        },
        render: function() {
            this._needFullRefresh = !0, this._debounceTemplate(this._render), this._flushTemplates()
        },
        _render: function() {
            this._needFullRefresh ? (this._applyFullRefresh(), this._needFullRefresh = !1) : this._keySplices.length && (this._sortFn ? this._applySplicesUserSort(this._keySplices) : this._filterFn ? this._applyFullRefresh() : this._applySplicesArrayOrder(this._indexSplices)), this._keySplices = [], this._indexSplices = [];
            for (var keyToIdx = this._keyToInstIdx = {}, i = this._instances.length - 1; i >= 0; i--) {
                var inst = this._instances[i];
                inst.isPlaceholder && i < this._limit ? inst = this._insertInstance(i, inst.__key__) : !inst.isPlaceholder && i >= this._limit && (inst = this._downgradeInstance(i, inst.__key__)), keyToIdx[inst.__key__] = i, inst.isPlaceholder || inst.__setProperty(this.indexAs, i, !0)
            }
            this._pool.length = 0, this._setRenderedItemCount(this._instances.length), (!Polymer.Settings.suppressTemplateNotifications || this.notifyDomChange) && this.fire("dom-change"), this._tryRenderChunk()
        },
        _applyFullRefresh: function() {
            var keys, c = this.collection;
            if (this._sortFn) keys = c ? c.getKeys() : [];
            else {
                keys = [];
                var items = this.items;
                if (items)
                    for (var i = 0; i < items.length; i++) keys.push(c.getKey(items[i]))
            }
            var self = this;
            for (this._filterFn && (keys = keys.filter(function(a) {
                    return self._filterFn(c.getItem(a))
                })), this._sortFn && keys.sort(function(a, b) {
                    return self._sortFn(c.getItem(a), c.getItem(b))
                }), i = 0; i < keys.length; i++) {
                var key = keys[i],
                    inst = this._instances[i];
                inst ? (inst.__key__ = key, !inst.isPlaceholder && i < this._limit && inst.__setProperty(this.as, c.getItem(key), !0)) : i < this._limit ? this._insertInstance(i, key) : this._insertPlaceholder(i, key)
            }
            for (var j = this._instances.length - 1; j >= i; j--) this._detachAndRemoveInstance(j)
        },
        _numericSort: function(a, b) {
            return a - b
        },
        _applySplicesUserSort: function(splices) {
            for (var key, s, c = this.collection, keyMap = {}, i = 0; i < splices.length && (s = splices[i]); i++) {
                for (var j = 0; j < s.removed.length; j++) key = s.removed[j], keyMap[key] = keyMap[key] ? null : -1;
                for (j = 0; j < s.added.length; j++) key = s.added[j], keyMap[key] = keyMap[key] ? null : 1
            }
            var removedIdxs = [],
                addedKeys = [];
            for (key in keyMap) - 1 === keyMap[key] && removedIdxs.push(this._keyToInstIdx[key]), 1 === keyMap[key] && addedKeys.push(key);
            if (removedIdxs.length)
                for (removedIdxs.sort(this._numericSort), i = removedIdxs.length - 1; i >= 0; i--) {
                    var idx = removedIdxs[i];
                    void 0 !== idx && this._detachAndRemoveInstance(idx)
                }
            var self = this;
            if (addedKeys.length) {
                this._filterFn && (addedKeys = addedKeys.filter(function(a) {
                    return self._filterFn(c.getItem(a))
                })), addedKeys.sort(function(a, b) {
                    return self._sortFn(c.getItem(a), c.getItem(b))
                });
                var start = 0;
                for (i = 0; i < addedKeys.length; i++) start = this._insertRowUserSort(start, addedKeys[i])
            }
        },
        _insertRowUserSort: function(start, key) {
            for (var c = this.collection, item = c.getItem(key), end = this._instances.length - 1, idx = -1; end >= start;) {
                var mid = start + end >> 1,
                    midKey = this._instances[mid].__key__,
                    cmp = this._sortFn(c.getItem(midKey), item);
                if (0 > cmp) start = mid + 1;
                else {
                    if (!(cmp > 0)) {
                        idx = mid;
                        break
                    }
                    end = mid - 1
                }
            }
            return 0 > idx && (idx = end + 1), this._insertPlaceholder(idx, key), idx
        },
        _applySplicesArrayOrder: function(splices) {
            for (var s, i = 0; i < splices.length && (s = splices[i]); i++) {
                for (var j = 0; j < s.removed.length; j++) this._detachAndRemoveInstance(s.index);
                for (j = 0; j < s.addedKeys.length; j++) this._insertPlaceholder(s.index + j, s.addedKeys[j])
            }
        },
        _detachInstance: function(idx) {
            var inst = this._instances[idx];
            if (!inst.isPlaceholder) {
                for (var i = 0; i < inst._children.length; i++) {
                    var el = inst._children[i];
                    Polymer.dom(inst.root).appendChild(el)
                }
                return inst
            }
        },
        _attachInstance: function(idx, parent, refNode) {
            var inst = this._instances[idx];
            inst.isPlaceholder || parent.insertBefore(inst.root, refNode)
        },
        _detachAndRemoveInstance: function(idx) {
            var inst = this._detachInstance(idx);
            inst && this._pool.push(inst), this._instances.splice(idx, 1)
        },
        _insertPlaceholder: function(idx, key) {
            this._instances.splice(idx, 0, {
                isPlaceholder: !0,
                __key__: key
            })
        },
        _stampInstance: function(idx, key) {
            var model = {
                __key__: key
            };
            return model[this.as] = this.collection.getItem(key), model[this.indexAs] = idx, this.stamp(model)
        },
        _insertInstance: function(idx, key) {
            var inst = this._pool.pop();
            inst ? (inst.__setProperty(this.as, this.collection.getItem(key), !0), inst.__setProperty("__key__", key, !0)) : inst = this._stampInstance(idx, key);
            var beforeRow = this._instances[idx + 1],
                beforeNode = beforeRow && !beforeRow.isPlaceholder ? beforeRow._children[0] : this,
                parentNode = Polymer.dom(this).parentNode;
            return parentNode.localName == this.is && (beforeNode == this && (beforeNode = parentNode), parentNode = Polymer.dom(parentNode).parentNode), Polymer.dom(parentNode).insertBefore(inst.root, beforeNode), this._instances[idx] = inst, inst
        },
        _downgradeInstance: function(idx, key) {
            var inst = this._detachInstance(idx);
            return inst && this._pool.push(inst), inst = {
                isPlaceholder: !0,
                __key__: key
            }, this._instances[idx] = inst, inst
        },
        _showHideChildren: function(hidden) {
            for (var i = 0; i < this._instances.length; i++) this._instances[i].isPlaceholder || this._instances[i]._showHideChildren(hidden)
        },
        _forwardInstanceProp: function(inst, prop, value) {
            if (prop == this.as) {
                var idx;
                idx = this._sortFn || this._filterFn ? this.items.indexOf(this.collection.getItem(inst.__key__)) : inst[this.indexAs], this.set("items." + idx, value)
            }
        },
        _forwardInstancePath: function(inst, path, value) {
            0 === path.indexOf(this.as + ".") && this._notifyPath("items." + inst.__key__ + "." + path.slice(this.as.length + 1), value)
        },
        _forwardParentProp: function(prop, value) {
            for (var inst, i$ = this._instances, i = 0; i < i$.length && (inst = i$[i]); i++) inst.isPlaceholder || inst.__setProperty(prop, value, !0)
        },
        _forwardParentPath: function(path, value) {
            for (var inst, i$ = this._instances, i = 0; i < i$.length && (inst = i$[i]); i++) inst.isPlaceholder || inst._notifyPath(path, value, !0)
        },
        _forwardItemPath: function(path, value) {
            if (this._keyToInstIdx) {
                var dot = path.indexOf("."),
                    key = path.substring(0, 0 > dot ? path.length : dot),
                    idx = this._keyToInstIdx[key],
                    inst = this._instances[idx];
                inst && !inst.isPlaceholder && (dot >= 0 ? (path = this.as + "." + path.substring(dot + 1), inst._notifyPath(path, value, !0)) : inst.__setProperty(this.as, value, !0))
            }
        },
        itemForElement: function(el) {
            var instance = this.modelForElement(el);
            return instance && instance[this.as]
        },
        keyForElement: function(el) {
            var instance = this.modelForElement(el);
            return instance && instance.__key__
        },
        indexForElement: function(el) {
            var instance = this.modelForElement(el);
            return instance && instance[this.indexAs]
        }
    }), Polymer({
        is: "array-selector",
        _template: null,
        properties: {
            items: {
                type: Array,
                observer: "clearSelection"
            },
            multi: {
                type: Boolean,
                value: !1,
                observer: "clearSelection"
            },
            selected: {
                type: Object,
                notify: !0
            },
            selectedItem: {
                type: Object,
                notify: !0
            },
            toggle: {
                type: Boolean,
                value: !1
            }
        },
        clearSelection: function() {
            if (Array.isArray(this.selected))
                for (var i = 0; i < this.selected.length; i++) this.unlinkPaths("selected." + i);
            else this.unlinkPaths("selected"), this.unlinkPaths("selectedItem");
            this.multi ? (!this.selected || this.selected.length) && (this.selected = [], this._selectedColl = Polymer.Collection.get(this.selected)) : (this.selected = null, this._selectedColl = null), this.selectedItem = null
        },
        isSelected: function(item) {
            return this.multi ? void 0 !== this._selectedColl.getKey(item) : this.selected == item
        },
        deselect: function(item) {
            if (this.multi) {
                if (this.isSelected(item)) {
                    var skey = this._selectedColl.getKey(item);
                    this.arrayDelete("selected", item), this.unlinkPaths("selected." + skey)
                }
            } else this.selected = null, this.selectedItem = null, this.unlinkPaths("selected"), this.unlinkPaths("selectedItem")
        },
        select: function(item) {
            var icol = Polymer.Collection.get(this.items),
                key = icol.getKey(item);
            if (this.multi)
                if (this.isSelected(item)) this.toggle && this.deselect(item);
                else {
                    this.push("selected", item);
                    var skey = this._selectedColl.getKey(item);
                    this.linkPaths("selected." + skey, "items." + key)
                }
            else this.toggle && item == this.selected ? this.deselect() : (this.selected = item, this.selectedItem = item, this.linkPaths("selected", "items." + key), this.linkPaths("selectedItem", "items." + key))
        }
    }), Polymer({
        is: "dom-if",
        "extends": "template",
        _template: null,
        properties: {
            "if": {
                type: Boolean,
                value: !1,
                observer: "_queueRender"
            },
            restamp: {
                type: Boolean,
                value: !1,
                observer: "_queueRender"
            },
            notifyDomChange: {
                type: Boolean
            }
        },
        behaviors: [Polymer.Templatizer],
        _queueRender: function() {
            this._debounceTemplate(this._render)
        },
        detached: function() {
            var parentNode = this.parentNode;
            parentNode && parentNode.localName == this.is && (parentNode = Polymer.dom(parentNode).parentNode), parentNode && (parentNode.nodeType != Node.DOCUMENT_FRAGMENT_NODE || Polymer.Settings.hasShadow && parentNode instanceof ShadowRoot) || this._teardownInstance()
        },
        attached: function() {
            this["if"] && this.ctor && this.async(this._ensureInstance)
        },
        render: function() {
            this._flushTemplates()
        },
        _render: function() {
            this["if"] ? (this.ctor || this.templatize(this), this._ensureInstance(), this._showHideChildren()) : this.restamp && this._teardownInstance(), !this.restamp && this._instance && this._showHideChildren(), this["if"] != this._lastIf && ((!Polymer.Settings.suppressTemplateNotifications || this.notifyDomChange) && this.fire("dom-change"), this._lastIf = this["if"])
        },
        _ensureInstance: function() {
            var refNode, parentNode = Polymer.dom(this).parentNode;
            if (parentNode && parentNode.localName == this.is ? (refNode = parentNode, parentNode = Polymer.dom(parentNode).parentNode) : refNode = this, parentNode)
                if (this._instance) {
                    var c$ = this._instance._children;
                    if (c$ && c$.length) {
                        var lastChild = Polymer.dom(refNode).previousSibling;
                        if (lastChild !== c$[c$.length - 1])
                            for (var n, i = 0; i < c$.length && (n = c$[i]); i++) Polymer.dom(parentNode).insertBefore(n, refNode)
                    }
                } else {
                    this._instance = this.stamp();
                    var root = this._instance.root;
                    Polymer.dom(parentNode).insertBefore(root, refNode)
                }
        },
        _teardownInstance: function() {
            if (this._instance) {
                var c$ = this._instance._children;
                if (c$ && c$.length)
                    for (var n, parent = Polymer.dom(Polymer.dom(c$[0]).parentNode), i = 0; i < c$.length && (n = c$[i]); i++) parent.removeChild(n);
                this._instance = null
            }
        },
        _showHideChildren: function() {
            var hidden = this.__hideTemplateChildren__ || !this["if"];
            this._instance && this._instance._showHideChildren(hidden)
        },
        _forwardParentProp: function(prop, value) {
            this._instance && this._instance.__setProperty(prop, value, !0)
        },
        _forwardParentPath: function(path, value) {
            this._instance && this._instance._notifyPath(path, value, !0)
        }
    }), Polymer({
        is: "dom-bind",
        properties: {
            notifyDomChange: {
                type: Boolean
            }
        },
        "extends": "template",
        _template: null,
        created: function() {
            var self = this;
            Polymer.RenderStatus.whenReady(function() {
                "loading" == document.readyState ? document.addEventListener("DOMContentLoaded", function() {
                    self._markImportsReady()
                }) : self._markImportsReady()
            })
        },
        _ensureReady: function() {
            this._readied || this._readySelf()
        },
        _markImportsReady: function() {
            this._importsReady = !0, this._ensureReady()
        },
        _registerFeatures: function() {
            this._prepConstructor()
        },
        _insertChildren: function() {
            var refNode, parentNode = Polymer.dom(this).parentNode;
            parentNode.localName == this.is ? (refNode = parentNode, parentNode = Polymer.dom(parentNode).parentNode) : refNode = this, Polymer.dom(parentNode).insertBefore(this.root, refNode)
        },
        _removeChildren: function() {
            if (this._children)
                for (var i = 0; i < this._children.length; i++) this.root.appendChild(this._children[i])
        },
        _initFeatures: function() {},
        _scopeElementClass: function(element, selector) {
            return this.dataHost ? this.dataHost._scopeElementClass(element, selector) : selector
        },
        _configureInstanceProperties: function() {},
        _prepConfigure: function() {
            var config = {};
            for (var prop in this._propertyEffects) config[prop] = this[prop];
            var setupConfigure = this._setupConfigure;
            this._setupConfigure = function() {
                setupConfigure.call(this, config)
            }
        },
        attached: function() {
            this._importsReady && this.render()
        },
        detached: function() {
            this._removeChildren()
        },
        render: function() {
            this._ensureReady(), this._children || (this._template = this, this._prepAnnotations(), this._prepEffects(), this._prepBehaviors(), this._prepConfigure(), this._prepBindings(), this._prepPropertyInfo(), Polymer.Base._initFeatures.call(this), this._children = Polymer.TreeApi.arrayCopyChildNodes(this.root)), this._insertChildren(), (!Polymer.Settings.suppressTemplateNotifications || this.notifyDomChange) && this.fire("dom-change")
        }
    }), Polymer({
        is: "sp-analytics",
        properties: {
            trackingId: {
                type: String
            }
        },
        ready: function() {
            ! function(i, s, o, g, r, a, m) {
                i.GoogleAnalyticsObject = r, i[r] = i[r] || function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date, a = s.createElement(o), m = s.getElementsByTagName(o)[0], a.async = 1, a.src = g, m.parentNode.insertBefore(a, m)
            }(window, document, "script", "https://www.google-analytics.com/analytics.js", "ga"), ga("create", this.trackingId, "auto"), ga("send", "pageview")
        },
        recordEvent: function(options) {
            ga("send", "event", options)
        }
    }), Polymer({
        is: "paper-material",
        properties: {
            elevation: {
                type: Number,
                reflectToAttribute: !0,
                value: 1
            },
            animated: {
                type: Boolean,
                reflectToAttribute: !0,
                value: !1
            }
        }
    }),
    function() {
        "use strict";

        function transformKey(key, noSpecialChars) {
            var validKey = "";
            if (key) {
                var lKey = key.toLowerCase();
                " " === lKey || SPACE_KEY.test(lKey) ? validKey = "space" : ESC_KEY.test(lKey) ? validKey = "esc" : 1 == lKey.length ? (!noSpecialChars || KEY_CHAR.test(lKey)) && (validKey = lKey) : validKey = ARROW_KEY.test(lKey) ? lKey.replace("arrow", "") : "multiply" == lKey ? "*" : lKey
            }
            return validKey
        }

        function transformKeyIdentifier(keyIdent) {
            var validKey = "";
            return keyIdent && (keyIdent in KEY_IDENTIFIER ? validKey = KEY_IDENTIFIER[keyIdent] : IDENT_CHAR.test(keyIdent) ? (keyIdent = parseInt(keyIdent.replace("U+", "0x"), 16), validKey = String.fromCharCode(keyIdent).toLowerCase()) : validKey = keyIdent.toLowerCase()), validKey
        }

        function transformKeyCode(keyCode) {
            var validKey = "";
            return Number(keyCode) && (validKey = keyCode >= 65 && 90 >= keyCode ? String.fromCharCode(32 + keyCode) : keyCode >= 112 && 123 >= keyCode ? "f" + (keyCode - 112) : keyCode >= 48 && 57 >= keyCode ? String(keyCode - 48) : keyCode >= 96 && 105 >= keyCode ? String(keyCode - 96) : KEY_CODE[keyCode]), validKey
        }

        function normalizedKeyForEvent(keyEvent, noSpecialChars) {
            return keyEvent.key ? transformKey(keyEvent.key, noSpecialChars) : keyEvent.detail && keyEvent.detail.key ? transformKey(keyEvent.detail.key, noSpecialChars) : transformKeyIdentifier(keyEvent.keyIdentifier) || transformKeyCode(keyEvent.keyCode) || ""
        }

        function keyComboMatchesEvent(keyCombo, event) {
            var keyEvent = normalizedKeyForEvent(event, keyCombo.hasModifiers);
            return keyEvent === keyCombo.key && (!keyCombo.hasModifiers || !!event.shiftKey == !!keyCombo.shiftKey && !!event.ctrlKey == !!keyCombo.ctrlKey && !!event.altKey == !!keyCombo.altKey && !!event.metaKey == !!keyCombo.metaKey)
        }

        function parseKeyComboString(keyComboString) {
            return 1 === keyComboString.length ? {
                combo: keyComboString,
                key: keyComboString,
                event: "keydown"
            } : keyComboString.split("+").reduce(function(parsedKeyCombo, keyComboPart) {
                var eventParts = keyComboPart.split(":"),
                    keyName = eventParts[0],
                    event = eventParts[1];
                return keyName in MODIFIER_KEYS ? (parsedKeyCombo[MODIFIER_KEYS[keyName]] = !0, parsedKeyCombo.hasModifiers = !0) : (parsedKeyCombo.key = keyName, parsedKeyCombo.event = event || "keydown"), parsedKeyCombo
            }, {
                combo: keyComboString.split(":").shift()
            })
        }

        function parseEventString(eventString) {
            return eventString.trim().split(" ").map(function(keyComboString) {
                return parseKeyComboString(keyComboString)
            })
        }
        var KEY_IDENTIFIER = {
                "U+0008": "backspace",
                "U+0009": "tab",
                "U+001B": "esc",
                "U+0020": "space",
                "U+007F": "del"
            },
            KEY_CODE = {
                8: "backspace",
                9: "tab",
                13: "enter",
                27: "esc",
                33: "pageup",
                34: "pagedown",
                35: "end",
                36: "home",
                32: "space",
                37: "left",
                38: "up",
                39: "right",
                40: "down",
                46: "del",
                106: "*"
            },
            MODIFIER_KEYS = {
                shift: "shiftKey",
                ctrl: "ctrlKey",
                alt: "altKey",
                meta: "metaKey"
            },
            KEY_CHAR = /[a-z0-9*]/,
            IDENT_CHAR = /U\+/,
            ARROW_KEY = /^arrow/,
            SPACE_KEY = /^space(bar)?/,
            ESC_KEY = /^escape$/;
        Polymer.IronA11yKeysBehavior = {
            properties: {
                keyEventTarget: {
                    type: Object,
                    value: function() {
                        return this
                    }
                },
                stopKeyboardEventPropagation: {
                    type: Boolean,
                    value: !1
                },
                _boundKeyHandlers: {
                    type: Array,
                    value: function() {
                        return []
                    }
                },
                _imperativeKeyBindings: {
                    type: Object,
                    value: function() {
                        return {}
                    }
                }
            },
            observers: ["_resetKeyEventListeners(keyEventTarget, _boundKeyHandlers)"],
            keyBindings: {},
            registered: function() {
                this._prepKeyBindings()
            },
            attached: function() {
                this._listenKeyEventListeners()
            },
            detached: function() {
                this._unlistenKeyEventListeners()
            },
            addOwnKeyBinding: function(eventString, handlerName) {
                this._imperativeKeyBindings[eventString] = handlerName, this._prepKeyBindings(), this._resetKeyEventListeners()
            },
            removeOwnKeyBindings: function() {
                this._imperativeKeyBindings = {}, this._prepKeyBindings(), this._resetKeyEventListeners()
            },
            keyboardEventMatchesKeys: function(event, eventString) {
                for (var keyCombos = parseEventString(eventString), i = 0; i < keyCombos.length; ++i)
                    if (keyComboMatchesEvent(keyCombos[i], event)) return !0;
                return !1
            },
            _collectKeyBindings: function() {
                var keyBindings = this.behaviors.map(function(behavior) {
                    return behavior.keyBindings
                });
                return -1 === keyBindings.indexOf(this.keyBindings) && keyBindings.push(this.keyBindings), keyBindings
            },
            _prepKeyBindings: function() {
                this._keyBindings = {}, this._collectKeyBindings().forEach(function(keyBindings) {
                    for (var eventString in keyBindings) this._addKeyBinding(eventString, keyBindings[eventString])
                }, this);
                for (var eventString in this._imperativeKeyBindings) this._addKeyBinding(eventString, this._imperativeKeyBindings[eventString]);
                for (var eventName in this._keyBindings) this._keyBindings[eventName].sort(function(kb1, kb2) {
                    var b1 = kb1[0].hasModifiers,
                        b2 = kb2[0].hasModifiers;
                    return b1 === b2 ? 0 : b1 ? -1 : 1
                })
            },
            _addKeyBinding: function(eventString, handlerName) {
                parseEventString(eventString).forEach(function(keyCombo) {
                    this._keyBindings[keyCombo.event] = this._keyBindings[keyCombo.event] || [], this._keyBindings[keyCombo.event].push([keyCombo, handlerName])
                }, this)
            },
            _resetKeyEventListeners: function() {
                this._unlistenKeyEventListeners(), this.isAttached && this._listenKeyEventListeners()
            },
            _listenKeyEventListeners: function() {
                this.keyEventTarget && Object.keys(this._keyBindings).forEach(function(eventName) {
                    var keyBindings = this._keyBindings[eventName],
                        boundKeyHandler = this._onKeyBindingEvent.bind(this, keyBindings);
                    this._boundKeyHandlers.push([this.keyEventTarget, eventName, boundKeyHandler]), this.keyEventTarget.addEventListener(eventName, boundKeyHandler)
                }, this)
            },
            _unlistenKeyEventListeners: function() {
                for (var keyHandlerTuple, keyEventTarget, eventName, boundKeyHandler; this._boundKeyHandlers.length;) keyHandlerTuple = this._boundKeyHandlers.pop(), keyEventTarget = keyHandlerTuple[0], eventName = keyHandlerTuple[1], boundKeyHandler = keyHandlerTuple[2], keyEventTarget.removeEventListener(eventName, boundKeyHandler)
            },
            _onKeyBindingEvent: function(keyBindings, event) {
                if (this.stopKeyboardEventPropagation && event.stopPropagation(), !event.defaultPrevented)
                    for (var i = 0; i < keyBindings.length; i++) {
                        var keyCombo = keyBindings[i][0],
                            handlerName = keyBindings[i][1];
                        if (keyComboMatchesEvent(keyCombo, event) && (this._triggerKeyHandler(keyCombo, handlerName, event), event.defaultPrevented)) return
                    }
            },
            _triggerKeyHandler: function(keyCombo, handlerName, keyboardEvent) {
                var detail = Object.create(keyCombo);

                detail.keyboardEvent = keyboardEvent;
                var event = new CustomEvent(keyCombo.event, {
                    detail: detail,
                    cancelable: !0
                });
                this[handlerName].call(this, event), event.defaultPrevented && keyboardEvent.preventDefault()
            }
        }
    }(),
    function() {
        "use strict";

        function ElementMetrics(element) {
            this.element = element, this.width = this.boundingRect.width, this.height = this.boundingRect.height, this.size = Math.max(this.width, this.height)
        }

        function Ripple(element) {
            this.element = element, this.color = window.getComputedStyle(element).color, this.wave = document.createElement("div"), this.waveContainer = document.createElement("div"), this.wave.style.backgroundColor = this.color, this.wave.classList.add("wave"), this.waveContainer.classList.add("wave-container"), Polymer.dom(this.waveContainer).appendChild(this.wave), this.resetInteractionState()
        }
        var Utility = {
            distance: function(x1, y1, x2, y2) {
                var xDelta = x1 - x2,
                    yDelta = y1 - y2;
                return Math.sqrt(xDelta * xDelta + yDelta * yDelta)
            },
            now: window.performance && window.performance.now ? window.performance.now.bind(window.performance) : Date.now
        };
        ElementMetrics.prototype = {
            get boundingRect() {
                return this.element.getBoundingClientRect()
            },
            furthestCornerDistanceFrom: function(x, y) {
                var topLeft = Utility.distance(x, y, 0, 0),
                    topRight = Utility.distance(x, y, this.width, 0),
                    bottomLeft = Utility.distance(x, y, 0, this.height),
                    bottomRight = Utility.distance(x, y, this.width, this.height);
                return Math.max(topLeft, topRight, bottomLeft, bottomRight)
            }
        }, Ripple.MAX_RADIUS = 300, Ripple.prototype = {
            get recenters() {
                return this.element.recenters
            },
            get center() {
                return this.element.center
            },
            get mouseDownElapsed() {
                var elapsed;
                return this.mouseDownStart ? (elapsed = Utility.now() - this.mouseDownStart, this.mouseUpStart && (elapsed -= this.mouseUpElapsed), elapsed) : 0
            },
            get mouseUpElapsed() {
                return this.mouseUpStart ? Utility.now() - this.mouseUpStart : 0
            },
            get mouseDownElapsedSeconds() {
                return this.mouseDownElapsed / 1e3
            },
            get mouseUpElapsedSeconds() {
                return this.mouseUpElapsed / 1e3
            },
            get mouseInteractionSeconds() {
                return this.mouseDownElapsedSeconds + this.mouseUpElapsedSeconds
            },
            get initialOpacity() {
                return this.element.initialOpacity
            },
            get opacityDecayVelocity() {
                return this.element.opacityDecayVelocity
            },
            get radius() {
                var width2 = this.containerMetrics.width * this.containerMetrics.width,
                    height2 = this.containerMetrics.height * this.containerMetrics.height,
                    waveRadius = 1.1 * Math.min(Math.sqrt(width2 + height2), Ripple.MAX_RADIUS) + 5,
                    duration = 1.1 - .2 * (waveRadius / Ripple.MAX_RADIUS),
                    timeNow = this.mouseInteractionSeconds / duration,
                    size = waveRadius * (1 - Math.pow(80, -timeNow));
                return Math.abs(size)
            },
            get opacity() {
                return this.mouseUpStart ? Math.max(0, this.initialOpacity - this.mouseUpElapsedSeconds * this.opacityDecayVelocity) : this.initialOpacity
            },
            get outerOpacity() {
                var outerOpacity = .3 * this.mouseUpElapsedSeconds,
                    waveOpacity = this.opacity;
                return Math.max(0, Math.min(outerOpacity, waveOpacity))
            },
            get isOpacityFullyDecayed() {
                return this.opacity < .01 && this.radius >= Math.min(this.maxRadius, Ripple.MAX_RADIUS)
            },
            get isRestingAtMaxRadius() {
                return this.opacity >= this.initialOpacity && this.radius >= Math.min(this.maxRadius, Ripple.MAX_RADIUS)
            },
            get isAnimationComplete() {
                return this.mouseUpStart ? this.isOpacityFullyDecayed : this.isRestingAtMaxRadius
            },
            get translationFraction() {
                return Math.min(1, this.radius / this.containerMetrics.size * 2 / Math.sqrt(2))
            },
            get xNow() {
                return this.xEnd ? this.xStart + this.translationFraction * (this.xEnd - this.xStart) : this.xStart
            },
            get yNow() {
                return this.yEnd ? this.yStart + this.translationFraction * (this.yEnd - this.yStart) : this.yStart
            },
            get isMouseDown() {
                return this.mouseDownStart && !this.mouseUpStart
            },
            resetInteractionState: function() {
                this.maxRadius = 0, this.mouseDownStart = 0, this.mouseUpStart = 0, this.xStart = 0, this.yStart = 0, this.xEnd = 0, this.yEnd = 0, this.slideDistance = 0, this.containerMetrics = new ElementMetrics(this.element)
            },
            draw: function() {
                var scale, dx, dy;
                this.wave.style.opacity = this.opacity, scale = this.radius / (this.containerMetrics.size / 2), dx = this.xNow - this.containerMetrics.width / 2, dy = this.yNow - this.containerMetrics.height / 2, this.waveContainer.style.webkitTransform = "translate(" + dx + "px, " + dy + "px)", this.waveContainer.style.transform = "translate3d(" + dx + "px, " + dy + "px, 0)", this.wave.style.webkitTransform = "scale(" + scale + "," + scale + ")", this.wave.style.transform = "scale3d(" + scale + "," + scale + ",1)"
            },
            downAction: function(event) {
                var xCenter = this.containerMetrics.width / 2,
                    yCenter = this.containerMetrics.height / 2;
                this.resetInteractionState(), this.mouseDownStart = Utility.now(), this.center ? (this.xStart = xCenter, this.yStart = yCenter, this.slideDistance = Utility.distance(this.xStart, this.yStart, this.xEnd, this.yEnd)) : (this.xStart = event ? event.detail.x - this.containerMetrics.boundingRect.left : this.containerMetrics.width / 2, this.yStart = event ? event.detail.y - this.containerMetrics.boundingRect.top : this.containerMetrics.height / 2), this.recenters && (this.xEnd = xCenter, this.yEnd = yCenter, this.slideDistance = Utility.distance(this.xStart, this.yStart, this.xEnd, this.yEnd)), this.maxRadius = this.containerMetrics.furthestCornerDistanceFrom(this.xStart, this.yStart), this.waveContainer.style.top = (this.containerMetrics.height - this.containerMetrics.size) / 2 + "px", this.waveContainer.style.left = (this.containerMetrics.width - this.containerMetrics.size) / 2 + "px", this.waveContainer.style.width = this.containerMetrics.size + "px", this.waveContainer.style.height = this.containerMetrics.size + "px"
            },
            upAction: function() {
                this.isMouseDown && (this.mouseUpStart = Utility.now())
            },
            remove: function() {
                Polymer.dom(this.waveContainer.parentNode).removeChild(this.waveContainer)
            }
        }, Polymer({
            is: "paper-ripple",
            behaviors: [Polymer.IronA11yKeysBehavior],
            properties: {
                initialOpacity: {
                    type: Number,
                    value: .25
                },
                opacityDecayVelocity: {
                    type: Number,
                    value: .8
                },
                recenters: {
                    type: Boolean,
                    value: !1
                },
                center: {
                    type: Boolean,
                    value: !1
                },
                ripples: {
                    type: Array,
                    value: function() {
                        return []
                    }
                },
                animating: {
                    type: Boolean,
                    readOnly: !0,
                    reflectToAttribute: !0,
                    value: !1
                },
                holdDown: {
                    type: Boolean,
                    value: !1,
                    observer: "_holdDownChanged"
                },
                noink: {
                    type: Boolean,
                    value: !1
                },
                _animating: {
                    type: Boolean
                },
                _boundAnimate: {
                    type: Function,
                    value: function() {
                        return this.animate.bind(this)
                    }
                }
            },
            get target() {
                return this.keyEventTarget
            },
            keyBindings: {
                "enter:keydown": "_onEnterKeydown",
                "space:keydown": "_onSpaceKeydown",
                "space:keyup": "_onSpaceKeyup"
            },
            attached: function() {
                this.keyEventTarget = 11 == this.parentNode.nodeType ? Polymer.dom(this).getOwnerRoot().host : this.parentNode;
                var keyEventTarget = this.keyEventTarget;
                this.listen(keyEventTarget, "up", "uiUpAction"), this.listen(keyEventTarget, "down", "uiDownAction")
            },
            detached: function() {
                this.unlisten(this.keyEventTarget, "up", "uiUpAction"), this.unlisten(this.keyEventTarget, "down", "uiDownAction"), this.keyEventTarget = null
            },
            get shouldKeepAnimating() {
                for (var index = 0; index < this.ripples.length; ++index)
                    if (!this.ripples[index].isAnimationComplete) return !0;
                return !1
            },
            simulatedRipple: function() {
                this.downAction(null), this.async(function() {
                    this.upAction()
                }, 1)
            },
            uiDownAction: function(event) {
                this.noink || this.downAction(event)
            },
            downAction: function(event) {
                if (!(this.holdDown && this.ripples.length > 0)) {
                    var ripple = this.addRipple();
                    ripple.downAction(event), this._animating || (this._animating = !0, this.animate())
                }
            },
            uiUpAction: function(event) {
                this.noink || this.upAction(event)
            },
            upAction: function(event) {
                this.holdDown || (this.ripples.forEach(function(ripple) {
                    ripple.upAction(event)
                }), this._animating = !0, this.animate())
            },
            onAnimationComplete: function() {
                this._animating = !1, this.$.background.style.backgroundColor = null, this.fire("transitionend")
            },
            addRipple: function() {
                var ripple = new Ripple(this);
                return Polymer.dom(this.$.waves).appendChild(ripple.waveContainer), this.$.background.style.backgroundColor = ripple.color, this.ripples.push(ripple), this._setAnimating(!0), ripple
            },
            removeRipple: function(ripple) {
                var rippleIndex = this.ripples.indexOf(ripple);
                0 > rippleIndex || (this.ripples.splice(rippleIndex, 1), ripple.remove(), this.ripples.length || this._setAnimating(!1))
            },
            animate: function() {
                if (this._animating) {
                    var index, ripple;
                    for (index = 0; index < this.ripples.length; ++index) ripple = this.ripples[index], ripple.draw(), this.$.background.style.opacity = ripple.outerOpacity, ripple.isOpacityFullyDecayed && !ripple.isRestingAtMaxRadius && this.removeRipple(ripple);
                    this.shouldKeepAnimating || 0 !== this.ripples.length ? window.requestAnimationFrame(this._boundAnimate) : this.onAnimationComplete()
                }
            },
            _onEnterKeydown: function() {
                this.uiDownAction(), this.async(this.uiUpAction, 1)
            },
            _onSpaceKeydown: function() {
                this.uiDownAction()
            },
            _onSpaceKeyup: function() {
                this.uiUpAction()
            },
            _holdDownChanged: function(newVal, oldVal) {
                void 0 !== oldVal && (newVal ? this.downAction() : this.upAction())
            }
        })
    }(), Polymer.IronControlState = {
        properties: {
            focused: {
                type: Boolean,
                value: !1,
                notify: !0,
                readOnly: !0,
                reflectToAttribute: !0
            },
            disabled: {
                type: Boolean,
                value: !1,
                notify: !0,
                observer: "_disabledChanged",
                reflectToAttribute: !0
            },
            _oldTabIndex: {
                type: Number
            },
            _boundFocusBlurHandler: {
                type: Function,
                value: function() {
                    return this._focusBlurHandler.bind(this)
                }
            },
            __handleEventRetargeting: {
                type: Boolean,
                value: function() {
                    return !this.shadowRoot && !Polymer.Element
                }
            }
        },
        observers: ["_changedControlState(focused, disabled)"],
        ready: function() {
            this.addEventListener("focus", this._boundFocusBlurHandler, !0), this.addEventListener("blur", this._boundFocusBlurHandler, !0)
        },
        _focusBlurHandler: function(event) {
            if (Polymer.Element) return void this._setFocused("focus" === event.type);
            if (event.target === this) this._setFocused("focus" === event.type);
            else if (this.__handleEventRetargeting) {
                var target = Polymer.dom(event).localTarget;
                this.isLightDescendant(target) || this.fire(event.type, {
                    sourceEvent: event
                }, {
                    node: this,
                    bubbles: event.bubbles,
                    cancelable: event.cancelable
                })
            }
        },
        _disabledChanged: function(disabled) {
            this.setAttribute("aria-disabled", disabled ? "true" : "false"), this.style.pointerEvents = disabled ? "none" : "", disabled ? (this._oldTabIndex = this.tabIndex, this._setFocused(!1), this.tabIndex = -1, this.blur()) : void 0 !== this._oldTabIndex && (this.tabIndex = this._oldTabIndex)
        },
        _changedControlState: function() {
            this._controlStateChanged && this._controlStateChanged()
        }
    }, Polymer.IronButtonStateImpl = {
        properties: {
            pressed: {
                type: Boolean,
                readOnly: !0,
                value: !1,
                reflectToAttribute: !0,
                observer: "_pressedChanged"
            },
            toggles: {
                type: Boolean,
                value: !1,
                reflectToAttribute: !0
            },
            active: {
                type: Boolean,
                value: !1,
                notify: !0,
                reflectToAttribute: !0
            },
            pointerDown: {
                type: Boolean,
                readOnly: !0,
                value: !1
            },
            receivedFocusFromKeyboard: {
                type: Boolean,
                readOnly: !0
            },
            ariaActiveAttribute: {
                type: String,
                value: "aria-pressed",
                observer: "_ariaActiveAttributeChanged"
            }
        },
        listeners: {
            down: "_downHandler",
            up: "_upHandler",
            tap: "_tapHandler"
        },
        observers: ["_focusChanged(focused)", "_activeChanged(active, ariaActiveAttribute)"],
        keyBindings: {
            "enter:keydown": "_asyncClick",
            "space:keydown": "_spaceKeyDownHandler",
            "space:keyup": "_spaceKeyUpHandler"
        },
        _mouseEventRe: /^mouse/,
        _tapHandler: function() {
            this.toggles ? this._userActivate(!this.active) : this.active = !1
        },
        _focusChanged: function(focused) {
            this._detectKeyboardFocus(focused), focused || this._setPressed(!1)
        },
        _detectKeyboardFocus: function(focused) {
            this._setReceivedFocusFromKeyboard(!this.pointerDown && focused)
        },
        _userActivate: function(active) {
            this.active !== active && (this.active = active, this.fire("change"))
        },
        _downHandler: function() {
            this._setPointerDown(!0), this._setPressed(!0), this._setReceivedFocusFromKeyboard(!1)
        },
        _upHandler: function() {
            this._setPointerDown(!1), this._setPressed(!1)
        },
        _spaceKeyDownHandler: function(event) {
            var keyboardEvent = event.detail.keyboardEvent,
                target = Polymer.dom(keyboardEvent).localTarget;
            this.isLightDescendant(target) || (keyboardEvent.preventDefault(), keyboardEvent.stopImmediatePropagation(), this._setPressed(!0))
        },
        _spaceKeyUpHandler: function(event) {
            var keyboardEvent = event.detail.keyboardEvent,
                target = Polymer.dom(keyboardEvent).localTarget;
            this.isLightDescendant(target) || (this.pressed && this._asyncClick(), this._setPressed(!1))
        },
        _asyncClick: function() {
            this.async(function() {
                this.click()
            }, 1)
        },
        _pressedChanged: function() {
            this._changedButtonState()
        },
        _ariaActiveAttributeChanged: function(value, oldValue) {
            oldValue && oldValue != value && this.hasAttribute(oldValue) && this.removeAttribute(oldValue)
        },
        _activeChanged: function(active) {
            this.toggles ? this.setAttribute(this.ariaActiveAttribute, active ? "true" : "false") : this.removeAttribute(this.ariaActiveAttribute), this._changedButtonState()
        },
        _controlStateChanged: function() {
            this.disabled ? this._setPressed(!1) : this._changedButtonState()
        },
        _changedButtonState: function() {
            this._buttonStateChanged && this._buttonStateChanged()
        }
    }, Polymer.IronButtonState = [Polymer.IronA11yKeysBehavior, Polymer.IronButtonStateImpl], Polymer.PaperRippleBehavior = {
        properties: {
            noink: {
                type: Boolean,
                observer: "_noinkChanged"
            },
            _rippleContainer: {
                type: Object
            }
        },
        _buttonStateChanged: function() {
            this.focused && this.ensureRipple()
        },
        _downHandler: function(event) {
            Polymer.IronButtonStateImpl._downHandler.call(this, event), this.pressed && this.ensureRipple(event)
        },
        ensureRipple: function(optTriggeringEvent) {
            if (!this.hasRipple()) {
                this._ripple = this._createRipple(), this._ripple.noink = this.noink;
                var rippleContainer = this._rippleContainer || this.root;
                if (rippleContainer && Polymer.dom(rippleContainer).appendChild(this._ripple), optTriggeringEvent) {
                    var domContainer = Polymer.dom(this._rippleContainer || this),
                        target = Polymer.dom(optTriggeringEvent).rootTarget;
                    domContainer.deepContains(target) && this._ripple.uiDownAction(optTriggeringEvent)
                }
            }
        },
        getRipple: function() {
            return this.ensureRipple(), this._ripple
        },
        hasRipple: function() {
            return Boolean(this._ripple)
        },
        _createRipple: function() {
            return document.createElement("paper-ripple")
        },
        _noinkChanged: function(noink) {
            this.hasRipple() && (this._ripple.noink = noink)
        }
    }, Polymer.PaperButtonBehaviorImpl = {
        properties: {
            elevation: {
                type: Number,
                reflectToAttribute: !0,
                readOnly: !0
            }
        },
        observers: ["_calculateElevation(focused, disabled, active, pressed, receivedFocusFromKeyboard)", "_computeKeyboardClass(receivedFocusFromKeyboard)"],
        hostAttributes: {
            role: "button",
            tabindex: "0",
            animated: !0
        },
        _calculateElevation: function() {
            var e = 1;
            this.disabled ? e = 0 : this.active || this.pressed ? e = 4 : this.receivedFocusFromKeyboard && (e = 3), this._setElevation(e)
        },
        _computeKeyboardClass: function(receivedFocusFromKeyboard) {
            this.toggleClass("keyboard-focus", receivedFocusFromKeyboard)
        },
        _spaceKeyDownHandler: function(event) {
            Polymer.IronButtonStateImpl._spaceKeyDownHandler.call(this, event), this.hasRipple() && this.getRipple().ripples.length < 1 && this._ripple.uiDownAction()
        },
        _spaceKeyUpHandler: function(event) {
            Polymer.IronButtonStateImpl._spaceKeyUpHandler.call(this, event), this.hasRipple() && this._ripple.uiUpAction()
        }
    }, Polymer.PaperButtonBehavior = [Polymer.IronButtonState, Polymer.IronControlState, Polymer.PaperRippleBehavior, Polymer.PaperButtonBehaviorImpl], Polymer({
        is: "paper-button",
        behaviors: [Polymer.PaperButtonBehavior],
        properties: {
            raised: {
                type: Boolean,
                reflectToAttribute: !0,
                value: !1,
                observer: "_calculateElevation"
            }
        },
        _calculateElevation: function() {
            this.raised ? Polymer.PaperButtonBehaviorImpl._calculateElevation.apply(this) : this._setElevation(0)
        }
    }),
    function() {
        var metaDatas = {},
            metaArrays = {},
            singleton = null;
        Polymer.IronMeta = Polymer({
            is: "iron-meta",
            properties: {
                type: {
                    type: String,
                    value: "default",
                    observer: "_typeChanged"
                },
                key: {
                    type: String,
                    observer: "_keyChanged"
                },
                value: {
                    type: Object,
                    notify: !0,
                    observer: "_valueChanged"
                },
                self: {
                    type: Boolean,
                    observer: "_selfChanged"
                },
                list: {
                    type: Array,
                    notify: !0
                }
            },
            hostAttributes: {
                hidden: !0
            },
            factoryImpl: function(config) {
                if (config)
                    for (var n in config) switch (n) {
                        case "type":
                        case "key":
                        case "value":
                            this[n] = config[n]
                    }
            },
            created: function() {
                this._metaDatas = metaDatas, this._metaArrays = metaArrays
            },
            _keyChanged: function(key, old) {
                this._resetRegistration(old)
            },
            _valueChanged: function() {
                this._resetRegistration(this.key)
            },
            _selfChanged: function(self) {
                self && (this.value = this)
            },
            _typeChanged: function(type) {
                this._unregisterKey(this.key), metaDatas[type] || (metaDatas[type] = {}), this._metaData = metaDatas[type], metaArrays[type] || (metaArrays[type] = []), this.list = metaArrays[type], this._registerKeyValue(this.key, this.value)
            },
            byKey: function(key) {
                return this._metaData && this._metaData[key]
            },
            _resetRegistration: function(oldKey) {
                this._unregisterKey(oldKey), this._registerKeyValue(this.key, this.value)
            },
            _unregisterKey: function(key) {
                this._unregister(key, this._metaData, this.list)
            },
            _registerKeyValue: function(key, value) {
                this._register(key, value, this._metaData, this.list)
            },
            _register: function(key, value, data, list) {
                key && data && void 0 !== value && (data[key] = value, list.push(value))
            },
            _unregister: function(key, data, list) {
                if (key && data && key in data) {
                    var value = data[key];
                    delete data[key], this.arrayDelete(list, value)
                }
            }
        }), Polymer.IronMeta.getIronMeta = function() {
            return null === singleton && (singleton = new Polymer.IronMeta), singleton
        }, Polymer.IronMetaQuery = Polymer({
            is: "iron-meta-query",
            properties: {
                type: {
                    type: String,
                    value: "default",
                    observer: "_typeChanged"
                },
                key: {
                    type: String,
                    observer: "_keyChanged"
                },
                value: {
                    type: Object,
                    notify: !0,
                    readOnly: !0
                },
                list: {
                    type: Array,
                    notify: !0
                }
            },
            factoryImpl: function(config) {
                if (config)
                    for (var n in config) switch (n) {
                        case "type":
                        case "key":
                            this[n] = config[n]
                    }
            },
            created: function() {
                this._metaDatas = metaDatas, this._metaArrays = metaArrays
            },
            _keyChanged: function(key) {
                this._setValue(this._metaData && this._metaData[key])
            },
            _typeChanged: function(type) {
                this._metaData = metaDatas[type], this.list = metaArrays[type], this.key && this._keyChanged(this.key)
            },
            byKey: function(key) {
                return this._metaData && this._metaData[key]
            }
        })
    }(), Polymer({
        is: "iron-icon",
        properties: {
            icon: {
                type: String
            },
            theme: {
                type: String
            },
            src: {
                type: String
            },
            _meta: {
                value: Polymer.Base.create("iron-meta", {
                    type: "iconset"
                })
            }
        },
        observers: ["_updateIcon(_meta, isAttached)", "_updateIcon(theme, isAttached)", "_srcChanged(src, isAttached)", "_iconChanged(icon, isAttached)"],
        _DEFAULT_ICONSET: "icons",
        _iconChanged: function(icon) {
            var parts = (icon || "").split(":");
            this._iconName = parts.pop(), this._iconsetName = parts.pop() || this._DEFAULT_ICONSET, this._updateIcon()
        },
        _srcChanged: function() {
            this._updateIcon()
        },
        _usesIconset: function() {
            return this.icon || !this.src
        },
        _updateIcon: function() {
            this._usesIconset() ? (this._img && this._img.parentNode && Polymer.dom(this.root).removeChild(this._img), "" === this._iconName ? this._iconset && this._iconset.removeIcon(this) : this._iconsetName && this._meta && (this._iconset = this._meta.byKey(this._iconsetName), this._iconset ? (this._iconset.applyIcon(this, this._iconName, this.theme), this.unlisten(window, "iron-iconset-added", "_updateIcon")) : this.listen(window, "iron-iconset-added", "_updateIcon"))) : (this._iconset && this._iconset.removeIcon(this), this._img || (this._img = document.createElement("img"), this._img.style.width = "100%", this._img.style.height = "100%", this._img.draggable = !1), this._img.src = this.src, Polymer.dom(this.root).appendChild(this._img))
        }
    }), Polymer({
        is: "iron-iconset-svg",
        properties: {
            name: {
                type: String,
                observer: "_nameChanged"
            },
            size: {
                type: Number,
                value: 24
            },
            rtlMirroring: {
                type: Boolean,
                value: !1
            }
        },
        created: function() {
            this._meta = new Polymer.IronMeta({
                type: "iconset",
                key: null,
                value: null
            })
        },
        attached: function() {
            this.style.display = "none"
        },
        getIconNames: function() {
            return this._icons = this._createIconMap(), Object.keys(this._icons).map(function(n) {
                return this.name + ":" + n
            }, this)
        },
        applyIcon: function(element, iconName) {
            this.removeIcon(element);
            var svg = this._cloneIcon(iconName, this.rtlMirroring && this._targetIsRTL(element));
            if (svg) {
                var pde = Polymer.dom(element.root || element);
                return pde.insertBefore(svg, pde.childNodes[0]), element._svgIcon = svg
            }
            return null
        },
        removeIcon: function(element) {
            element._svgIcon && (Polymer.dom(element.root || element).removeChild(element._svgIcon), element._svgIcon = null)
        },
        _targetIsRTL: function(target) {
            return null == this.__targetIsRTL && (target && target.nodeType !== Node.ELEMENT_NODE && (target = target.host), this.__targetIsRTL = target && "rtl" === window.getComputedStyle(target).direction), this.__targetIsRTL
        },
        _nameChanged: function() {
            this._meta.value = null, this._meta.key = this.name, this._meta.value = this, this.async(function() {
                this.fire("iron-iconset-added", this, {
                    node: window
                })
            })
        },
        _createIconMap: function() {
            var icons = Object.create(null);
            return Polymer.dom(this).querySelectorAll("[id]").forEach(function(icon) {
                icons[icon.id] = icon
            }), icons
        },
        _cloneIcon: function(id, mirrorAllowed) {
            return this._icons = this._icons || this._createIconMap(), this._prepareSvgClone(this._icons[id], this.size, mirrorAllowed)
        },
        _prepareSvgClone: function(sourceSvg, size, mirrorAllowed) {
            if (sourceSvg) {
                var content = sourceSvg.cloneNode(!0),
                    svg = document.createElementNS("http://www.w3.org/2000/svg", "svg"),
                    viewBox = content.getAttribute("viewBox") || "0 0 " + size + " " + size,
                    cssText = "pointer-events: none; display: block; width: 100%; height: 100%;";
                return mirrorAllowed && content.hasAttribute("mirror-in-rtl") && (cssText += "-webkit-transform:scale(-1,1);transform:scale(-1,1);"), svg.setAttribute("viewBox", viewBox), svg.setAttribute("preserveAspectRatio", "xMidYMid meet"), svg.style.cssText = cssText, svg.appendChild(content).removeAttribute("id"), svg
            }
            return null
        }
    }), Polymer.PaperItemBehaviorImpl = {
        hostAttributes: {
            role: "option",
            tabindex: "0"
        }
    }, Polymer.PaperItemBehavior = [Polymer.IronButtonState, Polymer.IronControlState, Polymer.PaperItemBehaviorImpl], Polymer({
        is: "paper-item",
        behaviors: [Polymer.PaperItemBehavior]
    }), Polymer.IronSelection = function(selectCallback) {
        this.selection = [], this.selectCallback = selectCallback
    }, Polymer.IronSelection.prototype = {
        get: function() {
            return this.multi ? this.selection.slice() : this.selection[0]
        },
        clear: function(excludes) {
            this.selection.slice().forEach(function(item) {
                (!excludes || excludes.indexOf(item) < 0) && this.setItemSelected(item, !1)
            }, this)
        },
        isSelected: function(item) {
            return this.selection.indexOf(item) >= 0
        },
        setItemSelected: function(item, isSelected) {
            if (null != item && isSelected !== this.isSelected(item)) {
                if (isSelected) this.selection.push(item);
                else {
                    var i = this.selection.indexOf(item);
                    i >= 0 && this.selection.splice(i, 1)
                }
                this.selectCallback && this.selectCallback(item, isSelected)
            }
        },
        select: function(item) {
            this.multi ? this.toggle(item) : this.get() !== item && (this.setItemSelected(this.get(), !1), this.setItemSelected(item, !0))
        },
        toggle: function(item) {
            this.setItemSelected(item, !this.isSelected(item))
        }
    }, Polymer.IronSelectableBehavior = {
        properties: {
            attrForSelected: {
                type: String,
                value: null
            },
            selected: {
                type: String,
                notify: !0
            },
            selectedItem: {
                type: Object,
                readOnly: !0,
                notify: !0
            },
            activateEvent: {
                type: String,
                value: "tap",
                observer: "_activateEventChanged"
            },
            selectable: String,
            selectedClass: {
                type: String,
                value: "iron-selected"
            },
            selectedAttribute: {
                type: String,
                value: null
            },
            fallbackSelection: {
                type: String,
                value: null
            },
            items: {
                type: Array,
                readOnly: !0,
                notify: !0,
                value: function() {
                    return []
                }
            },
            _excludedLocalNames: {
                type: Object,
                value: function() {
                    return {
                        template: 1
                    }
                }
            }
        },
        observers: ["_updateAttrForSelected(attrForSelected)", "_updateSelected(selected)", "_checkFallback(fallbackSelection)"],
        created: function() {
            this._bindFilterItem = this._filterItem.bind(this), this._selection = new Polymer.IronSelection(this._applySelection.bind(this))
        },
        attached: function() {
            this._observer = this._observeItems(this), this._updateItems(), this._shouldUpdateSelection || this._updateSelected(), this._addListener(this.activateEvent)
        },
        detached: function() {
            this._observer && Polymer.dom(this).unobserveNodes(this._observer), this._removeListener(this.activateEvent)
        },
        indexOf: function(item) {
            return this.items.indexOf(item)
        },
        select: function(value) {
            this.selected = value
        },
        selectPrevious: function() {
            var length = this.items.length,
                index = (Number(this._valueToIndex(this.selected)) - 1 + length) % length;
            this.selected = this._indexToValue(index)
        },
        selectNext: function() {
            var index = (Number(this._valueToIndex(this.selected)) + 1) % this.items.length;
            this.selected = this._indexToValue(index)
        },
        selectIndex: function(index) {
            this.select(this._indexToValue(index))
        },
        forceSynchronousItemUpdate: function() {
            this._updateItems()
        },
        get _shouldUpdateSelection() {
            return null != this.selected
        },
        _checkFallback: function() {
            this._shouldUpdateSelection && this._updateSelected()
        },
        _addListener: function(eventName) {
            this.listen(this, eventName, "_activateHandler")
        },
        _removeListener: function(eventName) {
            this.unlisten(this, eventName, "_activateHandler")
        },
        _activateEventChanged: function(eventName, old) {
            this._removeListener(old), this._addListener(eventName)
        },
        _updateItems: function() {
            var nodes = Polymer.dom(this).queryDistributedElements(this.selectable || "*");
            nodes = Array.prototype.filter.call(nodes, this._bindFilterItem), this._setItems(nodes)
        },
        _updateAttrForSelected: function() {
            this._shouldUpdateSelection && (this.selected = this._indexToValue(this.indexOf(this.selectedItem)))
        },
        _updateSelected: function() {
            this._selectSelected(this.selected)
        },
        _selectSelected: function() {
            this._selection.select(this._valueToItem(this.selected)), this.fallbackSelection && this.items.length && void 0 === this._selection.get() && (this.selected = this.fallbackSelection)
        },
        _filterItem: function(node) {
            return !this._excludedLocalNames[node.localName]
        },
        _valueToItem: function(value) {
            return null == value ? null : this.items[this._valueToIndex(value)]
        },
        _valueToIndex: function(value) {
            if (!this.attrForSelected) return Number(value);
            for (var item, i = 0; item = this.items[i]; i++)
                if (this._valueForItem(item) == value) return i
        },
        _indexToValue: function(index) {
            if (!this.attrForSelected) return index;
            var item = this.items[index];
            return item ? this._valueForItem(item) : void 0
        },
        _valueForItem: function(item) {
            var propValue = item[Polymer.CaseMap.dashToCamelCase(this.attrForSelected)];
            return void 0 != propValue ? propValue : item.getAttribute(this.attrForSelected)
        },
        _applySelection: function(item, isSelected) {
            this.selectedClass && this.toggleClass(this.selectedClass, isSelected, item), this.selectedAttribute && this.toggleAttribute(this.selectedAttribute, isSelected, item), this._selectionChange(), this.fire("iron-" + (isSelected ? "select" : "deselect"), {
                item: item
            })
        },
        _selectionChange: function() {
            this._setSelectedItem(this._selection.get())
        },
        _observeItems: function(node) {
            return Polymer.dom(node).observeNodes(function(mutation) {
                this._updateItems(), this._shouldUpdateSelection && this._updateSelected(), this.fire("iron-items-changed", mutation, {
                    bubbles: !1,
                    cancelable: !1
                })
            })
        },
        _activateHandler: function(e) {
            for (var t = e.target, items = this.items; t && t != this;) {
                var i = items.indexOf(t);
                if (i >= 0) {
                    var value = this._indexToValue(i);
                    return void this._itemActivate(value, t)
                }
                t = t.parentNode
            }
        },
        _itemActivate: function(value, item) {
            this.fire("iron-activate", {
                selected: value,
                item: item
            }, {
                cancelable: !0
            }).defaultPrevented || this.select(value)
        }
    }, Polymer.IronMultiSelectableBehaviorImpl = {
        properties: {
            multi: {
                type: Boolean,
                value: !1,
                observer: "multiChanged"
            },
            selectedValues: {
                type: Array,
                notify: !0
            },
            selectedItems: {
                type: Array,
                readOnly: !0,
                notify: !0
            }
        },
        observers: ["_updateSelected(selectedValues.splices)"],
        select: function(value) {
            this.multi ? this.selectedValues ? this._toggleSelected(value) : this.selectedValues = [value] : this.selected = value
        },
        multiChanged: function(multi) {
            this._selection.multi = multi
        },
        get _shouldUpdateSelection() {
            return null != this.selected || null != this.selectedValues && this.selectedValues.length
        },
        _updateAttrForSelected: function() {
            this.multi ? this._shouldUpdateSelection && (this.selectedValues = this.selectedItems.map(function(selectedItem) {
                return this._indexToValue(this.indexOf(selectedItem))
            }, this).filter(function(unfilteredValue) {
                return null != unfilteredValue
            }, this)) : Polymer.IronSelectableBehavior._updateAttrForSelected.apply(this)
        },
        _updateSelected: function() {
            this.multi ? this._selectMulti(this.selectedValues) : this._selectSelected(this.selected)
        },
        _selectMulti: function(values) {
            if (values) {
                var selectedItems = this._valuesToItems(values);
                this._selection.clear(selectedItems);
                for (var i = 0; i < selectedItems.length; i++) this._selection.setItemSelected(selectedItems[i], !0);
                if (this.fallbackSelection && this.items.length && !this._selection.get().length) {
                    var fallback = this._valueToItem(this.fallbackSelection);
                    fallback && (this.selectedValues = [this.fallbackSelection])
                }
            } else this._selection.clear()
        },
        _selectionChange: function() {
            var s = this._selection.get();
            this.multi ? this._setSelectedItems(s) : (this._setSelectedItems([s]), this._setSelectedItem(s))
        },
        _toggleSelected: function(value) {
            var i = this.selectedValues.indexOf(value),
                unselected = 0 > i;
            unselected ? this.push("selectedValues", value) : this.splice("selectedValues", i, 1)
        },
        _valuesToItems: function(values) {
            return null == values ? null : values.map(function(value) {
                return this._valueToItem(value)
            }, this)
        }
    }, Polymer.IronMultiSelectableBehavior = [Polymer.IronSelectableBehavior, Polymer.IronMultiSelectableBehaviorImpl], Polymer.IronMenuBehaviorImpl = {
        properties: {
            focusedItem: {
                observer: "_focusedItemChanged",
                readOnly: !0,
                type: Object
            },
            attrForItemTitle: {
                type: String
            },
            disabled: {
                type: Boolean,
                value: !1,
                observer: "_disabledChanged"
            }
        },
        _SEARCH_RESET_TIMEOUT_MS: 1e3,
        _previousTabIndex: 0,
        hostAttributes: {
            role: "menu"
        },
        observers: ["_updateMultiselectable(multi)"],
        listeners: {
            focus: "_onFocus",
            keydown: "_onKeydown",
            "iron-items-changed": "_onIronItemsChanged"
        },
        keyBindings: {
            up: "_onUpKey",
            down: "_onDownKey",
            esc: "_onEscKey",
            "shift+tab:keydown": "_onShiftTabDown"
        },
        attached: function() {
            this._resetTabindices()
        },
        select: function(value) {
            this._defaultFocusAsync && (this.cancelAsync(this._defaultFocusAsync), this._defaultFocusAsync = null);
            var item = this._valueToItem(value);
            item && item.hasAttribute("disabled") || (this._setFocusedItem(item), Polymer.IronMultiSelectableBehaviorImpl.select.apply(this, arguments))
        },
        _resetTabindices: function() {
            var selectedItem = this.multi ? this.selectedItems && this.selectedItems[0] : this.selectedItem;
            this.items.forEach(function(item) {
                item.setAttribute("tabindex", item === selectedItem ? "0" : "-1")
            }, this)
        },
        _updateMultiselectable: function(multi) {
            multi ? this.setAttribute("aria-multiselectable", "true") : this.removeAttribute("aria-multiselectable")
        },
        _focusWithKeyboardEvent: function(event) {
            this.cancelDebouncer("_clearSearchText");
            var searchText = this._searchText || "",
                key = event.key && 1 == event.key.length ? event.key : String.fromCharCode(event.keyCode);
            searchText += key.toLocaleLowerCase();
            for (var item, searchLength = searchText.length, i = 0; item = this.items[i]; i++)
                if (!item.hasAttribute("disabled")) {
                    var attr = this.attrForItemTitle || "textContent",
                        title = (item[attr] || item.getAttribute(attr) || "").trim();
                    if (!(title.length < searchLength) && title.slice(0, searchLength).toLocaleLowerCase() == searchText) {
                        this._setFocusedItem(item);
                        break
                    }
                }
            this._searchText = searchText, this.debounce("_clearSearchText", this._clearSearchText, this._SEARCH_RESET_TIMEOUT_MS)
        },
        _clearSearchText: function() {
            this._searchText = ""
        },
        _focusPrevious: function() {
            for (var length = this.items.length, curFocusIndex = Number(this.indexOf(this.focusedItem)), i = 1; length + 1 > i; i++) {
                var item = this.items[(curFocusIndex - i + length) % length];
                if (!item.hasAttribute("disabled")) {
                    var owner = Polymer.dom(item).getOwnerRoot() || document;
                    if (this._setFocusedItem(item), Polymer.dom(owner).activeElement == item) return
                }
            }
        },
        _focusNext: function() {
            for (var length = this.items.length, curFocusIndex = Number(this.indexOf(this.focusedItem)), i = 1; length + 1 > i; i++) {
                var item = this.items[(curFocusIndex + i) % length];
                if (!item.hasAttribute("disabled")) {
                    var owner = Polymer.dom(item).getOwnerRoot() || document;
                    if (this._setFocusedItem(item), Polymer.dom(owner).activeElement == item) return
                }
            }
        },
        _applySelection: function(item, isSelected) {
            isSelected ? item.setAttribute("aria-selected", "true") : item.removeAttribute("aria-selected"), Polymer.IronSelectableBehavior._applySelection.apply(this, arguments)
        },
        _focusedItemChanged: function(focusedItem, old) {
            old && old.setAttribute("tabindex", "-1"), !focusedItem || focusedItem.hasAttribute("disabled") || this.disabled || (focusedItem.setAttribute("tabindex", "0"), focusedItem.focus())
        },
        _onIronItemsChanged: function(event) {
            event.detail.addedNodes.length && this._resetTabindices()
        },
        _onShiftTabDown: function() {
            var oldTabIndex = this.getAttribute("tabindex");
            Polymer.IronMenuBehaviorImpl._shiftTabPressed = !0, this._setFocusedItem(null), this.setAttribute("tabindex", "-1"), this.async(function() {
                this.setAttribute("tabindex", oldTabIndex), Polymer.IronMenuBehaviorImpl._shiftTabPressed = !1
            }, 1)
        },
        _onFocus: function(event) {
            if (!Polymer.IronMenuBehaviorImpl._shiftTabPressed) {
                var rootTarget = Polymer.dom(event).rootTarget;
                (rootTarget === this || "undefined" == typeof rootTarget.tabIndex || this.isLightDescendant(rootTarget)) && (this._defaultFocusAsync = this.async(function() {
                    var selectedItem = this.multi ? this.selectedItems && this.selectedItems[0] : this.selectedItem;
                    this._setFocusedItem(null), selectedItem ? this._setFocusedItem(selectedItem) : this.items[0] && this._focusNext()
                }))
            }
        },
        _onUpKey: function(event) {
            this._focusPrevious(), event.detail.keyboardEvent.preventDefault()
        },
        _onDownKey: function(event) {
            this._focusNext(), event.detail.keyboardEvent.preventDefault()
        },
        _onEscKey: function() {
            var focusedItem = this.focusedItem;
            focusedItem && focusedItem.blur()
        },
        _onKeydown: function(event) {
            this.keyboardEventMatchesKeys(event, "up down esc") || this._focusWithKeyboardEvent(event), event.stopPropagation()
        },
        _activateHandler: function(event) {
            Polymer.IronSelectableBehavior._activateHandler.call(this, event), event.stopPropagation()
        },
        _disabledChanged: function(disabled) {
            disabled ? (this._previousTabIndex = this.hasAttribute("tabindex") ? this.tabIndex : 0, this.removeAttribute("tabindex")) : this.hasAttribute("tabindex") || this.setAttribute("tabindex", this._previousTabIndex)
        }
    }, Polymer.IronMenuBehaviorImpl._shiftTabPressed = !1, Polymer.IronMenuBehavior = [Polymer.IronMultiSelectableBehavior, Polymer.IronA11yKeysBehavior, Polymer.IronMenuBehaviorImpl],
    function() {
        Polymer({
            is: "paper-menu",
            behaviors: [Polymer.IronMenuBehavior]
        })
    }(), Polymer.IronFormElementBehavior = {
        properties: {
            name: {
                type: String
            },
            value: {
                notify: !0,
                type: String
            },
            required: {
                type: Boolean,
                value: !1
            },
            _parentForm: {
                type: Object
            }
        },
        attached: Polymer.Element ? null : function() {
            this.fire("iron-form-element-register")
        },
        detached: Polymer.Element ? null : function() {
            this._parentForm && this._parentForm.fire("iron-form-element-unregister", {
                target: this
            })
        }
    }, Polymer.IronValidatableBehaviorMeta = null, Polymer.IronValidatableBehavior = {
        properties: {
            validator: {
                type: String
            },
            invalid: {
                notify: !0,
                reflectToAttribute: !0,
                type: Boolean,
                value: !1
            },
            _validatorMeta: {
                type: Object
            },
            validatorType: {
                type: String,
                value: "validator"
            },
            _validator: {
                type: Object,
                computed: "__computeValidator(validator)"
            }
        },
        observers: ["_invalidChanged(invalid)"],
        registered: function() {
            Polymer.IronValidatableBehaviorMeta = new Polymer.IronMeta({
                type: "validator"
            })
        },
        _invalidChanged: function() {
            this.invalid ? this.setAttribute("aria-invalid", "true") : this.removeAttribute("aria-invalid")
        },
        hasValidator: function() {
            return null != this._validator
        },
        validate: function(value) {
            return this.invalid = !this._getValidity(value), !this.invalid
        },
        _getValidity: function(value) {
            return this.hasValidator() ? this._validator.validate(value) : !0
        },
        __computeValidator: function() {
            return Polymer.IronValidatableBehaviorMeta && Polymer.IronValidatableBehaviorMeta.byKey(this.validator)
        }
    },
    function() {
        "use strict";
        Polymer.IronA11yAnnouncer = Polymer({
            is: "iron-a11y-announcer",
            properties: {
                mode: {
                    type: String,
                    value: "polite"
                },
                _text: {
                    type: String,
                    value: ""
                }
            },
            created: function() {
                Polymer.IronA11yAnnouncer.instance || (Polymer.IronA11yAnnouncer.instance = this), document.body.addEventListener("iron-announce", this._onIronAnnounce.bind(this))
            },
            announce: function(text) {
                this._text = "", this.async(function() {
                    this._text = text
                }, 100)
            },
            _onIronAnnounce: function(event) {
                event.detail && event.detail.text && this.announce(event.detail.text)
            }
        }), Polymer.IronA11yAnnouncer.instance = null, Polymer.IronA11yAnnouncer.requestAvailability = function() {
            Polymer.IronA11yAnnouncer.instance || (Polymer.IronA11yAnnouncer.instance = document.createElement("iron-a11y-announcer")), document.body.appendChild(Polymer.IronA11yAnnouncer.instance)
        }
    }(), Polymer({
        is: "iron-input",
        "extends": "input",
        behaviors: [Polymer.IronValidatableBehavior],
        properties: {
            bindValue: {
                observer: "_bindValueChanged",
                type: String
            },
            preventInvalidInput: {
                type: Boolean
            },
            allowedPattern: {
                type: String,
                observer: "_allowedPatternChanged"
            },
            _previousValidInput: {
                type: String,
                value: ""
            },
            _patternAlreadyChecked: {
                type: Boolean,
                value: !1
            }
        },
        listeners: {
            input: "_onInput",
            keypress: "_onKeypress"
        },
        registered: function() {
            this._canDispatchEventOnDisabled() || (this._origDispatchEvent = this.dispatchEvent, this.dispatchEvent = this._dispatchEventFirefoxIE)
        },
        created: function() {
            Polymer.IronA11yAnnouncer.requestAvailability()
        },
        _canDispatchEventOnDisabled: function() {
            var input = document.createElement("input"),
                canDispatch = !1;
            input.disabled = !0, input.addEventListener("feature-check-dispatch-event", function() {
                canDispatch = !0
            });
            try {
                input.dispatchEvent(new Event("feature-check-dispatch-event"))
            } catch (e) {}
            return canDispatch
        },
        _dispatchEventFirefoxIE: function() {
            var disabled = this.disabled;
            this.disabled = !1, this._origDispatchEvent.apply(this, arguments), this.disabled = disabled
        },
        get _patternRegExp() {
            var pattern;
            if (this.allowedPattern) pattern = new RegExp(this.allowedPattern);
            else switch (this.type) {
                case "number":
                    pattern = /[0-9.,e-]/
            }
            return pattern
        },
        ready: function() {
            this.bindValue = this.value
        },
        _bindValueChanged: function() {
            this.value !== this.bindValue && (this.value = this.bindValue || 0 === this.bindValue || this.bindValue === !1 ? this.bindValue : ""), this.fire("bind-value-changed", {
                value: this.bindValue
            })
        },
        _allowedPatternChanged: function() {
            this.preventInvalidInput = this.allowedPattern ? !0 : !1
        },
        _onInput: function() {
            if (this.preventInvalidInput && !this._patternAlreadyChecked) {
                var valid = this._checkPatternValidity();
                valid || (this._announceInvalidCharacter("Invalid string of characters not entered."), this.value = this._previousValidInput)
            }
            this.bindValue = this.value, this._previousValidInput = this.value, this._patternAlreadyChecked = !1
        },
        _isPrintable: function(event) {
            var anyNonPrintable = 8 == event.keyCode || 9 == event.keyCode || 13 == event.keyCode || 27 == event.keyCode,
                mozNonPrintable = 19 == event.keyCode || 20 == event.keyCode || 45 == event.keyCode || 46 == event.keyCode || 144 == event.keyCode || 145 == event.keyCode || event.keyCode > 32 && event.keyCode < 41 || event.keyCode > 111 && event.keyCode < 124;
            return !(anyNonPrintable || 0 == event.charCode && mozNonPrintable)
        },
        _onKeypress: function(event) {
            if (this.preventInvalidInput || "number" === this.type) {
                var regexp = this._patternRegExp;
                if (regexp && !(event.metaKey || event.ctrlKey || event.altKey)) {
                    this._patternAlreadyChecked = !0;
                    var thisChar = String.fromCharCode(event.charCode);
                    this._isPrintable(event) && !regexp.test(thisChar) && (event.preventDefault(), this._announceInvalidCharacter("Invalid character " + thisChar + " not entered."))
                }
            }
        },
        _checkPatternValidity: function() {
            var regexp = this._patternRegExp;
            if (!regexp) return !0;
            for (var i = 0; i < this.value.length; i++)
                if (!regexp.test(this.value[i])) return !1;
            return !0
        },
        validate: function() {
            var valid = this.checkValidity();
            return valid && (this.required && "" === this.value ? valid = !1 : this.hasValidator() && (valid = Polymer.IronValidatableBehavior.validate.call(this, this.value))), this.invalid = !valid, this.fire("iron-input-validate"), valid
        },
        _announceInvalidCharacter: function(message) {
            this.fire("iron-announce", {
                text: message
            })
        }
    }), Polymer.PaperInputHelper = {}, Polymer.PaperInputHelper.NextLabelID = 1, Polymer.PaperInputHelper.NextAddonID = 1, Polymer.PaperInputBehaviorImpl = {
        properties: {
            label: {
                type: String
            },
            value: {
                notify: !0,
                type: String
            },
            disabled: {
                type: Boolean,
                value: !1
            },
            invalid: {
                type: Boolean,
                value: !1,
                notify: !0
            },
            preventInvalidInput: {
                type: Boolean
            },
            allowedPattern: {
                type: String
            },
            type: {
                type: String
            },
            list: {
                type: String
            },
            pattern: {
                type: String
            },
            required: {
                type: Boolean,
                value: !1
            },
            errorMessage: {
                type: String
            },
            charCounter: {
                type: Boolean,
                value: !1
            },
            noLabelFloat: {
                type: Boolean,
                value: !1
            },
            alwaysFloatLabel: {
                type: Boolean,
                value: !1
            },
            autoValidate: {
                type: Boolean,
                value: !1
            },
            validator: {
                type: String
            },
            autocomplete: {
                type: String,
                value: "off"
            },
            autofocus: {
                type: Boolean,
                observer: "_autofocusChanged"
            },
            inputmode: {
                type: String
            },
            minlength: {
                type: Number
            },
            maxlength: {
                type: Number
            },
            min: {
                type: String
            },
            max: {
                type: String
            },
            step: {
                type: String
            },
            name: {
                type: String
            },
            placeholder: {
                type: String,
                value: ""
            },
            readonly: {
                type: Boolean,
                value: !1
            },
            size: {
                type: Number
            },
            autocapitalize: {
                type: String,
                value: "none"
            },
            autocorrect: {
                type: String,
                value: "off"
            },
            autosave: {
                type: String
            },
            results: {
                type: Number
            },
            accept: {
                type: String
            },
            multiple: {
                type: Boolean
            },
            _ariaDescribedBy: {
                type: String,
                value: ""
            },
            _ariaLabelledBy: {
                type: String,
                value: ""
            }
        },
        listeners: {
            "addon-attached": "_onAddonAttached"
        },
        keyBindings: {
            "shift+tab:keydown": "_onShiftTabDown"
        },
        hostAttributes: {
            tabindex: 0
        },
        get inputElement() {
            return this.$.input
        },
        get _focusableElement() {
            return this.inputElement
        },
        registered: function() {
            this._typesThatHaveText = ["date", "datetime", "datetime-local", "month", "time", "week", "file"]
        },
        attached: function() {
            this._updateAriaLabelledBy(), this.inputElement && -1 !== this._typesThatHaveText.indexOf(this.inputElement.type) && (this.alwaysFloatLabel = !0)
        },
        _appendStringWithSpace: function(str, more) {
            return str = str ? str + " " + more : more
        },
        _onAddonAttached: function(event) {
            var target = event.path ? event.path[0] : event.target;
            if (target.id) this._ariaDescribedBy = this._appendStringWithSpace(this._ariaDescribedBy, target.id);
            else {
                var id = "paper-input-add-on-" + Polymer.PaperInputHelper.NextAddonID++;
                target.id = id, this._ariaDescribedBy = this._appendStringWithSpace(this._ariaDescribedBy, id)
            }
        },
        validate: function() {
            return this.inputElement.validate()
        },
        _focusBlurHandler: function(event) {
            Polymer.IronControlState._focusBlurHandler.call(this, event), this.focused && !this._shiftTabPressed && this._focusableElement.focus()
        },
        _onShiftTabDown: function() {
            var oldTabIndex = this.getAttribute("tabindex");
            this._shiftTabPressed = !0, this.setAttribute("tabindex", "-1"), this.async(function() {
                this.setAttribute("tabindex", oldTabIndex), this._shiftTabPressed = !1
            }, 1)
        },
        _handleAutoValidate: function() {
            this.autoValidate && this.validate()
        },
        updateValueAndPreserveCaret: function(newValue) {
            try {
                var start = this.inputElement.selectionStart;
                this.value = newValue, this.inputElement.selectionStart = start, this.inputElement.selectionEnd = start
            } catch (e) {
                this.value = newValue
            }
        },
        _computeAlwaysFloatLabel: function(alwaysFloatLabel, placeholder) {
            return placeholder || alwaysFloatLabel
        },
        _updateAriaLabelledBy: function() {
            var label = Polymer.dom(this.root).querySelector("label");
            if (!label) return void(this._ariaLabelledBy = "");
            var labelledBy;
            label.id ? labelledBy = label.id : (labelledBy = "paper-input-label-" + Polymer.PaperInputHelper.NextLabelID++, label.id = labelledBy), this._ariaLabelledBy = labelledBy
        },
        _onChange: function(event) {
            this.shadowRoot && this.fire(event.type, {
                sourceEvent: event
            }, {
                node: this,
                bubbles: event.bubbles,
                cancelable: event.cancelable
            })
        },
        _autofocusChanged: function() {
            if (this.autofocus && this._focusableElement) {
                var activeElement = document.activeElement,
                    isActiveElementValid = activeElement instanceof HTMLElement,
                    isSomeElementActive = isActiveElementValid && activeElement !== document.body && activeElement !== document.documentElement;
                isSomeElementActive || this._focusableElement.focus()
            }
        }
    }, Polymer.PaperInputBehavior = [Polymer.IronControlState, Polymer.IronA11yKeysBehavior, Polymer.PaperInputBehaviorImpl], Polymer.PaperInputAddonBehavior = {
        hostAttributes: {
            "add-on": ""
        },
        attached: function() {
            this.fire("addon-attached")
        },
        update: function() {}
    }, Polymer({
        is: "paper-input-char-counter",
        behaviors: [Polymer.PaperInputAddonBehavior],
        properties: {
            _charCounterStr: {
                type: String,
                value: "0"
            }
        },
        update: function(state) {
            if (state.inputElement) {
                state.value = state.value || "";
                var counter = state.value.toString().length.toString();
                state.inputElement.hasAttribute("maxlength") && (counter += "/" + state.inputElement.getAttribute("maxlength")), this._charCounterStr = counter
            }
        }
    }), Polymer({
        is: "paper-input-container",
        properties: {
            noLabelFloat: {
                type: Boolean,
                value: !1
            },
            alwaysFloatLabel: {
                type: Boolean,
                value: !1
            },
            attrForValue: {
                type: String,
                value: "bind-value"
            },
            autoValidate: {
                type: Boolean,
                value: !1
            },
            invalid: {
                observer: "_invalidChanged",
                type: Boolean,
                value: !1
            },
            focused: {
                readOnly: !0,
                type: Boolean,
                value: !1,
                notify: !0
            },
            _addons: {
                type: Array
            },
            _inputHasContent: {
                type: Boolean,
                value: !1
            },
            _inputSelector: {
                type: String,
                value: "input,textarea,.paper-input-input"
            },
            _boundOnFocus: {
                type: Function,
                value: function() {
                    return this._onFocus.bind(this)
                }
            },
            _boundOnBlur: {
                type: Function,
                value: function() {
                    return this._onBlur.bind(this)
                }
            },
            _boundOnInput: {
                type: Function,
                value: function() {
                    return this._onInput.bind(this)
                }
            },
            _boundValueChanged: {
                type: Function,
                value: function() {
                    return this._onValueChanged.bind(this)
                }
            }
        },
        listeners: {
            "addon-attached": "_onAddonAttached",
            "iron-input-validate": "_onIronInputValidate"
        },
        get _valueChangedEvent() {
            return this.attrForValue + "-changed"
        },
        get _propertyForValue() {
            return Polymer.CaseMap.dashToCamelCase(this.attrForValue)
        },
        get _inputElement() {
            return Polymer.dom(this).querySelector(this._inputSelector)
        },
        get _inputElementValue() {
            return this._inputElement[this._propertyForValue] || this._inputElement.value
        },
        ready: function() {
            this._addons || (this._addons = []), this.addEventListener("focus", this._boundOnFocus, !0), this.addEventListener("blur", this._boundOnBlur, !0)
        },
        attached: function() {
            this.attrForValue ? this._inputElement.addEventListener(this._valueChangedEvent, this._boundValueChanged) : this.addEventListener("input", this._onInput), "" != this._inputElementValue ? this._handleValueAndAutoValidate(this._inputElement) : this._handleValue(this._inputElement)
        },
        _onAddonAttached: function(event) {
            this._addons || (this._addons = []);
            var target = event.target; - 1 === this._addons.indexOf(target) && (this._addons.push(target), this.isAttached && this._handleValue(this._inputElement))
        },
        _onFocus: function() {
            this._setFocused(!0)
        },
        _onBlur: function() {
            this._setFocused(!1), this._handleValueAndAutoValidate(this._inputElement)
        },
        _onInput: function(event) {
            this._handleValueAndAutoValidate(event.target)
        },
        _onValueChanged: function(event) {
            this._handleValueAndAutoValidate(event.target)
        },
        _handleValue: function(inputElement) {
            var value = this._inputElementValue;
            this._inputHasContent = value || 0 === value || "number" === inputElement.type && !inputElement.checkValidity() ? !0 : !1, this.updateAddons({
                inputElement: inputElement,
                value: value,
                invalid: this.invalid
            })
        },
        _handleValueAndAutoValidate: function(inputElement) {
            if (this.autoValidate) {
                var valid;
                valid = inputElement.validate ? inputElement.validate(this._inputElementValue) : inputElement.checkValidity(), this.invalid = !valid
            }
            this._handleValue(inputElement)
        },
        _onIronInputValidate: function() {
            this.invalid = this._inputElement.invalid
        },
        _invalidChanged: function() {
            this._addons && this.updateAddons({
                invalid: this.invalid
            })
        },
        updateAddons: function(state) {
            for (var addon, index = 0; addon = this._addons[index]; index++) addon.update(state)
        },
        _computeInputContentClass: function(noLabelFloat, alwaysFloatLabel, focused, invalid, _inputHasContent) {
            var cls = "input-content";
            if (noLabelFloat) _inputHasContent && (cls += " label-is-hidden");
            else {
                var label = this.querySelector("label");
                alwaysFloatLabel || _inputHasContent ? (cls += " label-is-floating", this.$.labelAndInputContainer.style.position = "static", invalid ? cls += " is-invalid" : focused && (cls += " label-is-highlighted")) : label && (this.$.labelAndInputContainer.style.position = "relative")
            }
            return cls
        },
        _computeUnderlineClass: function(focused, invalid) {
            var cls = "underline";
            return invalid ? cls += " is-invalid" : focused && (cls += " is-highlighted"), cls
        },
        _computeAddOnContentClass: function(focused, invalid) {
            var cls = "add-on-content";
            return invalid ? cls += " is-invalid" : focused && (cls += " is-highlighted"), cls
        }
    }), Polymer({
        is: "paper-input-error",
        behaviors: [Polymer.PaperInputAddonBehavior],
        properties: {
            invalid: {
                readOnly: !0,
                reflectToAttribute: !0,
                type: Boolean
            }
        },
        update: function(state) {
            this._setInvalid(state.invalid)
        }
    }), Polymer({
        is: "paper-input",
        behaviors: [Polymer.IronFormElementBehavior, Polymer.PaperInputBehavior]
    }), Polymer.IronResizableBehavior = {
        properties: {
            _parentResizable: {
                type: Object,
                observer: "_parentResizableChanged"
            },
            _notifyingDescendant: {
                type: Boolean,
                value: !1
            }
        },
        listeners: {
            "iron-request-resize-notifications": "_onIronRequestResizeNotifications"
        },
        created: function() {
            this._interestedResizables = [], this._boundNotifyResize = this.notifyResize.bind(this)
        },
        attached: function() {
            this._requestResizeNotifications()
        },
        detached: function() {
            this._parentResizable ? this._parentResizable.stopResizeNotificationsFor(this) : window.removeEventListener("resize", this._boundNotifyResize), this._parentResizable = null
        },
        notifyResize: function() {
            this.isAttached && (this._interestedResizables.forEach(function(resizable) {
                this.resizerShouldNotify(resizable) && this._notifyDescendant(resizable)
            }, this), this._fireResize())
        },
        assignParentResizable: function(parentResizable) {
            this._parentResizable = parentResizable
        },
        stopResizeNotificationsFor: function(target) {
            var index = this._interestedResizables.indexOf(target);
            index > -1 && (this._interestedResizables.splice(index, 1), this.unlisten(target, "iron-resize", "_onDescendantIronResize"))
        },
        resizerShouldNotify: function() {
            return !0
        },
        _onDescendantIronResize: function(event) {
            return this._notifyingDescendant ? void event.stopPropagation() : void(Polymer.Settings.useShadow || this._fireResize())
        },
        _fireResize: function() {
            this.fire("iron-resize", null, {
                node: this,
                bubbles: !1
            })
        },
        _onIronRequestResizeNotifications: function(event) {
            var target = Polymer.dom(event).rootTarget;
            target !== this && (-1 === this._interestedResizables.indexOf(target) && (this._interestedResizables.push(target), this.listen(target, "iron-resize", "_onDescendantIronResize")), target.assignParentResizable(this), this._notifyDescendant(target), event.stopPropagation())
        },
        _parentResizableChanged: function(parentResizable) {
            parentResizable && window.removeEventListener("resize", this._boundNotifyResize)
        },
        _notifyDescendant: function(descendant) {
            this.isAttached && (this._notifyingDescendant = !0, descendant.notifyResize(), this._notifyingDescendant = !1)
        },
        _requestResizeNotifications: function() {
            if (this.isAttached)
                if ("loading" === document.readyState) {
                    var _requestResizeNotifications = this._requestResizeNotifications.bind(this);
                    document.addEventListener("readystatechange", function readystatechanged() {
                        document.removeEventListener("readystatechange", readystatechanged), _requestResizeNotifications()
                    })
                } else this.fire("iron-request-resize-notifications", null, {
                    node: this,
                    bubbles: !0,
                    cancelable: !0
                }), this._parentResizable || (window.addEventListener("resize", this._boundNotifyResize), this.notifyResize())
        }
    }, Polymer.IronFitBehavior = {
        properties: {
            sizingTarget: {
                type: Object,
                value: function() {
                    return this
                }
            },
            fitInto: {
                type: Object,
                value: window
            },
            noOverlap: {
                type: Boolean
            },
            positionTarget: {
                type: Element
            },
            horizontalAlign: {
                type: String
            },
            verticalAlign: {
                type: String
            },
            dynamicAlign: {
                type: Boolean
            },
            horizontalOffset: {
                type: Number,
                value: 0,
                notify: !0
            },
            verticalOffset: {
                type: Number,
                value: 0,
                notify: !0
            },
            autoFitOnAttach: {
                type: Boolean,
                value: !1
            },
            _fitInfo: {
                type: Object
            }
        },
        get _fitWidth() {
            var fitWidth;
            return fitWidth = this.fitInto === window ? this.fitInto.innerWidth : this.fitInto.getBoundingClientRect().width
        },
        get _fitHeight() {
            var fitHeight;
            return fitHeight = this.fitInto === window ? this.fitInto.innerHeight : this.fitInto.getBoundingClientRect().height
        },
        get _fitLeft() {
            var fitLeft;
            return fitLeft = this.fitInto === window ? 0 : this.fitInto.getBoundingClientRect().left
        },
        get _fitTop() {
            var fitTop;
            return fitTop = this.fitInto === window ? 0 : this.fitInto.getBoundingClientRect().top
        },
        get _defaultPositionTarget() {
            var parent = Polymer.dom(this).parentNode;
            return parent && parent.nodeType === Node.DOCUMENT_FRAGMENT_NODE && (parent = parent.host), parent
        },
        get _localeHorizontalAlign() {
            if (this._isRTL) {
                if ("right" === this.horizontalAlign) return "left";
                if ("left" === this.horizontalAlign) return "right"
            }
            return this.horizontalAlign
        },
        attached: function() {
            "undefined" == typeof this._isRTL && (this._isRTL = "rtl" == window.getComputedStyle(this).direction), this.positionTarget = this.positionTarget || this._defaultPositionTarget, this.autoFitOnAttach && ("none" === window.getComputedStyle(this).display ? setTimeout(function() {
                this.fit()
            }.bind(this)) : (window.ShadyDOM && ShadyDOM.flush(), this.fit()))
        },
        detached: function() {
            this.__deferredFit && (clearTimeout(this.__deferredFit), this.__deferredFit = null)
        },
        fit: function() {
            this.position(), this.constrain(), this.center()
        },
        _discoverInfo: function() {
            if (!this._fitInfo) {
                var target = window.getComputedStyle(this),
                    sizer = window.getComputedStyle(this.sizingTarget);
                this._fitInfo = {
                    inlineStyle: {
                        top: this.style.top || "",
                        left: this.style.left || "",
                        position: this.style.position || ""
                    },
                    sizerInlineStyle: {
                        maxWidth: this.sizingTarget.style.maxWidth || "",
                        maxHeight: this.sizingTarget.style.maxHeight || "",
                        boxSizing: this.sizingTarget.style.boxSizing || ""
                    },
                    positionedBy: {
                        vertically: "auto" !== target.top ? "top" : "auto" !== target.bottom ? "bottom" : null,
                        horizontally: "auto" !== target.left ? "left" : "auto" !== target.right ? "right" : null
                    },
                    sizedBy: {
                        height: "none" !== sizer.maxHeight,
                        width: "none" !== sizer.maxWidth,
                        minWidth: parseInt(sizer.minWidth, 10) || 0,
                        minHeight: parseInt(sizer.minHeight, 10) || 0
                    },
                    margin: {
                        top: parseInt(target.marginTop, 10) || 0,
                        right: parseInt(target.marginRight, 10) || 0,
                        bottom: parseInt(target.marginBottom, 10) || 0,
                        left: parseInt(target.marginLeft, 10) || 0
                    }
                }
            }
        },
        resetFit: function() {
            var info = this._fitInfo || {};
            for (var property in info.sizerInlineStyle) this.sizingTarget.style[property] = info.sizerInlineStyle[property];
            for (var property in info.inlineStyle) this.style[property] = info.inlineStyle[property];
            this._fitInfo = null
        },
        refit: function() {
            var scrollLeft = this.sizingTarget.scrollLeft,
                scrollTop = this.sizingTarget.scrollTop;
            this.resetFit(), this.fit(), this.sizingTarget.scrollLeft = scrollLeft, this.sizingTarget.scrollTop = scrollTop
        },
        position: function() {
            if (this.horizontalAlign || this.verticalAlign) {
                this._discoverInfo(), this.style.position = "fixed", this.sizingTarget.style.boxSizing = "border-box", this.style.left = "0px", this.style.top = "0px";
                var rect = this.getBoundingClientRect(),
                    positionRect = this.__getNormalizedRect(this.positionTarget),
                    fitRect = this.__getNormalizedRect(this.fitInto),
                    margin = this._fitInfo.margin,
                    size = {
                        width: rect.width + margin.left + margin.right,
                        height: rect.height + margin.top + margin.bottom
                    },
                    position = this.__getPosition(this._localeHorizontalAlign, this.verticalAlign, size, positionRect, fitRect),
                    left = position.left + margin.left,
                    top = position.top + margin.top,
                    right = Math.min(fitRect.right - margin.right, left + rect.width),
                    bottom = Math.min(fitRect.bottom - margin.bottom, top + rect.height);
                left = Math.max(fitRect.left + margin.left, Math.min(left, right - this._fitInfo.sizedBy.minWidth)), top = Math.max(fitRect.top + margin.top, Math.min(top, bottom - this._fitInfo.sizedBy.minHeight)), this.sizingTarget.style.maxWidth = Math.max(right - left, this._fitInfo.sizedBy.minWidth) + "px", this.sizingTarget.style.maxHeight = Math.max(bottom - top, this._fitInfo.sizedBy.minHeight) + "px", this.style.left = left - rect.left + "px", this.style.top = top - rect.top + "px"
            }
        },
        constrain: function() {
            if (!this.horizontalAlign && !this.verticalAlign) {
                this._discoverInfo();
                var info = this._fitInfo;
                info.positionedBy.vertically || (this.style.position = "fixed", this.style.top = "0px"), info.positionedBy.horizontally || (this.style.position = "fixed", this.style.left = "0px"), this.sizingTarget.style.boxSizing = "border-box";
                var rect = this.getBoundingClientRect();
                info.sizedBy.height || this.__sizeDimension(rect, info.positionedBy.vertically, "top", "bottom", "Height"), info.sizedBy.width || this.__sizeDimension(rect, info.positionedBy.horizontally, "left", "right", "Width")
            }
        },
        _sizeDimension: function(rect, positionedBy, start, end, extent) {
            this.__sizeDimension(rect, positionedBy, start, end, extent)
        },
        __sizeDimension: function(rect, positionedBy, start, end, extent) {
            var info = this._fitInfo,
                fitRect = this.__getNormalizedRect(this.fitInto),
                max = "Width" === extent ? fitRect.width : fitRect.height,
                flip = positionedBy === end,
                offset = flip ? max - rect[end] : rect[start],
                margin = info.margin[flip ? start : end],
                offsetExtent = "offset" + extent,
                sizingOffset = this[offsetExtent] - this.sizingTarget[offsetExtent];
            this.sizingTarget.style["max" + extent] = max - margin - offset - sizingOffset + "px"
        },
        center: function() {
            if (!this.horizontalAlign && !this.verticalAlign) {
                this._discoverInfo();
                var positionedBy = this._fitInfo.positionedBy;
                if (!positionedBy.vertically || !positionedBy.horizontally) {
                    this.style.position = "fixed", positionedBy.vertically || (this.style.top = "0px"), positionedBy.horizontally || (this.style.left = "0px");
                    var rect = this.getBoundingClientRect(),
                        fitRect = this.__getNormalizedRect(this.fitInto);
                    if (!positionedBy.vertically) {
                        var top = fitRect.top - rect.top + (fitRect.height - rect.height) / 2;
                        this.style.top = top + "px"
                    }
                    if (!positionedBy.horizontally) {
                        var left = fitRect.left - rect.left + (fitRect.width - rect.width) / 2;
                        this.style.left = left + "px"
                    }
                }
            }
        },
        __getNormalizedRect: function(target) {
            return target === document.documentElement || target === window ? {
                top: 0,
                left: 0,
                width: window.innerWidth,
                height: window.innerHeight,
                right: window.innerWidth,
                bottom: window.innerHeight
            } : target.getBoundingClientRect()
        },
        __getCroppedArea: function(position, size, fitRect) {
            var verticalCrop = Math.min(0, position.top) + Math.min(0, fitRect.bottom - (position.top + size.height)),
                horizontalCrop = Math.min(0, position.left) + Math.min(0, fitRect.right - (position.left + size.width));
            return Math.abs(verticalCrop) * size.width + Math.abs(horizontalCrop) * size.height
        },
        __getPosition: function(hAlign, vAlign, size, positionRect, fitRect) {
            var positions = [{
                verticalAlign: "top",
                horizontalAlign: "left",
                top: positionRect.top + this.verticalOffset,
                left: positionRect.left + this.horizontalOffset
            }, {
                verticalAlign: "top",
                horizontalAlign: "right",
                top: positionRect.top + this.verticalOffset,
                left: positionRect.right - size.width - this.horizontalOffset
            }, {
                verticalAlign: "bottom",
                horizontalAlign: "left",
                top: positionRect.bottom - size.height - this.verticalOffset,
                left: positionRect.left + this.horizontalOffset
            }, {
                verticalAlign: "bottom",
                horizontalAlign: "right",
                top: positionRect.bottom - size.height - this.verticalOffset,
                left: positionRect.right - size.width - this.horizontalOffset
            }];
            if (this.noOverlap) {
                for (var i = 0, l = positions.length; l > i; i++) {
                    var copy = {};
                    for (var key in positions[i]) copy[key] = positions[i][key];
                    positions.push(copy)
                }
                positions[0].top = positions[1].top += positionRect.height, positions[2].top = positions[3].top -= positionRect.height, positions[4].left = positions[6].left += positionRect.width, positions[5].left = positions[7].left -= positionRect.width
            }
            vAlign = "auto" === vAlign ? null : vAlign, hAlign = "auto" === hAlign ? null : hAlign;
            for (var position, i = 0; i < positions.length; i++) {
                var pos = positions[i];
                if (!this.dynamicAlign && !this.noOverlap && pos.verticalAlign === vAlign && pos.horizontalAlign === hAlign) {
                    position = pos;
                    break
                }
                var alignOk = !(vAlign && pos.verticalAlign !== vAlign || hAlign && pos.horizontalAlign !== hAlign);
                if (this.dynamicAlign || alignOk) {
                    position = position || pos, pos.croppedArea = this.__getCroppedArea(pos, size, fitRect);
                    var diff = pos.croppedArea - position.croppedArea;
                    if ((0 > diff || 0 === diff && alignOk) && (position = pos), 0 === position.croppedArea && alignOk) break
                }
            }
            return position
        }
    },
    function() {
        "use strict";
        Polymer({
            is: "iron-overlay-backdrop",
            properties: {
                opened: {
                    reflectToAttribute: !0,
                    type: Boolean,
                    value: !1,
                    observer: "_openedChanged"
                }
            },
            listeners: {
                transitionend: "_onTransitionend"
            },
            created: function() {
                this.__openedRaf = null
            },
            attached: function() {
                this.opened && this._openedChanged(this.opened)
            },
            prepare: function() {
                this.opened && !this.parentNode && Polymer.dom(document.body).appendChild(this)
            },
            open: function() {
                this.opened = !0
            },
            close: function() {
                this.opened = !1
            },
            complete: function() {
                this.opened || this.parentNode !== document.body || Polymer.dom(this.parentNode).removeChild(this)
            },
            _onTransitionend: function(event) {
                event && event.target === this && this.complete()
            },
            _openedChanged: function(opened) {
                if (opened) this.prepare();
                else {
                    var cs = window.getComputedStyle(this);
                    ("0s" === cs.transitionDuration || 0 == cs.opacity) && this.complete()
                }
                this.isAttached && (this.__openedRaf && (window.cancelAnimationFrame(this.__openedRaf), this.__openedRaf = null), this.scrollTop = this.scrollTop, this.__openedRaf = window.requestAnimationFrame(function() {
                    this.__openedRaf = null, this.toggleClass("opened", this.opened)
                }.bind(this)))
            }
        })
    }(), Polymer.IronOverlayManagerClass = function() {
        this._overlays = [], this._minimumZ = 101, this._backdropElement = null, Polymer.Gestures.add(document.documentElement, "tap", null), document.addEventListener("tap", this._onCaptureClick.bind(this), !0), document.addEventListener("focus", this._onCaptureFocus.bind(this), !0), document.addEventListener("keydown", this._onCaptureKeyDown.bind(this), !0)
    }, Polymer.IronOverlayManagerClass.prototype = {
        constructor: Polymer.IronOverlayManagerClass,
        get backdropElement() {
            return this._backdropElement || (this._backdropElement = document.createElement("iron-overlay-backdrop")), this._backdropElement
        },
        get deepActiveElement() {
            for (var active = document.activeElement || document.body; active.root && Polymer.dom(active.root).activeElement;) active = Polymer.dom(active.root).activeElement;
            return active
        },
        _bringOverlayAtIndexToFront: function(i) {
            var overlay = this._overlays[i];
            if (overlay) {
                var lastI = this._overlays.length - 1,
                    currentOverlay = this._overlays[lastI];
                if (currentOverlay && this._shouldBeBehindOverlay(overlay, currentOverlay) && lastI--, !(i >= lastI)) {
                    var minimumZ = Math.max(this.currentOverlayZ(), this._minimumZ);
                    for (this._getZ(overlay) <= minimumZ && this._applyOverlayZ(overlay, minimumZ); lastI > i;) this._overlays[i] = this._overlays[i + 1], i++;
                    this._overlays[lastI] = overlay
                }
            }
        },
        addOrRemoveOverlay: function(overlay) {
            overlay.opened ? this.addOverlay(overlay) : this.removeOverlay(overlay)
        },
        addOverlay: function(overlay) {
            var i = this._overlays.indexOf(overlay);
            if (i >= 0) return this._bringOverlayAtIndexToFront(i), void this.trackBackdrop();
            var insertionIndex = this._overlays.length,
                currentOverlay = this._overlays[insertionIndex - 1],
                minimumZ = Math.max(this._getZ(currentOverlay), this._minimumZ),
                newZ = this._getZ(overlay);
            if (currentOverlay && this._shouldBeBehindOverlay(overlay, currentOverlay)) {
                this._applyOverlayZ(currentOverlay, minimumZ), insertionIndex--;
                var previousOverlay = this._overlays[insertionIndex - 1];
                minimumZ = Math.max(this._getZ(previousOverlay), this._minimumZ)
            }
            minimumZ >= newZ && this._applyOverlayZ(overlay, minimumZ), this._overlays.splice(insertionIndex, 0, overlay), this.trackBackdrop()
        },
        removeOverlay: function(overlay) {
            var i = this._overlays.indexOf(overlay); - 1 !== i && (this._overlays.splice(i, 1), this.trackBackdrop())
        },
        currentOverlay: function() {
            var i = this._overlays.length - 1;
            return this._overlays[i]
        },
        currentOverlayZ: function() {
            return this._getZ(this.currentOverlay())
        },
        ensureMinimumZ: function(minimumZ) {
            this._minimumZ = Math.max(this._minimumZ, minimumZ)
        },
        focusOverlay: function() {
            var current = this.currentOverlay();
            current && current._applyFocus()
        },
        trackBackdrop: function() {
            var overlay = this._overlayWithBackdrop();
            (overlay || this._backdropElement) && (this.backdropElement.style.zIndex = this._getZ(overlay) - 1, this.backdropElement.opened = !!overlay, this.backdropElement.prepare())
        },
        getBackdrops: function() {
            for (var backdrops = [], i = 0; i < this._overlays.length; i++) this._overlays[i].withBackdrop && backdrops.push(this._overlays[i]);
            return backdrops
        },
        backdropZ: function() {
            return this._getZ(this._overlayWithBackdrop()) - 1
        },
        _overlayWithBackdrop: function() {
            for (var i = 0; i < this._overlays.length; i++)
                if (this._overlays[i].withBackdrop) return this._overlays[i]
        },
        _getZ: function(overlay) {
            var z = this._minimumZ;
            if (overlay) {
                var z1 = Number(overlay.style.zIndex || window.getComputedStyle(overlay).zIndex);
                z1 === z1 && (z = z1)
            }
            return z
        },
        _setZ: function(element, z) {
            element.style.zIndex = z
        },
        _applyOverlayZ: function(overlay, aboveZ) {
            this._setZ(overlay, aboveZ + 2)
        },
        _overlayInPath: function(path) {
            path = path || [];
            for (var i = 0; i < path.length; i++)
                if (path[i]._manager === this) return path[i]
        },
        _onCaptureClick: function(event) {
            var overlay = this.currentOverlay();
            overlay && this._overlayInPath(Polymer.dom(event).path) !== overlay && overlay._onCaptureClick(event)
        },
        _onCaptureFocus: function(event) {
            var overlay = this.currentOverlay();
            overlay && overlay._onCaptureFocus(event)
        },
        _onCaptureKeyDown: function(event) {
            var overlay = this.currentOverlay();
            overlay && (Polymer.IronA11yKeysBehavior.keyboardEventMatchesKeys(event, "esc") ? overlay._onCaptureEsc(event) : Polymer.IronA11yKeysBehavior.keyboardEventMatchesKeys(event, "tab") && overlay._onCaptureTab(event))
        },
        _shouldBeBehindOverlay: function(overlay1, overlay2) {
            return !overlay1.alwaysOnTop && overlay2.alwaysOnTop
        }
    }, Polymer.IronOverlayManager = new Polymer.IronOverlayManagerClass,
    function() {
        "use strict";
        var p = Element.prototype,
            matches = p.matches || p.matchesSelector || p.mozMatchesSelector || p.msMatchesSelector || p.oMatchesSelector || p.webkitMatchesSelector;
        Polymer.IronFocusablesHelper = {
            getTabbableNodes: function(node) {
                var result = [],
                    needsSortByTabIndex = this._collectTabbableNodes(node, result);
                return needsSortByTabIndex ? this._sortByTabIndex(result) : result
            },
            isFocusable: function(element) {
                return matches.call(element, "input, select, textarea, button, object") ? matches.call(element, ":not([disabled])") : matches.call(element, "a[href], area[href], iframe, [tabindex], [contentEditable]")
            },
            isTabbable: function(element) {
                return this.isFocusable(element) && matches.call(element, ':not([tabindex="-1"])') && this._isVisible(element)
            },
            _normalizedTabIndex: function(element) {
                if (this.isFocusable(element)) {
                    var tabIndex = element.getAttribute("tabindex") || 0;
                    return Number(tabIndex)
                }
                return -1
            },
            _collectTabbableNodes: function(node, result) {
                if (node.nodeType !== Node.ELEMENT_NODE || !this._isVisible(node)) return !1;
                var element = node,
                    tabIndex = this._normalizedTabIndex(element),
                    needsSort = tabIndex > 0;
                tabIndex >= 0 && result.push(element);
                var children;
                children = "content" === element.localName || "slot" === element.localName ? Polymer.dom(element).getDistributedNodes() : Polymer.dom(element.root || element).children;
                for (var i = 0; i < children.length; i++) needsSort = this._collectTabbableNodes(children[i], result) || needsSort;
                return needsSort
            },
            _isVisible: function(element) {
                var style = element.style;
                return "hidden" !== style.visibility && "none" !== style.display ? (style = window.getComputedStyle(element),
                    "hidden" !== style.visibility && "none" !== style.display) : !1
            },
            _sortByTabIndex: function(tabbables) {
                var len = tabbables.length;
                if (2 > len) return tabbables;
                var pivot = Math.ceil(len / 2),
                    left = this._sortByTabIndex(tabbables.slice(0, pivot)),
                    right = this._sortByTabIndex(tabbables.slice(pivot));
                return this._mergeSortByTabIndex(left, right)
            },
            _mergeSortByTabIndex: function(left, right) {
                for (var result = []; left.length > 0 && right.length > 0;) result.push(this._hasLowerTabOrder(left[0], right[0]) ? right.shift() : left.shift());
                return result.concat(left, right)
            },
            _hasLowerTabOrder: function(a, b) {
                var ati = Math.max(a.tabIndex, 0),
                    bti = Math.max(b.tabIndex, 0);
                return 0 === ati || 0 === bti ? bti > ati : ati > bti
            }
        }
    }(),
    function() {
        "use strict";
        Polymer.IronOverlayBehaviorImpl = {
            properties: {
                opened: {
                    observer: "_openedChanged",
                    type: Boolean,
                    value: !1,
                    notify: !0
                },
                canceled: {
                    observer: "_canceledChanged",
                    readOnly: !0,
                    type: Boolean,
                    value: !1
                },
                withBackdrop: {
                    observer: "_withBackdropChanged",
                    type: Boolean
                },
                noAutoFocus: {
                    type: Boolean,
                    value: !1
                },
                noCancelOnEscKey: {
                    type: Boolean,
                    value: !1
                },
                noCancelOnOutsideClick: {
                    type: Boolean,
                    value: !1
                },
                closingReason: {
                    type: Object
                },
                restoreFocusOnClose: {
                    type: Boolean,
                    value: !1
                },
                alwaysOnTop: {
                    type: Boolean
                },
                _manager: {
                    type: Object,
                    value: Polymer.IronOverlayManager
                },
                _focusedChild: {
                    type: Object
                }
            },
            listeners: {
                "iron-resize": "_onIronResize"
            },
            get backdropElement() {
                return this._manager.backdropElement
            },
            get _focusNode() {
                return this._focusedChild || Polymer.dom(this).querySelector("[autofocus]") || this
            },
            get _focusableNodes() {
                return Polymer.IronFocusablesHelper.getTabbableNodes(this)
            },
            ready: function() {
                this.__isAnimating = !1, this.__shouldRemoveTabIndex = !1, this.__firstFocusableNode = this.__lastFocusableNode = null, this.__raf = null, this.__restoreFocusNode = null, this._ensureSetup()
            },
            attached: function() {
                this.opened && this._openedChanged(this.opened), this._observer = Polymer.dom(this).observeNodes(this._onNodesChange)
            },
            detached: function() {
                Polymer.dom(this).unobserveNodes(this._observer), this._observer = null, this.__raf && (window.cancelAnimationFrame(this.__raf), this.__raf = null), this._manager.removeOverlay(this)
            },
            toggle: function() {
                this._setCanceled(!1), this.opened = !this.opened
            },
            open: function() {
                this._setCanceled(!1), this.opened = !0
            },
            close: function() {
                this._setCanceled(!1), this.opened = !1
            },
            cancel: function(event) {
                var cancelEvent = this.fire("iron-overlay-canceled", event, {
                    cancelable: !0
                });
                cancelEvent.defaultPrevented || (this._setCanceled(!0), this.opened = !1)
            },
            invalidateTabbables: function() {
                this.__firstFocusableNode = this.__lastFocusableNode = null
            },
            _ensureSetup: function() {
                this._overlaySetup || (this._overlaySetup = !0, this.style.outline = "none", this.style.display = "none")
            },
            _openedChanged: function(opened) {
                opened ? this.removeAttribute("aria-hidden") : this.setAttribute("aria-hidden", "true"), this.isAttached && (this.__isAnimating = !0, this.__onNextAnimationFrame(this.__openedChanged))
            },
            _canceledChanged: function() {
                this.closingReason = this.closingReason || {}, this.closingReason.canceled = this.canceled
            },
            _withBackdropChanged: function() {
                this.withBackdrop && !this.hasAttribute("tabindex") ? (this.setAttribute("tabindex", "-1"), this.__shouldRemoveTabIndex = !0) : this.__shouldRemoveTabIndex && (this.removeAttribute("tabindex"), this.__shouldRemoveTabIndex = !1), this.opened && this.isAttached && this._manager.trackBackdrop()
            },
            _prepareRenderOpened: function() {
                this.__restoreFocusNode = this._manager.deepActiveElement, this._preparePositioning(), this.refit(), this._finishPositioning(), this.noAutoFocus && document.activeElement === this._focusNode && (this._focusNode.blur(), this.__restoreFocusNode.focus())
            },
            _renderOpened: function() {
                this._finishRenderOpened()
            },
            _renderClosed: function() {
                this._finishRenderClosed()
            },
            _finishRenderOpened: function() {
                this.notifyResize(), this.__isAnimating = !1, this.fire("iron-overlay-opened")
            },
            _finishRenderClosed: function() {
                this.style.display = "none", this.style.zIndex = "", this.notifyResize(), this.__isAnimating = !1, this.fire("iron-overlay-closed", this.closingReason)
            },
            _preparePositioning: function() {
                this.style.transition = this.style.webkitTransition = "none", this.style.transform = this.style.webkitTransform = "none", this.style.display = ""
            },
            _finishPositioning: function() {
                this.style.display = "none", this.scrollTop = this.scrollTop, this.style.transition = this.style.webkitTransition = "", this.style.transform = this.style.webkitTransform = "", this.style.display = "", this.scrollTop = this.scrollTop
            },
            _applyFocus: function() {
                if (this.opened) this.noAutoFocus || this._focusNode.focus();
                else {
                    this._focusNode.blur(), this._focusedChild = null, this.restoreFocusOnClose && this.__restoreFocusNode && this.__restoreFocusNode.focus(), this.__restoreFocusNode = null;
                    var currentOverlay = this._manager.currentOverlay();
                    currentOverlay && this !== currentOverlay && currentOverlay._applyFocus()
                }
            },
            _onCaptureClick: function(event) {
                this.noCancelOnOutsideClick || this.cancel(event)
            },
            _onCaptureFocus: function(event) {
                if (this.withBackdrop) {
                    var path = Polymer.dom(event).path; - 1 === path.indexOf(this) ? (event.stopPropagation(), this._applyFocus()) : this._focusedChild = path[0]
                }
            },
            _onCaptureEsc: function(event) {
                this.noCancelOnEscKey || this.cancel(event)
            },
            _onCaptureTab: function(event) {
                if (this.withBackdrop) {
                    this.__ensureFirstLastFocusables();
                    var shift = event.shiftKey,
                        nodeToCheck = shift ? this.__firstFocusableNode : this.__lastFocusableNode,
                        nodeToSet = shift ? this.__lastFocusableNode : this.__firstFocusableNode,
                        shouldWrap = !1;
                    if (nodeToCheck === nodeToSet) shouldWrap = !0;
                    else {
                        var focusedNode = this._manager.deepActiveElement;
                        shouldWrap = focusedNode === nodeToCheck || focusedNode === this
                    }
                    shouldWrap && (event.preventDefault(), this._focusedChild = nodeToSet, this._applyFocus())
                }
            },
            _onIronResize: function() {
                this.opened && !this.__isAnimating && this.__onNextAnimationFrame(this.refit)
            },
            _onNodesChange: function() {
                this.opened && !this.__isAnimating && (this.invalidateTabbables(), this.notifyResize())
            },
            __ensureFirstLastFocusables: function() {
                if (!this.__firstFocusableNode || !this.__lastFocusableNode) {
                    var focusableNodes = this._focusableNodes;
                    this.__firstFocusableNode = focusableNodes[0], this.__lastFocusableNode = focusableNodes[focusableNodes.length - 1]
                }
            },
            __openedChanged: function() {
                this.opened ? (this._prepareRenderOpened(), this._manager.addOverlay(this), this._applyFocus(), this._renderOpened()) : (this._manager.removeOverlay(this), this._applyFocus(), this._renderClosed())
            },
            __onNextAnimationFrame: function(callback) {
                this.__raf && window.cancelAnimationFrame(this.__raf);
                var self = this;
                this.__raf = window.requestAnimationFrame(function() {
                    self.__raf = null, callback.call(self)
                })
            }
        }, Polymer.IronOverlayBehavior = [Polymer.IronFitBehavior, Polymer.IronResizableBehavior, Polymer.IronOverlayBehaviorImpl]
    }(), Polymer.NeonAnimationBehavior = {
        properties: {
            animationTiming: {
                type: Object,
                value: function() {
                    return {
                        duration: 500,
                        easing: "cubic-bezier(0.4, 0, 0.2, 1)",
                        fill: "both"
                    }
                }
            }
        },
        isNeonAnimation: !0,
        timingFromConfig: function(config) {
            if (config.timing)
                for (var property in config.timing) this.animationTiming[property] = config.timing[property];
            return this.animationTiming
        },
        setPrefixedProperty: function(node, property, value) {
            for (var prefix, map = {
                    transform: ["webkitTransform"],
                    transformOrigin: ["mozTransformOrigin", "webkitTransformOrigin"]
                }, prefixes = map[property], index = 0; prefix = prefixes[index]; index++) node.style[prefix] = value;
            node.style[property] = value
        },
        complete: function() {}
    },
    function() {
        ! function(a, b) {
            var c = {},
                d = {},
                e = {},
                f = null;
            ! function(a) {
                function c(a) {
                    if ("number" == typeof a) return a;
                    var b = {};
                    for (var c in a) b[c] = a[c];
                    return b
                }

                function d() {
                    this._delay = 0, this._endDelay = 0, this._fill = "none", this._iterationStart = 0, this._iterations = 1, this._duration = 0, this._playbackRate = 1, this._direction = "normal", this._easing = "linear", this._easingFunction = w
                }

                function e() {
                    return a.isDeprecated("Invalid timing inputs", "2016-03-02", "TypeError exceptions will be thrown instead.", !0)
                }

                function f(b, c) {
                    var f = new d;
                    return c && (f.fill = "both", f.duration = "auto"), "number" != typeof b || isNaN(b) ? void 0 !== b && Object.getOwnPropertyNames(b).forEach(function(c) {
                        if ("auto" != b[c]) {
                            if (("number" == typeof f[c] || "duration" == c) && ("number" != typeof b[c] || isNaN(b[c]))) return;
                            if ("fill" == c && -1 == u.indexOf(b[c])) return;
                            if ("direction" == c && -1 == v.indexOf(b[c])) return;
                            if ("playbackRate" == c && 1 !== b[c] && a.isDeprecated("AnimationEffectTiming.playbackRate", "2014-11-28", "Use Animation.playbackRate instead.")) return;
                            f[c] = b[c]
                        }
                    }) : f.duration = b, f
                }

                function g(a) {
                    return "number" == typeof a && (a = isNaN(a) ? {
                        duration: 0
                    } : {
                        duration: a
                    }), a
                }

                function h(b, c) {
                    return b = a.numericTimingToObject(b), f(b, c)
                }

                function i(a, b, c, d) {
                    return 0 > a || a > 1 || 0 > c || c > 1 ? w : function(e) {
                        function f(a, b, c) {
                            return 3 * a * (1 - c) * (1 - c) * c + 3 * b * (1 - c) * c * c + c * c * c
                        }
                        if (0 == e || 1 == e) return e;
                        for (var g = 0, h = 1;;) {
                            var i = (g + h) / 2,
                                j = f(a, c, i);
                            if (Math.abs(e - j) < 1e-4) return f(b, d, i);
                            e > j ? g = i : h = i
                        }
                    }
                }

                function j(a, b) {
                    return function(c) {
                        if (c >= 1) return 1;
                        var d = 1 / a;
                        return c += b * d, c - c % d
                    }
                }

                function k(a) {
                    B || (B = document.createElement("div").style), B.animationTimingFunction = "", B.animationTimingFunction = a;
                    var b = B.animationTimingFunction;
                    if ("" == b && e()) throw new TypeError(a + " is not a valid value for easing");
                    var c = D.exec(b);
                    if (c) return i.apply(this, c.slice(1).map(Number));
                    var d = E.exec(b);
                    if (d) return j(Number(d[1]), {
                        start: x,
                        middle: y,
                        end: z
                    }[d[2]]);
                    var f = A[b];
                    return f ? f : w
                }

                function l(a) {
                    return Math.abs(m(a) / a.playbackRate)
                }

                function m(a) {
                    return a.duration * a.iterations
                }

                function n(a, b, c) {
                    return null == b ? F : b < c.delay ? G : b >= c.delay + a ? H : I
                }

                function o(a, b, c, d, e) {
                    switch (d) {
                        case G:
                            return "backwards" == b || "both" == b ? 0 : null;
                        case I:
                            return c - e;
                        case H:
                            return "forwards" == b || "both" == b ? a : null;
                        case F:
                            return null
                    }
                }

                function p(a, b, c, d) {
                    return (d.playbackRate < 0 ? b - a : b) * d.playbackRate + c
                }

                function q(a, b, c, d, e) {
                    return c === 1 / 0 || c === -(1 / 0) || c - d == b && e.iterations && (e.iterations + e.iterationStart) % 1 == 0 ? a : c % a
                }

                function r(a, b, c, d) {
                    return 0 === c ? 0 : b == a ? d.iterationStart + d.iterations - 1 : Math.floor(c / a)
                }

                function s(a, b, c, d) {
                    var e = a % 2 >= 1,
                        f = "normal" == d.direction || d.direction == (e ? "alternate-reverse" : "alternate"),
                        g = f ? c : b - c,
                        h = g / b;
                    return b * d._easingFunction(h)
                }

                function t(a, b, c) {
                    var d = n(a, b, c),
                        e = o(a, c.fill, b, d, c.delay);
                    if (null === e) return null;
                    if (0 === a) return d === G ? 0 : 1;
                    var f = c.iterationStart * c.duration,
                        g = p(a, e, f, c),
                        h = q(c.duration, m(c), g, f, c),
                        i = r(c.duration, h, g, c);
                    return s(i, c.duration, h, c) / c.duration
                }
                var u = "backwards|forwards|both|none".split("|"),
                    v = "reverse|alternate|alternate-reverse".split("|"),
                    w = function(a) {
                        return a
                    };
                d.prototype = {
                    _setMember: function(b, c) {
                        this["_" + b] = c, this._effect && (this._effect._timingInput[b] = c, this._effect._timing = a.normalizeTimingInput(this._effect._timingInput), this._effect.activeDuration = a.calculateActiveDuration(this._effect._timing), this._effect._animation && this._effect._animation._rebuildUnderlyingAnimation())
                    },
                    get playbackRate() {
                        return this._playbackRate
                    },
                    set delay(a) {
                        this._setMember("delay", a)
                    },
                    get delay() {
                        return this._delay
                    },
                    set endDelay(a) {
                        this._setMember("endDelay", a)
                    },
                    get endDelay() {
                        return this._endDelay
                    },
                    set fill(a) {
                        this._setMember("fill", a)
                    },
                    get fill() {
                        return this._fill
                    },
                    set iterationStart(a) {
                        if ((isNaN(a) || 0 > a) && e()) throw new TypeError("iterationStart must be a non-negative number, received: " + timing.iterationStart);
                        this._setMember("iterationStart", a)
                    },
                    get iterationStart() {
                        return this._iterationStart
                    },
                    set duration(a) {
                        if ("auto" != a && (isNaN(a) || 0 > a) && e()) throw new TypeError("duration must be non-negative or auto, received: " + a);
                        this._setMember("duration", a)
                    },
                    get duration() {
                        return this._duration
                    },
                    set direction(a) {
                        this._setMember("direction", a)
                    },
                    get direction() {
                        return this._direction
                    },
                    set easing(a) {
                        this._easingFunction = k(a), this._setMember("easing", a)
                    },
                    get easing() {
                        return this._easing
                    },
                    set iterations(a) {
                        if ((isNaN(a) || 0 > a) && e()) throw new TypeError("iterations must be non-negative, received: " + a);
                        this._setMember("iterations", a)
                    },
                    get iterations() {
                        return this._iterations
                    }
                };
                var x = 1,
                    y = .5,
                    z = 0,
                    A = {
                        ease: i(.25, .1, .25, 1),
                        "ease-in": i(.42, 0, 1, 1),
                        "ease-out": i(0, 0, .58, 1),
                        "ease-in-out": i(.42, 0, .58, 1),
                        "step-start": j(1, x),
                        "step-middle": j(1, y),
                        "step-end": j(1, z)
                    },
                    B = null,
                    C = "\\s*(-?\\d+\\.?\\d*|-?\\.\\d+)\\s*",
                    D = new RegExp("cubic-bezier\\(" + C + "," + C + "," + C + "," + C + "\\)"),
                    E = /steps\(\s*(\d+)\s*,\s*(start|middle|end)\s*\)/,
                    F = 0,
                    G = 1,
                    H = 2,
                    I = 3;
                a.cloneTimingInput = c, a.makeTiming = f, a.numericTimingToObject = g, a.normalizeTimingInput = h, a.calculateActiveDuration = l, a.calculateTimeFraction = t, a.calculatePhase = n, a.toTimingFunction = k
            }(c, f),
            function(a) {
                function c(a, b) {
                    return a in j ? j[a][b] || b : b
                }

                function d(a, b, d) {
                    var e = g[a];
                    if (e) {
                        h.style[a] = b;
                        for (var f in e) {
                            var i = e[f],
                                j = h.style[i];
                            d[i] = c(i, j)
                        }
                    } else d[a] = c(a, b)
                }

                function e(a) {
                    var b = [];
                    for (var c in a)
                        if (!(c in ["easing", "offset", "composite"])) {
                            var d = a[c];
                            Array.isArray(d) || (d = [d]);
                            for (var e, f = d.length, g = 0; f > g; g++) e = {}, e.offset = "offset" in a ? a.offset : 1 == f ? 1 : g / (f - 1), "easing" in a && (e.easing = a.easing), "composite" in a && (e.composite = a.composite), e[c] = d[g], b.push(e)
                        }
                    return b.sort(function(a, b) {
                        return a.offset - b.offset
                    }), b
                }

                function f(a) {
                    function b() {
                        var a = c.length;
                        null == c[a - 1].offset && (c[a - 1].offset = 1), a > 1 && null == c[0].offset && (c[0].offset = 0);
                        for (var b = 0, d = c[0].offset, e = 1; a > e; e++) {
                            var f = c[e].offset;
                            if (null != f) {
                                for (var g = 1; e - b > g; g++) c[b + g].offset = d + (f - d) * g / (e - b);
                                b = e, d = f
                            }
                        }
                    }
                    if (null == a) return [];
                    window.Symbol && Symbol.iterator && Array.prototype.from && a[Symbol.iterator] && (a = Array.from(a)), Array.isArray(a) || (a = e(a));
                    for (var c = a.map(function(a) {
                            var b = {};
                            for (var c in a) {
                                var e = a[c];
                                if ("offset" == c) {
                                    if (null != e && (e = Number(e), !isFinite(e))) throw new TypeError("keyframe offsets must be numbers.")
                                } else {
                                    if ("composite" == c) throw {
                                        type: DOMException.NOT_SUPPORTED_ERR,
                                        name: "NotSupportedError",
                                        message: "add compositing is not supported"
                                    };
                                    e = "" + e
                                }
                                d(c, e, b)
                            }
                            return void 0 == b.offset && (b.offset = null), b
                        }), f = !0, g = -(1 / 0), h = 0; h < c.length; h++) {
                        var i = c[h].offset;
                        if (null != i) {
                            if (g > i) throw {
                                code: DOMException.INVALID_MODIFICATION_ERR,
                                name: "InvalidModificationError",
                                message: "Keyframes are not loosely sorted by offset. Sort or specify offsets."
                            };
                            g = i
                        } else f = !1
                    }
                    return c = c.filter(function(a) {
                        return a.offset >= 0 && a.offset <= 1
                    }), f || b(), c
                }
                var g = {
                        background: ["backgroundImage", "backgroundPosition", "backgroundSize", "backgroundRepeat", "backgroundAttachment", "backgroundOrigin", "backgroundClip", "backgroundColor"],
                        border: ["borderTopColor", "borderTopStyle", "borderTopWidth", "borderRightColor", "borderRightStyle", "borderRightWidth", "borderBottomColor", "borderBottomStyle", "borderBottomWidth", "borderLeftColor", "borderLeftStyle", "borderLeftWidth"],
                        borderBottom: ["borderBottomWidth", "borderBottomStyle", "borderBottomColor"],
                        borderColor: ["borderTopColor", "borderRightColor", "borderBottomColor", "borderLeftColor"],
                        borderLeft: ["borderLeftWidth", "borderLeftStyle", "borderLeftColor"],
                        borderRadius: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomRightRadius", "borderBottomLeftRadius"],
                        borderRight: ["borderRightWidth", "borderRightStyle", "borderRightColor"],
                        borderTop: ["borderTopWidth", "borderTopStyle", "borderTopColor"],
                        borderWidth: ["borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth"],
                        flex: ["flexGrow", "flexShrink", "flexBasis"],
                        font: ["fontFamily", "fontSize", "fontStyle", "fontVariant", "fontWeight", "lineHeight"],
                        margin: ["marginTop", "marginRight", "marginBottom", "marginLeft"],
                        outline: ["outlineColor", "outlineStyle", "outlineWidth"],
                        padding: ["paddingTop", "paddingRight", "paddingBottom", "paddingLeft"]
                    },
                    h = document.createElementNS("http://www.w3.org/1999/xhtml", "div"),
                    i = {
                        thin: "1px",
                        medium: "3px",
                        thick: "5px"
                    },
                    j = {
                        borderBottomWidth: i,
                        borderLeftWidth: i,
                        borderRightWidth: i,
                        borderTopWidth: i,
                        fontSize: {
                            "xx-small": "60%",
                            "x-small": "75%",
                            small: "89%",
                            medium: "100%",
                            large: "120%",
                            "x-large": "150%",
                            "xx-large": "200%"
                        },
                        fontWeight: {
                            normal: "400",
                            bold: "700"
                        },
                        outlineWidth: i,
                        textShadow: {
                            none: "0px 0px 0px transparent"
                        },
                        boxShadow: {
                            none: "0px 0px 0px 0px transparent"
                        }
                    };
                a.convertToArrayForm = e, a.normalizeKeyframes = f
            }(c, f),
            function(a) {
                var b = {};
                a.isDeprecated = function(a, c, d, e) {
                    var f = e ? "are" : "is",
                        g = new Date,
                        h = new Date(c);
                    return h.setMonth(h.getMonth() + 3), h > g ? (a in b || console.warn("Web Animations: " + a + " " + f + " deprecated and will stop working on " + h.toDateString() + ". " + d), b[a] = !0, !1) : !0
                }, a.deprecated = function(b, c, d, e) {
                    var f = e ? "are" : "is";
                    if (a.isDeprecated(b, c, d, e)) throw new Error(b + " " + f + " no longer supported. " + d)
                }
            }(c),
            function() {
                if (document.documentElement.animate) {
                    var a = document.documentElement.animate([], 0),
                        b = !0;
                    if (a && (b = !1, "play|currentTime|pause|reverse|playbackRate|cancel|finish|startTime|playState".split("|").forEach(function(c) {
                            void 0 === a[c] && (b = !0)
                        })), !b) return
                }! function(a, b) {
                    function d(a) {
                        for (var b = {}, c = 0; c < a.length; c++)
                            for (var d in a[c])
                                if ("offset" != d && "easing" != d && "composite" != d) {
                                    var e = {
                                        offset: a[c].offset,
                                        easing: a[c].easing,
                                        value: a[c][d]
                                    };
                                    b[d] = b[d] || [], b[d].push(e)
                                }
                        for (var f in b) {
                            var g = b[f];
                            if (0 != g[0].offset || 1 != g[g.length - 1].offset) throw {
                                type: DOMException.NOT_SUPPORTED_ERR,
                                name: "NotSupportedError",
                                message: "Partial keyframes are not supported"
                            }
                        }
                        return b
                    }

                    function e(c) {
                        var d = [];
                        for (var e in c)
                            for (var f = c[e], g = 0; g < f.length - 1; g++) {
                                var h = f[g].offset,
                                    i = f[g + 1].offset,
                                    j = f[g].value,
                                    k = f[g + 1].value,
                                    l = f[g].easing;
                                h == i && (1 == i ? j = k : k = j), d.push({
                                    startTime: h,
                                    endTime: i,
                                    easing: a.toTimingFunction(l ? l : "linear"),
                                    property: e,
                                    interpolation: b.propertyInterpolation(e, j, k)
                                })
                            }
                        return d.sort(function(a, b) {
                            return a.startTime - b.startTime
                        }), d
                    }
                    b.convertEffectInput = function(c) {
                        var f = a.normalizeKeyframes(c),
                            g = d(f),
                            h = e(g);
                        return function(a, c) {
                            if (null != c) h.filter(function(a) {
                                return 0 >= c && 0 == a.startTime || c >= 1 && 1 == a.endTime || c >= a.startTime && c <= a.endTime
                            }).forEach(function(d) {
                                var e = c - d.startTime,
                                    f = d.endTime - d.startTime,
                                    g = 0 == f ? 0 : d.easing(e / f);
                                b.apply(a, d.property, d.interpolation(g))
                            });
                            else
                                for (var d in g) "offset" != d && "easing" != d && "composite" != d && b.clear(a, d)
                        }
                    }
                }(c, d, f),
                function(a, b) {
                    function d(a) {
                        return a.replace(/-(.)/g, function(a, b) {
                            return b.toUpperCase()
                        })
                    }

                    function e(a, b, c) {
                        h[c] = h[c] || [], h[c].push([a, b])
                    }

                    function f(a, b, c) {
                        for (var f = 0; f < c.length; f++) {
                            var g = c[f];
                            e(a, b, d(g))
                        }
                    }

                    function g(c, e, f) {
                        var g = c;
                        /-/.test(c) && !a.isDeprecated("Hyphenated property names", "2016-03-22", "Use camelCase instead.", !0) && (g = d(c)), "initial" != e && "initial" != f || ("initial" == e && (e = i[g]), "initial" == f && (f = i[g]));
                        for (var j = e == f ? [] : h[g], k = 0; j && k < j.length; k++) {
                            var l = j[k][0](e),
                                m = j[k][0](f);
                            if (void 0 !== l && void 0 !== m) {
                                var n = j[k][1](l, m);
                                if (n) {
                                    var o = b.Interpolation.apply(null, n);
                                    return function(a) {
                                        return 0 == a ? e : 1 == a ? f : o(a)
                                    }
                                }
                            }
                        }
                        return b.Interpolation(!1, !0, function(a) {
                            return a ? f : e
                        })
                    }
                    var h = {};
                    b.addPropertiesHandler = f;
                    var i = {
                        backgroundColor: "transparent",
                        backgroundPosition: "0% 0%",
                        borderBottomColor: "currentColor",
                        borderBottomLeftRadius: "0px",
                        borderBottomRightRadius: "0px",
                        borderBottomWidth: "3px",
                        borderLeftColor: "currentColor",
                        borderLeftWidth: "3px",
                        borderRightColor: "currentColor",
                        borderRightWidth: "3px",
                        borderSpacing: "2px",
                        borderTopColor: "currentColor",
                        borderTopLeftRadius: "0px",
                        borderTopRightRadius: "0px",
                        borderTopWidth: "3px",
                        bottom: "auto",
                        clip: "rect(0px, 0px, 0px, 0px)",
                        color: "black",
                        fontSize: "100%",
                        fontWeight: "400",
                        height: "auto",
                        left: "auto",
                        letterSpacing: "normal",
                        lineHeight: "120%",
                        marginBottom: "0px",
                        marginLeft: "0px",
                        marginRight: "0px",
                        marginTop: "0px",
                        maxHeight: "none",
                        maxWidth: "none",
                        minHeight: "0px",
                        minWidth: "0px",
                        opacity: "1.0",
                        outlineColor: "invert",
                        outlineOffset: "0px",
                        outlineWidth: "3px",
                        paddingBottom: "0px",
                        paddingLeft: "0px",
                        paddingRight: "0px",
                        paddingTop: "0px",
                        right: "auto",
                        textIndent: "0px",
                        textShadow: "0px 0px 0px transparent",
                        top: "auto",
                        transform: "",
                        verticalAlign: "0px",
                        visibility: "visible",
                        width: "auto",
                        wordSpacing: "normal",
                        zIndex: "auto"
                    };
                    b.propertyInterpolation = g
                }(c, d, f),
                function(a, b) {
                    function d(b) {
                        var c = a.calculateActiveDuration(b),
                            d = function(d) {
                                return a.calculateTimeFraction(c, d, b)
                            };
                        return d._totalDuration = b.delay + c + b.endDelay, d._isCurrent = function(d) {
                            var e = a.calculatePhase(c, d, b);
                            return e === PhaseActive || e === PhaseBefore
                        }, d
                    }
                    b.KeyframeEffect = function(c, e, f, g) {
                        var h, i = d(a.normalizeTimingInput(f)),
                            j = b.convertEffectInput(e),
                            k = function() {
                                j(c, h)
                            };
                        return k._update = function(a) {
                            return h = i(a), null !== h
                        }, k._clear = function() {
                            j(c, null)
                        }, k._hasSameTarget = function(a) {
                            return c === a
                        }, k._isCurrent = i._isCurrent, k._totalDuration = i._totalDuration, k._id = g, k
                    }, b.NullEffect = function(a) {
                        var b = function() {
                            a && (a(), a = null)
                        };
                        return b._update = function() {
                            return null
                        }, b._totalDuration = 0, b._isCurrent = function() {
                            return !1
                        }, b._hasSameTarget = function() {
                            return !1
                        }, b
                    }
                }(c, d, f),
                function(a) {
                    a.apply = function(b, c, d) {
                        b.style[a.propertyName(c)] = d
                    }, a.clear = function(b, c) {
                        b.style[a.propertyName(c)] = ""
                    }
                }(d, f),
                function(a) {
                    window.Element.prototype.animate = function(b, c) {
                        var d = "";
                        return c && c.id && (d = c.id), a.timeline._play(a.KeyframeEffect(this, b, c, d))
                    }
                }(d),
                function(a) {
                    function c(a, b, d) {
                        if ("number" == typeof a && "number" == typeof b) return a * (1 - d) + b * d;
                        if ("boolean" == typeof a && "boolean" == typeof b) return .5 > d ? a : b;
                        if (a.length == b.length) {
                            for (var e = [], f = 0; f < a.length; f++) e.push(c(a[f], b[f], d));
                            return e
                        }
                        throw "Mismatched interpolation arguments " + a + ":" + b
                    }
                    a.Interpolation = function(a, b, d) {
                        return function(e) {
                            return d(c(a, b, e))
                        }
                    }
                }(d, f),
                function(a, b) {
                    a.sequenceNumber = 0;
                    var d = function(a, b, c) {
                        this.target = a, this.currentTime = b, this.timelineTime = c, this.type = "finish", this.bubbles = !1, this.cancelable = !1, this.currentTarget = a, this.defaultPrevented = !1, this.eventPhase = Event.AT_TARGET, this.timeStamp = Date.now()
                    };
                    b.Animation = function(b) {
                        this.id = "", b && b._id && (this.id = b._id), this._sequenceNumber = a.sequenceNumber++, this._currentTime = 0, this._startTime = null, this._paused = !1, this._playbackRate = 1, this._inTimeline = !0, this._finishedFlag = !0, this.onfinish = null, this._finishHandlers = [], this._effect = b, this._inEffect = this._effect._update(0), this._idle = !0, this._currentTimePending = !1
                    }, b.Animation.prototype = {
                        _ensureAlive: function() {
                            this._inEffect = this._effect._update(this.playbackRate < 0 && 0 === this.currentTime ? -1 : this.currentTime), this._inTimeline || !this._inEffect && this._finishedFlag || (this._inTimeline = !0, b.timeline._animations.push(this))
                        },
                        _tickCurrentTime: function(a, b) {
                            a != this._currentTime && (this._currentTime = a, this._isFinished && !b && (this._currentTime = this._playbackRate > 0 ? this._totalDuration : 0), this._ensureAlive())
                        },
                        get currentTime() {
                            return this._idle || this._currentTimePending ? null : this._currentTime
                        },
                        set currentTime(a) {
                            a = +a, isNaN(a) || (b.restart(), this._paused || null == this._startTime || (this._startTime = this._timeline.currentTime - a / this._playbackRate), this._currentTimePending = !1, this._currentTime != a && (this._tickCurrentTime(a, !0), b.invalidateEffects()))
                        },
                        get startTime() {
                            return this._startTime
                        },
                        set startTime(a) {
                            a = +a, isNaN(a) || this._paused || this._idle || (this._startTime = a, this._tickCurrentTime((this._timeline.currentTime - this._startTime) * this.playbackRate), b.invalidateEffects())
                        },
                        get playbackRate() {
                            return this._playbackRate
                        },
                        set playbackRate(a) {
                            if (a != this._playbackRate) {
                                var b = this.currentTime;
                                this._playbackRate = a, this._startTime = null, "paused" != this.playState && "idle" != this.playState && this.play(), null != b && (this.currentTime = b)
                            }
                        },
                        get _isFinished() {
                            return !this._idle && (this._playbackRate > 0 && this._currentTime >= this._totalDuration || this._playbackRate < 0 && this._currentTime <= 0)
                        },
                        get _totalDuration() {
                            return this._effect._totalDuration
                        },
                        get playState() {
                            return this._idle ? "idle" : null == this._startTime && !this._paused && 0 != this.playbackRate || this._currentTimePending ? "pending" : this._paused ? "paused" : this._isFinished ? "finished" : "running"
                        },
                        play: function() {
                            this._paused = !1, (this._isFinished || this._idle) && (this._currentTime = this._playbackRate > 0 ? 0 : this._totalDuration, this._startTime = null), this._finishedFlag = !1, this._idle = !1, this._ensureAlive(), b.invalidateEffects()
                        },
                        pause: function() {
                            this._isFinished || this._paused || this._idle || (this._currentTimePending = !0), this._startTime = null, this._paused = !0
                        },
                        finish: function() {
                            this._idle || (this.currentTime = this._playbackRate > 0 ? this._totalDuration : 0, this._startTime = this._totalDuration - this.currentTime, this._currentTimePending = !1, b.invalidateEffects())
                        },
                        cancel: function() {
                            this._inEffect && (this._inEffect = !1, this._idle = !0, this._finishedFlag = !0, this.currentTime = 0, this._startTime = null, this._effect._update(null), b.invalidateEffects())
                        },
                        reverse: function() {
                            this.playbackRate *= -1, this.play()
                        },
                        addEventListener: function(a, b) {
                            "function" == typeof b && "finish" == a && this._finishHandlers.push(b)
                        },
                        removeEventListener: function(a, b) {
                            if ("finish" == a) {
                                var c = this._finishHandlers.indexOf(b);
                                c >= 0 && this._finishHandlers.splice(c, 1)
                            }
                        },
                        _fireEvents: function(a) {
                            if (this._isFinished) {
                                if (!this._finishedFlag) {
                                    var b = new d(this, this._currentTime, a),
                                        c = this._finishHandlers.concat(this.onfinish ? [this.onfinish] : []);
                                    setTimeout(function() {
                                        c.forEach(function(a) {
                                            a.call(b.target, b)
                                        })
                                    }, 0), this._finishedFlag = !0
                                }
                            } else this._finishedFlag = !1
                        },
                        _tick: function(a, b) {
                            this._idle || this._paused || (null == this._startTime ? b && (this.startTime = a - this._currentTime / this.playbackRate) : this._isFinished || this._tickCurrentTime((a - this._startTime) * this.playbackRate)), b && (this._currentTimePending = !1, this._fireEvents(a))
                        },
                        get _needsTick() {
                            return this.playState in {
                                pending: 1,
                                running: 1
                            } || !this._finishedFlag
                        }
                    }
                }(c, d, f),
                function(a, b) {
                    function d(a) {
                        var b = j;
                        j = [], a < p.currentTime && (a = p.currentTime), h(a, !0), b.forEach(function(b) {
                            b[1](a)
                        }), g(), l = void 0
                    }

                    function e(a, b) {
                        return a._sequenceNumber - b._sequenceNumber
                    }

                    function f() {
                        this._animations = [], this.currentTime = window.performance && performance.now ? performance.now() : 0
                    }

                    function g() {
                        o.forEach(function(a) {
                            a()
                        }), o.length = 0
                    }

                    function h(a, c) {
                        n = !1;
                        var d = b.timeline;
                        d.currentTime = a, d._animations.sort(e), m = !1;
                        var f = d._animations;
                        d._animations = [];
                        var g = [],
                            h = [];
                        f = f.filter(function(b) {
                            b._tick(a, c), b._inEffect ? h.push(b._effect) : g.push(b._effect), b._needsTick && (m = !0);
                            var d = b._inEffect || b._needsTick;
                            return b._inTimeline = d, d
                        }), o.push.apply(o, g), o.push.apply(o, h), d._animations.push.apply(d._animations, f), m && requestAnimationFrame(function() {})
                    }
                    var i = window.requestAnimationFrame,
                        j = [],
                        k = 0;
                    window.requestAnimationFrame = function(a) {
                        var b = k++;
                        return 0 == j.length && i(d), j.push([b, a]), b
                    }, window.cancelAnimationFrame = function(a) {
                        j.forEach(function(b) {
                            b[0] == a && (b[1] = function() {})
                        })
                    }, f.prototype = {
                        _play: function(c) {
                            c._timing = a.normalizeTimingInput(c.timing);
                            var d = new b.Animation(c);
                            return d._idle = !1, d._timeline = this, this._animations.push(d), b.restart(), b.invalidateEffects(), d
                        }
                    };
                    var l = void 0,
                        m = !1,
                        n = !1;
                    b.restart = function() {
                        return m || (m = !0, requestAnimationFrame(function() {}), n = !0), n
                    }, b.invalidateEffects = function() {
                        h(b.timeline.currentTime, !1), g()
                    };
                    var o = [],
                        p = new f;
                    b.timeline = p
                }(c, d, f),
                function(a) {
                    function b(a, b) {
                        var c = a.exec(b);
                        return c ? (c = a.ignoreCase ? c[0].toLowerCase() : c[0], [c, b.substr(c.length)]) : void 0
                    }

                    function c(a, b) {
                        b = b.replace(/^\s*/, "");
                        var c = a(b);
                        return c ? [c[0], c[1].replace(/^\s*/, "")] : void 0
                    }

                    function d(a, d, e) {
                        a = c.bind(null, a);
                        for (var f = [];;) {
                            var g = a(e);
                            if (!g) return [f, e];
                            if (f.push(g[0]), e = g[1], g = b(d, e), !g || "" == g[1]) return [f, e];
                            e = g[1]
                        }
                    }

                    function e(a, b) {
                        for (var c = 0, d = 0; d < b.length && (!/\s|,/.test(b[d]) || 0 != c); d++)
                            if ("(" == b[d]) c++;
                            else if (")" == b[d] && (c--, 0 == c && d++, 0 >= c)) break;
                        var e = a(b.substr(0, d));
                        return void 0 == e ? void 0 : [e, b.substr(d)]
                    }

                    function f(a, b) {
                        for (var c = a, d = b; c && d;) c > d ? c %= d : d %= c;
                        return c = a * b / (c + d)
                    }

                    function g(a) {
                        return function(b) {
                            var c = a(b);
                            return c && (c[0] = void 0), c
                        }
                    }

                    function h(a, b) {
                        return function(c) {
                            var d = a(c);
                            return d ? d : [b, c]
                        }
                    }

                    function i(b, c) {
                        for (var d = [], e = 0; e < b.length; e++) {
                            var f = a.consumeTrimmed(b[e], c);
                            if (!f || "" == f[0]) return;
                            void 0 !== f[0] && d.push(f[0]), c = f[1]
                        }
                        return "" == c ? d : void 0
                    }

                    function j(a, b, c, d, e) {
                        for (var g = [], h = [], i = [], j = f(d.length, e.length), k = 0; j > k; k++) {
                            var l = b(d[k % d.length], e[k % e.length]);
                            if (!l) return;
                            g.push(l[0]), h.push(l[1]), i.push(l[2])
                        }
                        return [g, h, function(b) {
                            var d = b.map(function(a, b) {
                                return i[b](a)
                            }).join(c);
                            return a ? a(d) : d
                        }]
                    }

                    function k(a, b, c) {
                        for (var d = [], e = [], f = [], g = 0, h = 0; h < c.length; h++)
                            if ("function" == typeof c[h]) {
                                var i = c[h](a[g], b[g++]);
                                d.push(i[0]), e.push(i[1]), f.push(i[2])
                            } else ! function(a) {
                                d.push(!1), e.push(!1), f.push(function() {
                                    return c[a]
                                })
                            }(h);
                        return [d, e, function(a) {
                            for (var b = "", c = 0; c < a.length; c++) b += f[c](a[c]);
                            return b
                        }]
                    }
                    a.consumeToken = b, a.consumeTrimmed = c, a.consumeRepeated = d, a.consumeParenthesised = e, a.ignore = g, a.optional = h, a.consumeList = i, a.mergeNestedRepeated = j.bind(null, null), a.mergeWrappedNestedRepeated = j, a.mergeList = k
                }(d),
                function(a) {
                    function b(b) {
                        function c(b) {
                            var c = a.consumeToken(/^inset/i, b);
                            if (c) return d.inset = !0, c;
                            var c = a.consumeLengthOrPercent(b);
                            if (c) return d.lengths.push(c[0]), c;
                            var c = a.consumeColor(b);
                            return c ? (d.color = c[0], c) : void 0
                        }
                        var d = {
                                inset: !1,
                                lengths: [],
                                color: null
                            },
                            e = a.consumeRepeated(c, /^/, b);
                        return e && e[0].length ? [d, e[1]] : void 0
                    }

                    function c(c) {
                        var d = a.consumeRepeated(b, /^,/, c);
                        return d && "" == d[1] ? d[0] : void 0
                    }

                    function d(b, c) {
                        for (; b.lengths.length < Math.max(b.lengths.length, c.lengths.length);) b.lengths.push({
                            px: 0
                        });
                        for (; c.lengths.length < Math.max(b.lengths.length, c.lengths.length);) c.lengths.push({
                            px: 0
                        });
                        if (b.inset == c.inset && !!b.color == !!c.color) {
                            for (var d, e = [], f = [
                                    [], 0
                                ], g = [
                                    [], 0
                                ], h = 0; h < b.lengths.length; h++) {
                                var i = a.mergeDimensions(b.lengths[h], c.lengths[h], 2 == h);
                                f[0].push(i[0]), g[0].push(i[1]), e.push(i[2])
                            }
                            if (b.color && c.color) {
                                var j = a.mergeColors(b.color, c.color);
                                f[1] = j[0], g[1] = j[1], d = j[2]
                            }
                            return [f, g, function(a) {
                                for (var c = b.inset ? "inset " : " ", f = 0; f < e.length; f++) c += e[f](a[0][f]) + " ";
                                return d && (c += d(a[1])), c
                            }]
                        }
                    }

                    function e(b, c, d, e) {
                        function f(a) {
                            return {
                                inset: a,
                                color: [0, 0, 0, 0],
                                lengths: [{
                                    px: 0
                                }, {
                                    px: 0
                                }, {
                                    px: 0
                                }, {
                                    px: 0
                                }]
                            }
                        }
                        for (var g = [], h = [], i = 0; i < d.length || i < e.length; i++) {
                            var j = d[i] || f(e[i].inset),
                                k = e[i] || f(d[i].inset);
                            g.push(j), h.push(k)
                        }
                        return a.mergeNestedRepeated(b, c, g, h)
                    }
                    var f = e.bind(null, d, ", ");
                    a.addPropertiesHandler(c, f, ["box-shadow", "text-shadow"])
                }(d),
                function(a) {
                    function c(a) {
                        return a.toFixed(3).replace(".000", "")
                    }

                    function d(a, b, c) {
                        return Math.min(b, Math.max(a, c))
                    }

                    function e(a) {
                        return /^\s*[-+]?(\d*\.)?\d+\s*$/.test(a) ? Number(a) : void 0
                    }

                    function f(a, b) {
                        return [a, b, c]
                    }

                    function g(a, b) {
                        return 0 != a ? i(0, 1 / 0)(a, b) : void 0
                    }

                    function h(a, b) {
                        return [a, b, function(a) {
                            return Math.round(d(1, 1 / 0, a))
                        }]
                    }

                    function i(a, b) {
                        return function(e, f) {
                            return [e, f, function(e) {
                                return c(d(a, b, e))
                            }]
                        }
                    }

                    function j(a, b) {
                        return [a, b, Math.round]
                    }
                    a.clamp = d, a.addPropertiesHandler(e, i(0, 1 / 0), ["border-image-width", "line-height"]), a.addPropertiesHandler(e, i(0, 1), ["opacity", "shape-image-threshold"]), a.addPropertiesHandler(e, g, ["flex-grow", "flex-shrink"]), a.addPropertiesHandler(e, h, ["orphans", "widows"]), a.addPropertiesHandler(e, j, ["z-index"]), a.parseNumber = e, a.mergeNumbers = f, a.numberToString = c
                }(d, f),
                function(a) {
                    function c(a, b) {
                        return "visible" == a || "visible" == b ? [0, 1, function(c) {
                            return 0 >= c ? a : c >= 1 ? b : "visible"
                        }] : void 0
                    }
                    a.addPropertiesHandler(String, c, ["visibility"])
                }(d),
                function(a) {
                    function c(a) {
                        a = a.trim(), f.fillStyle = "#000", f.fillStyle = a;
                        var b = f.fillStyle;
                        if (f.fillStyle = "#fff", f.fillStyle = a, b == f.fillStyle) {
                            f.fillRect(0, 0, 1, 1);
                            var c = f.getImageData(0, 0, 1, 1).data;
                            f.clearRect(0, 0, 1, 1);
                            var d = c[3] / 255;
                            return [c[0] * d, c[1] * d, c[2] * d, d]
                        }
                    }

                    function d(b, c) {
                        return [b, c, function(b) {
                            function c(a) {
                                return Math.max(0, Math.min(255, a))
                            }
                            if (b[3])
                                for (var d = 0; 3 > d; d++) b[d] = Math.round(c(b[d] / b[3]));
                            return b[3] = a.numberToString(a.clamp(0, 1, b[3])), "rgba(" + b.join(",") + ")"
                        }]
                    }
                    var e = document.createElementNS("http://www.w3.org/1999/xhtml", "canvas");
                    e.width = e.height = 1;
                    var f = e.getContext("2d");
                    a.addPropertiesHandler(c, d, ["background-color", "border-bottom-color", "border-left-color", "border-right-color", "border-top-color", "color", "outline-color", "text-decoration-color"]), a.consumeColor = a.consumeParenthesised.bind(null, c), a.mergeColors = d
                }(d, f),
                function(a, b) {
                    function c(a, b) {
                        if (b = b.trim().toLowerCase(), "0" == b && "px".search(a) >= 0) return {
                            px: 0
                        };
                        if (/^[^(]*$|^calc/.test(b)) {
                            b = b.replace(/calc\(/g, "(");
                            var c = {};
                            b = b.replace(a, function(a) {
                                return c[a] = null, "U" + a
                            });
                            for (var d = "U(" + a.source + ")", e = b.replace(/[-+]?(\d*\.)?\d+/g, "N").replace(new RegExp("N" + d, "g"), "D").replace(/\s[+-]\s/g, "O").replace(/\s/g, ""), f = [/N\*(D)/g, /(N|D)[*\/]N/g, /(N|D)O\1/g, /\((N|D)\)/g], g = 0; g < f.length;) f[g].test(e) ? (e = e.replace(f[g], "$1"), g = 0) : g++;
                            if ("D" == e) {
                                for (var h in c) {
                                    var i = eval(b.replace(new RegExp("U" + h, "g"), "").replace(new RegExp(d, "g"), "*0"));
                                    if (!isFinite(i)) return;
                                    c[h] = i
                                }
                                return c
                            }
                        }
                    }

                    function d(a, b) {
                        return e(a, b, !0)
                    }

                    function e(b, c, d) {
                        var e, f = [];
                        for (e in b) f.push(e);
                        for (e in c) f.indexOf(e) < 0 && f.push(e);
                        return b = f.map(function(a) {
                            return b[a] || 0
                        }), c = f.map(function(a) {
                            return c[a] || 0
                        }), [b, c, function(b) {
                            var c = b.map(function(c, e) {
                                return 1 == b.length && d && (c = Math.max(c, 0)), a.numberToString(c) + f[e]
                            }).join(" + ");
                            return b.length > 1 ? "calc(" + c + ")" : c
                        }]
                    }
                    var f = "px|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc",
                        g = c.bind(null, new RegExp(f, "g")),
                        h = c.bind(null, new RegExp(f + "|%", "g")),
                        i = c.bind(null, /deg|rad|grad|turn/g);
                    a.parseLength = g, a.parseLengthOrPercent = h, a.consumeLengthOrPercent = a.consumeParenthesised.bind(null, h), a.parseAngle = i, a.mergeDimensions = e;

                    var j = a.consumeParenthesised.bind(null, g),
                        k = a.consumeRepeated.bind(void 0, j, /^/),
                        l = a.consumeRepeated.bind(void 0, k, /^,/);
                    a.consumeSizePairList = l;
                    var m = function(a) {
                            var b = l(a);
                            return b && "" == b[1] ? b[0] : void 0
                        },
                        n = a.mergeNestedRepeated.bind(void 0, d, " "),
                        o = a.mergeNestedRepeated.bind(void 0, n, ",");
                    a.mergeNonNegativeSizePair = n, a.addPropertiesHandler(m, o, ["background-size"]), a.addPropertiesHandler(h, d, ["border-bottom-width", "border-image-width", "border-left-width", "border-right-width", "border-top-width", "flex-basis", "font-size", "height", "line-height", "max-height", "max-width", "outline-width", "width"]), a.addPropertiesHandler(h, e, ["border-bottom-left-radius", "border-bottom-right-radius", "border-top-left-radius", "border-top-right-radius", "bottom", "left", "letter-spacing", "margin-bottom", "margin-left", "margin-right", "margin-top", "min-height", "min-width", "outline-offset", "padding-bottom", "padding-left", "padding-right", "padding-top", "perspective", "right", "shape-margin", "text-indent", "top", "vertical-align", "word-spacing"])
                }(d, f),
                function(a) {
                    function c(b) {
                        return a.consumeLengthOrPercent(b) || a.consumeToken(/^auto/, b)
                    }

                    function d(b) {
                        var d = a.consumeList([a.ignore(a.consumeToken.bind(null, /^rect/)), a.ignore(a.consumeToken.bind(null, /^\(/)), a.consumeRepeated.bind(null, c, /^,/), a.ignore(a.consumeToken.bind(null, /^\)/))], b);
                        return d && 4 == d[0].length ? d[0] : void 0
                    }

                    function e(b, c) {
                        return "auto" == b || "auto" == c ? [!0, !1, function(d) {
                            var e = d ? b : c;
                            if ("auto" == e) return "auto";
                            var f = a.mergeDimensions(e, e);
                            return f[2](f[0])
                        }] : a.mergeDimensions(b, c)
                    }

                    function f(a) {
                        return "rect(" + a + ")"
                    }
                    var g = a.mergeWrappedNestedRepeated.bind(null, f, e, ", ");
                    a.parseBox = d, a.mergeBoxes = g, a.addPropertiesHandler(d, g, ["clip"])
                }(d, f),
                function(a) {
                    function c(a) {
                        return function(b) {
                            var c = 0;
                            return a.map(function(a) {
                                return a === k ? b[c++] : a
                            })
                        }
                    }

                    function d(a) {
                        return a
                    }

                    function e(b) {
                        if (b = b.toLowerCase().trim(), "none" == b) return [];
                        for (var c, d = /\s*(\w+)\(([^)]*)\)/g, e = [], f = 0; c = d.exec(b);) {
                            if (c.index != f) return;
                            f = c.index + c[0].length;
                            var g = c[1],
                                h = n[g];
                            if (!h) return;
                            var i = c[2].split(","),
                                j = h[0];
                            if (j.length < i.length) return;
                            for (var k = [], o = 0; o < j.length; o++) {
                                var p, q = i[o],
                                    r = j[o];
                                if (p = q ? {
                                        A: function(b) {
                                            return "0" == b.trim() ? m : a.parseAngle(b)
                                        },
                                        N: a.parseNumber,
                                        T: a.parseLengthOrPercent,
                                        L: a.parseLength
                                    }[r.toUpperCase()](q) : {
                                        a: m,
                                        n: k[0],
                                        t: l
                                    }[r], void 0 === p) return;
                                k.push(p)
                            }
                            if (e.push({
                                    t: g,
                                    d: k
                                }), d.lastIndex == b.length) return e
                        }
                    }

                    function f(a) {
                        return a.toFixed(6).replace(".000000", "")
                    }

                    function g(b, c) {
                        if (b.decompositionPair !== c) {
                            b.decompositionPair = c;
                            var d = a.makeMatrixDecomposition(b)
                        }
                        if (c.decompositionPair !== b) {
                            c.decompositionPair = b;
                            var e = a.makeMatrixDecomposition(c)
                        }
                        return null == d[0] || null == e[0] ? [
                            [!1],
                            [!0],
                            function(a) {
                                return a ? c[0].d : b[0].d
                            }
                        ] : (d[0].push(0), e[0].push(1), [d, e, function(b) {
                            var c = a.quat(d[0][3], e[0][3], b[5]),
                                g = a.composeMatrix(b[0], b[1], b[2], c, b[4]),
                                h = g.map(f).join(",");
                            return h
                        }])
                    }

                    function h(a) {
                        return a.replace(/[xy]/, "")
                    }

                    function i(a) {
                        return a.replace(/(x|y|z|3d)?$/, "3d")
                    }

                    function j(b, c) {
                        var d = a.makeMatrixDecomposition && !0,
                            e = !1;
                        if (!b.length || !c.length) {
                            b.length || (e = !0, b = c, c = []);
                            for (var f = 0; f < b.length; f++) {
                                var j = b[f].t,
                                    k = b[f].d,
                                    l = "scale" == j.substr(0, 5) ? 1 : 0;
                                c.push({
                                    t: j,
                                    d: k.map(function(a) {
                                        if ("number" == typeof a) return l;
                                        var b = {};
                                        for (var c in a) b[c] = l;
                                        return b
                                    })
                                })
                            }
                        }
                        var m = function(a, b) {
                                return "perspective" == a && "perspective" == b || ("matrix" == a || "matrix3d" == a) && ("matrix" == b || "matrix3d" == b)
                            },
                            o = [],
                            p = [],
                            q = [];
                        if (b.length != c.length) {
                            if (!d) return;
                            var r = g(b, c);
                            o = [r[0]], p = [r[1]], q = [
                                ["matrix", [r[2]]]
                            ]
                        } else
                            for (var f = 0; f < b.length; f++) {
                                var j, s = b[f].t,
                                    t = c[f].t,
                                    u = b[f].d,
                                    v = c[f].d,
                                    w = n[s],
                                    x = n[t];
                                if (m(s, t)) {
                                    if (!d) return;
                                    var r = g([b[f]], [c[f]]);
                                    o.push(r[0]), p.push(r[1]), q.push(["matrix", [r[2]]])
                                } else {
                                    if (s == t) j = s;
                                    else if (w[2] && x[2] && h(s) == h(t)) j = h(s), u = w[2](u), v = x[2](v);
                                    else {
                                        if (!w[1] || !x[1] || i(s) != i(t)) {
                                            if (!d) return;
                                            var r = g(b, c);
                                            o = [r[0]], p = [r[1]], q = [
                                                ["matrix", [r[2]]]
                                            ];
                                            break
                                        }
                                        j = i(s), u = w[1](u), v = x[1](v)
                                    }
                                    for (var y = [], z = [], A = [], B = 0; B < u.length; B++) {
                                        var C = "number" == typeof u[B] ? a.mergeNumbers : a.mergeDimensions,
                                            r = C(u[B], v[B]);
                                        y[B] = r[0], z[B] = r[1], A.push(r[2])
                                    }
                                    o.push(y), p.push(z), q.push([j, A])
                                }
                            }
                        if (e) {
                            var D = o;
                            o = p, p = D
                        }
                        return [o, p, function(a) {
                            return a.map(function(a, b) {
                                var c = a.map(function(a, c) {
                                    return q[b][1][c](a)
                                }).join(",");
                                return "matrix" == q[b][0] && 16 == c.split(",").length && (q[b][0] = "matrix3d"), q[b][0] + "(" + c + ")"
                            }).join(" ")
                        }]
                    }
                    var k = null,
                        l = {
                            px: 0
                        },
                        m = {
                            deg: 0
                        },
                        n = {
                            matrix: ["NNNNNN", [k, k, 0, 0, k, k, 0, 0, 0, 0, 1, 0, k, k, 0, 1], d],
                            matrix3d: ["NNNNNNNNNNNNNNNN", d],
                            rotate: ["A"],
                            rotatex: ["A"],
                            rotatey: ["A"],
                            rotatez: ["A"],
                            rotate3d: ["NNNA"],
                            perspective: ["L"],
                            scale: ["Nn", c([k, k, 1]), d],
                            scalex: ["N", c([k, 1, 1]), c([k, 1])],
                            scaley: ["N", c([1, k, 1]), c([1, k])],
                            scalez: ["N", c([1, 1, k])],
                            scale3d: ["NNN", d],
                            skew: ["Aa", null, d],
                            skewx: ["A", null, c([k, m])],
                            skewy: ["A", null, c([m, k])],
                            translate: ["Tt", c([k, k, l]), d],
                            translatex: ["T", c([k, l, l]), c([k, l])],
                            translatey: ["T", c([l, k, l]), c([l, k])],
                            translatez: ["L", c([l, l, k])],
                            translate3d: ["TTL", d]
                        };
                    a.addPropertiesHandler(e, j, ["transform"])
                }(d, f),
                function(a) {
                    function c(a, b) {
                        b.concat([a]).forEach(function(b) {
                            b in document.documentElement.style && (d[a] = b)
                        })
                    }
                    var d = {};
                    c("transform", ["webkitTransform", "msTransform"]), c("transformOrigin", ["webkitTransformOrigin"]), c("perspective", ["webkitPerspective"]), c("perspectiveOrigin", ["webkitPerspectiveOrigin"]), a.propertyName = function(a) {
                        return d[a] || a
                    }
                }(d, f)
            }(), ! function() {
                if (void 0 === document.createElement("div").animate([]).oncancel) {
                    var a;
                    if (window.performance && performance.now) var a = function() {
                        return performance.now()
                    };
                    else var a = function() {
                        return Date.now()
                    };
                    var b = function(a, b, c) {
                            this.target = a, this.currentTime = b, this.timelineTime = c, this.type = "cancel", this.bubbles = !1, this.cancelable = !1, this.currentTarget = a, this.defaultPrevented = !1, this.eventPhase = Event.AT_TARGET, this.timeStamp = Date.now()
                        },
                        c = window.Element.prototype.animate;
                    window.Element.prototype.animate = function(d, e) {
                        var f = c.call(this, d, e);
                        f._cancelHandlers = [], f.oncancel = null;
                        var g = f.cancel;
                        f.cancel = function() {
                            g.call(this);
                            var c = new b(this, null, a()),
                                d = this._cancelHandlers.concat(this.oncancel ? [this.oncancel] : []);
                            setTimeout(function() {
                                d.forEach(function(a) {
                                    a.call(c.target, c)
                                })
                            }, 0)
                        };
                        var h = f.addEventListener;
                        f.addEventListener = function(a, b) {
                            "function" == typeof b && "cancel" == a ? this._cancelHandlers.push(b) : h.call(this, a, b)
                        };
                        var i = f.removeEventListener;
                        return f.removeEventListener = function(a, b) {
                            if ("cancel" == a) {
                                var c = this._cancelHandlers.indexOf(b);
                                c >= 0 && this._cancelHandlers.splice(c, 1)
                            } else i.call(this, a, b)
                        }, f
                    }
                }
            }(),
            function(a) {
                var b = document.documentElement,
                    c = null,
                    d = !1;
                try {
                    var e = getComputedStyle(b).getPropertyValue("opacity"),
                        f = "0" == e ? "1" : "0";
                    c = b.animate({
                        opacity: [f, f]
                    }, {
                        duration: 1
                    }), c.currentTime = 0, d = getComputedStyle(b).getPropertyValue("opacity") == f
                } catch (g) {} finally {
                    c && c.cancel()
                }
                if (!d) {
                    var h = window.Element.prototype.animate;
                    window.Element.prototype.animate = function(b, c) {
                        return window.Symbol && Symbol.iterator && Array.prototype.from && b[Symbol.iterator] && (b = Array.from(b)), Array.isArray(b) || null === b || (b = a.convertToArrayForm(b)), h.call(this, b, c)
                    }
                }
            }(c), ! function(a, b) {
                function d(a) {
                    var b = window.document.timeline;
                    b.currentTime = a, b._discardAnimations(), 0 == b._animations.length ? f = !1 : requestAnimationFrame(d)
                }
                var e = window.requestAnimationFrame;
                window.requestAnimationFrame = function(a) {
                    return e(function(b) {
                        window.document.timeline._updateAnimationsPromises(), a(b), window.document.timeline._updateAnimationsPromises()
                    })
                }, b.AnimationTimeline = function() {
                    this._animations = [], this.currentTime = void 0
                }, b.AnimationTimeline.prototype = {
                    getAnimations: function() {
                        return this._discardAnimations(), this._animations.slice()
                    },
                    _updateAnimationsPromises: function() {
                        b.animationsWithPromises = b.animationsWithPromises.filter(function(a) {
                            return a._updatePromises()
                        })
                    },
                    _discardAnimations: function() {
                        this._updateAnimationsPromises(), this._animations = this._animations.filter(function(a) {
                            return "finished" != a.playState && "idle" != a.playState
                        })
                    },
                    _play: function(a) {
                        var c = new b.Animation(a, this);
                        return this._animations.push(c), b.restartWebAnimationsNextTick(), c._updatePromises(), c._animation.play(), c._updatePromises(), c
                    },
                    play: function(a) {
                        return a && a.remove(), this._play(a)
                    }
                };
                var f = !1;
                b.restartWebAnimationsNextTick = function() {
                    f || (f = !0, requestAnimationFrame(d))
                };
                var g = new b.AnimationTimeline;
                b.timeline = g;
                try {
                    Object.defineProperty(window.document, "timeline", {
                        configurable: !0,
                        get: function() {
                            return g
                        }
                    })
                } catch (h) {}
                try {
                    window.document.timeline = g
                } catch (h) {}
            }(c, e, f),
            function(a, b) {
                b.animationsWithPromises = [], b.Animation = function(b, c) {
                    if (this.id = "", b && b._id && (this.id = b._id), this.effect = b, b && (b._animation = this), !c) throw new Error("Animation with null timeline is not supported");
                    this._timeline = c, this._sequenceNumber = a.sequenceNumber++, this._holdTime = 0, this._paused = !1, this._isGroup = !1, this._animation = null, this._childAnimations = [], this._callback = null, this._oldPlayState = "idle", this._rebuildUnderlyingAnimation(), this._animation.cancel(), this._updatePromises()
                }, b.Animation.prototype = {
                    _updatePromises: function() {
                        var a = this._oldPlayState,
                            b = this.playState;
                        return this._readyPromise && b !== a && ("idle" == b ? (this._rejectReadyPromise(), this._readyPromise = void 0) : "pending" == a ? this._resolveReadyPromise() : "pending" == b && (this._readyPromise = void 0)), this._finishedPromise && b !== a && ("idle" == b ? (this._rejectFinishedPromise(), this._finishedPromise = void 0) : "finished" == b ? this._resolveFinishedPromise() : "finished" == a && (this._finishedPromise = void 0)), this._oldPlayState = this.playState, this._readyPromise || this._finishedPromise
                    },
                    _rebuildUnderlyingAnimation: function() {
                        this._updatePromises();
                        var a, c, d, e, f = !!this._animation;
                        f && (a = this.playbackRate, c = this._paused, d = this.startTime, e = this.currentTime, this._animation.cancel(), this._animation._wrapper = null, this._animation = null), (!this.effect || this.effect instanceof window.KeyframeEffect) && (this._animation = b.newUnderlyingAnimationForKeyframeEffect(this.effect), b.bindAnimationForKeyframeEffect(this)), (this.effect instanceof window.SequenceEffect || this.effect instanceof window.GroupEffect) && (this._animation = b.newUnderlyingAnimationForGroup(this.effect), b.bindAnimationForGroup(this)), this.effect && this.effect._onsample && b.bindAnimationForCustomEffect(this), f && (1 != a && (this.playbackRate = a), null !== d ? this.startTime = d : null !== e ? this.currentTime = e : null !== this._holdTime && (this.currentTime = this._holdTime), c && this.pause()), this._updatePromises()
                    },
                    _updateChildren: function() {
                        if (this.effect && "idle" != this.playState) {
                            var a = this.effect._timing.delay;
                            this._childAnimations.forEach(function(c) {
                                this._arrangeChildren(c, a), this.effect instanceof window.SequenceEffect && (a += b.groupChildDuration(c.effect))
                            }.bind(this))
                        }
                    },
                    _setExternalAnimation: function(a) {
                        if (this.effect && this._isGroup)
                            for (var b = 0; b < this.effect.children.length; b++) this.effect.children[b]._animation = a, this._childAnimations[b]._setExternalAnimation(a)
                    },
                    _constructChildAnimations: function() {
                        if (this.effect && this._isGroup) {
                            var a = this.effect._timing.delay;
                            this._removeChildAnimations(), this.effect.children.forEach(function(c) {
                                var d = window.document.timeline._play(c);
                                this._childAnimations.push(d), d.playbackRate = this.playbackRate, this._paused && d.pause(), c._animation = this.effect._animation, this._arrangeChildren(d, a), this.effect instanceof window.SequenceEffect && (a += b.groupChildDuration(c))
                            }.bind(this))
                        }
                    },
                    _arrangeChildren: function(a, b) {
                        null === this.startTime ? a.currentTime = this.currentTime - b / this.playbackRate : a.startTime !== this.startTime + b / this.playbackRate && (a.startTime = this.startTime + b / this.playbackRate)
                    },
                    get timeline() {
                        return this._timeline
                    },
                    get playState() {
                        return this._animation ? this._animation.playState : "idle"
                    },
                    get finished() {
                        return window.Promise ? (this._finishedPromise || (-1 == b.animationsWithPromises.indexOf(this) && b.animationsWithPromises.push(this), this._finishedPromise = new Promise(function(a, b) {
                            this._resolveFinishedPromise = function() {
                                a(this)
                            }, this._rejectFinishedPromise = function() {
                                b({
                                    type: DOMException.ABORT_ERR,
                                    name: "AbortError"
                                })
                            }
                        }.bind(this)), "finished" == this.playState && this._resolveFinishedPromise()), this._finishedPromise) : (console.warn("Animation Promises require JavaScript Promise constructor"), null)
                    },
                    get ready() {
                        return window.Promise ? (this._readyPromise || (-1 == b.animationsWithPromises.indexOf(this) && b.animationsWithPromises.push(this), this._readyPromise = new Promise(function(a, b) {
                            this._resolveReadyPromise = function() {
                                a(this)
                            }, this._rejectReadyPromise = function() {
                                b({
                                    type: DOMException.ABORT_ERR,
                                    name: "AbortError"
                                })
                            }
                        }.bind(this)), "pending" !== this.playState && this._resolveReadyPromise()), this._readyPromise) : (console.warn("Animation Promises require JavaScript Promise constructor"), null)
                    },
                    get onfinish() {
                        return this._animation.onfinish
                    },
                    set onfinish(a) {
                        this._animation.onfinish = "function" == typeof a ? function(b) {
                            b.target = this, a.call(this, b)
                        }.bind(this) : a
                    },
                    get oncancel() {
                        return this._animation.oncancel
                    },
                    set oncancel(a) {
                        this._animation.oncancel = "function" == typeof a ? function(b) {
                            b.target = this, a.call(this, b)
                        }.bind(this) : a
                    },
                    get currentTime() {
                        this._updatePromises();
                        var a = this._animation.currentTime;
                        return this._updatePromises(), a
                    },
                    set currentTime(a) {
                        this._updatePromises(), this._animation.currentTime = isFinite(a) ? a : Math.sign(a) * Number.MAX_VALUE, this._register(), this._forEachChild(function(b, c) {
                            b.currentTime = a - c
                        }), this._updatePromises()
                    },
                    get startTime() {
                        return this._animation.startTime
                    },
                    set startTime(a) {
                        this._updatePromises(), this._animation.startTime = isFinite(a) ? a : Math.sign(a) * Number.MAX_VALUE, this._register(), this._forEachChild(function(b, c) {
                            b.startTime = a + c
                        }), this._updatePromises()
                    },
                    get playbackRate() {
                        return this._animation.playbackRate
                    },
                    set playbackRate(a) {
                        this._updatePromises();
                        var b = this.currentTime;
                        this._animation.playbackRate = a, this._forEachChild(function(b) {
                            b.playbackRate = a
                        }), "paused" != this.playState && "idle" != this.playState && this.play(), null !== b && (this.currentTime = b), this._updatePromises()
                    },
                    play: function() {
                        this._updatePromises(), this._paused = !1, this._animation.play(), -1 == this._timeline._animations.indexOf(this) && this._timeline._animations.push(this), this._register(), b.awaitStartTime(this), this._forEachChild(function(a) {
                            var b = a.currentTime;
                            a.play(), a.currentTime = b
                        }), this._updatePromises()
                    },
                    pause: function() {
                        this._updatePromises(), this.currentTime && (this._holdTime = this.currentTime), this._animation.pause(), this._register(), this._forEachChild(function(a) {
                            a.pause()
                        }), this._paused = !0, this._updatePromises()
                    },
                    finish: function() {
                        this._updatePromises(), this._animation.finish(), this._register(), this._updatePromises()
                    },
                    cancel: function() {
                        this._updatePromises(), this._animation.cancel(), this._register(), this._removeChildAnimations(), this._updatePromises()
                    },
                    reverse: function() {
                        this._updatePromises();
                        var a = this.currentTime;
                        this._animation.reverse(), this._forEachChild(function(a) {
                            a.reverse()
                        }), null !== a && (this.currentTime = a), this._updatePromises()
                    },
                    addEventListener: function(a, b) {
                        var c = b;
                        "function" == typeof b && (c = function(a) {
                            a.target = this, b.call(this, a)
                        }.bind(this), b._wrapper = c), this._animation.addEventListener(a, c)
                    },
                    removeEventListener: function(a, b) {
                        this._animation.removeEventListener(a, b && b._wrapper || b)
                    },
                    _removeChildAnimations: function() {
                        for (; this._childAnimations.length;) this._childAnimations.pop().cancel()
                    },
                    _forEachChild: function(b) {
                        var c = 0;
                        if (this.effect.children && this._childAnimations.length < this.effect.children.length && this._constructChildAnimations(), this._childAnimations.forEach(function(a) {
                                b.call(this, a, c), this.effect instanceof window.SequenceEffect && (c += a.effect.activeDuration)
                            }.bind(this)), "pending" != this.playState) {
                            var d = this.effect._timing,
                                e = this.currentTime;
                            null !== e && (e = a.calculateTimeFraction(a.calculateActiveDuration(d), e, d)), (null == e || isNaN(e)) && this._removeChildAnimations()
                        }
                    }
                }, window.Animation = b.Animation
            }(c, e, f),
            function(a, b) {
                function d(b) {
                    this._frames = a.normalizeKeyframes(b)
                }

                function e() {
                    for (var a = !1; i.length;) {
                        var b = i.shift();
                        b._updateChildren(), a = !0
                    }
                    return a
                }
                var f = function(a) {
                    if (a._animation = void 0, a instanceof window.SequenceEffect || a instanceof window.GroupEffect)
                        for (var b = 0; b < a.children.length; b++) f(a.children[b])
                };
                b.removeMulti = function(a) {
                    for (var b = [], c = 0; c < a.length; c++) {
                        var d = a[c];
                        d._parent ? (-1 == b.indexOf(d._parent) && b.push(d._parent), d._parent.children.splice(d._parent.children.indexOf(d), 1), d._parent = null, f(d)) : d._animation && d._animation.effect == d && (d._animation.cancel(), d._animation.effect = new KeyframeEffect(null, []), d._animation._callback && (d._animation._callback._animation = null), d._animation._rebuildUnderlyingAnimation(), f(d))
                    }
                    for (c = 0; c < b.length; c++) b[c]._rebuild()
                }, b.KeyframeEffect = function(b, c, e, f) {
                    return this.target = b, this._parent = null, e = a.numericTimingToObject(e), this._timingInput = a.cloneTimingInput(e), this._timing = a.normalizeTimingInput(e), this.timing = a.makeTiming(e, !1, this), this.timing._effect = this, "function" == typeof c ? (a.deprecated("Custom KeyframeEffect", "2015-06-22", "Use KeyframeEffect.onsample instead."), this._normalizedKeyframes = c) : this._normalizedKeyframes = new d(c), this._keyframes = c, this.activeDuration = a.calculateActiveDuration(this._timing), this._id = f, this
                }, b.KeyframeEffect.prototype = {
                    getFrames: function() {
                        return "function" == typeof this._normalizedKeyframes ? this._normalizedKeyframes : this._normalizedKeyframes._frames
                    },
                    set onsample(a) {
                        if ("function" == typeof this.getFrames()) throw new Error("Setting onsample on custom effect KeyframeEffect is not supported.");
                        this._onsample = a, this._animation && this._animation._rebuildUnderlyingAnimation()
                    },
                    get parent() {
                        return this._parent
                    },
                    clone: function() {
                        if ("function" == typeof this.getFrames()) throw new Error("Cloning custom effects is not supported.");
                        var b = new KeyframeEffect(this.target, [], a.cloneTimingInput(this._timingInput), this._id);
                        return b._normalizedKeyframes = this._normalizedKeyframes, b._keyframes = this._keyframes, b
                    },
                    remove: function() {
                        b.removeMulti([this])
                    }
                };
                var g = Element.prototype.animate;
                Element.prototype.animate = function(a, c) {
                    var d = "";
                    return c && c.id && (d = c.id), b.timeline._play(new b.KeyframeEffect(this, a, c, d))
                };
                var h = document.createElementNS("http://www.w3.org/1999/xhtml", "div");
                b.newUnderlyingAnimationForKeyframeEffect = function(a) {
                    if (a) {
                        var b = a.target || h,
                            c = a._keyframes;
                        "function" == typeof c && (c = []);
                        var d = a._timingInput;
                        d.id = a._id
                    } else var b = h,
                        c = [],
                        d = 0;
                    return g.apply(b, [c, d])
                }, b.bindAnimationForKeyframeEffect = function(a) {
                    a.effect && "function" == typeof a.effect._normalizedKeyframes && b.bindAnimationForCustomEffect(a)
                };
                var i = [];
                b.awaitStartTime = function(a) {
                    null === a.startTime && a._isGroup && (0 == i.length && requestAnimationFrame(e), i.push(a))
                };
                var j = window.getComputedStyle;
                Object.defineProperty(window, "getComputedStyle", {
                    configurable: !0,
                    enumerable: !0,
                    value: function() {
                        window.document.timeline._updateAnimationsPromises();
                        var a = j.apply(this, arguments);
                        return e() && (a = j.apply(this, arguments)), window.document.timeline._updateAnimationsPromises(), a
                    }
                }), window.KeyframeEffect = b.KeyframeEffect, window.Element.prototype.getAnimations = function() {
                    return document.timeline.getAnimations().filter(function(a) {
                        return null !== a.effect && a.effect.target == this
                    }.bind(this))
                }
            }(c, e, f),
            function(a, b) {
                function d(a) {
                    a._registered || (a._registered = !0, g.push(a), h || (h = !0, requestAnimationFrame(e)))
                }

                function e() {
                    var b = g;
                    g = [], b.sort(function(a, b) {
                        return a._sequenceNumber - b._sequenceNumber
                    }), b = b.filter(function(a) {
                        a();
                        var b = a._animation ? a._animation.playState : "idle";
                        return "running" != b && "pending" != b && (a._registered = !1), a._registered
                    }), g.push.apply(g, b), g.length ? (h = !0, requestAnimationFrame(e)) : h = !1
                }
                var f = (document.createElementNS("http://www.w3.org/1999/xhtml", "div"), 0);
                b.bindAnimationForCustomEffect = function(b) {
                    var c, e = b.effect.target,
                        g = "function" == typeof b.effect.getFrames();
                    c = g ? b.effect.getFrames() : b.effect._onsample;
                    var h = b.effect.timing,
                        i = null;
                    h = a.normalizeTimingInput(h);
                    var j = function() {
                        var d = j._animation ? j._animation.currentTime : null;
                        null !== d && (d = a.calculateTimeFraction(a.calculateActiveDuration(h), d, h), isNaN(d) && (d = null)), d !== i && (g ? c(d, e, b.effect) : c(d, b.effect, b.effect._animation)), i = d
                    };
                    j._animation = b, j._registered = !1, j._sequenceNumber = f++, b._callback = j, d(j)
                };
                var g = [],
                    h = !1;
                b.Animation.prototype._register = function() {
                    this._callback && d(this._callback)
                }
            }(c, e, f),
            function(a, b) {
                function d(a) {
                    return a._timing.delay + a.activeDuration + a._timing.endDelay
                }

                function e(b, c, d) {
                    this._id = d, this._parent = null, this.children = b || [], this._reparent(this.children), c = a.numericTimingToObject(c), this._timingInput = a.cloneTimingInput(c), this._timing = a.normalizeTimingInput(c, !0), this.timing = a.makeTiming(c, !0, this), this.timing._effect = this, "auto" === this._timing.duration && (this._timing.duration = this.activeDuration)
                }
                window.SequenceEffect = function() {
                    e.apply(this, arguments)
                }, window.GroupEffect = function() {
                    e.apply(this, arguments)
                }, e.prototype = {
                    _isAncestor: function(a) {
                        for (var b = this; null !== b;) {
                            if (b == a) return !0;
                            b = b._parent
                        }
                        return !1
                    },
                    _rebuild: function() {
                        for (var a = this; a;) "auto" === a.timing.duration && (a._timing.duration = a.activeDuration), a = a._parent;
                        this._animation && this._animation._rebuildUnderlyingAnimation()
                    },
                    _reparent: function(a) {
                        b.removeMulti(a);
                        for (var c = 0; c < a.length; c++) a[c]._parent = this
                    },
                    _putChild: function(a, b) {
                        for (var c = b ? "Cannot append an ancestor or self" : "Cannot prepend an ancestor or self", d = 0; d < a.length; d++)
                            if (this._isAncestor(a[d])) throw {
                                type: DOMException.HIERARCHY_REQUEST_ERR,
                                name: "HierarchyRequestError",
                                message: c
                            };
                        for (var d = 0; d < a.length; d++) b ? this.children.push(a[d]) : this.children.unshift(a[d]);
                        this._reparent(a), this._rebuild()
                    },
                    append: function() {
                        this._putChild(arguments, !0)
                    },
                    prepend: function() {
                        this._putChild(arguments, !1)
                    },
                    get parent() {
                        return this._parent
                    },
                    get firstChild() {
                        return this.children.length ? this.children[0] : null
                    },
                    get lastChild() {
                        return this.children.length ? this.children[this.children.length - 1] : null
                    },
                    clone: function() {
                        for (var b = a.cloneTimingInput(this._timingInput), c = [], d = 0; d < this.children.length; d++) c.push(this.children[d].clone());
                        return this instanceof GroupEffect ? new GroupEffect(c, b) : new SequenceEffect(c, b)
                    },
                    remove: function() {
                        b.removeMulti([this])
                    }
                }, window.SequenceEffect.prototype = Object.create(e.prototype), Object.defineProperty(window.SequenceEffect.prototype, "activeDuration", {
                    get: function() {
                        var a = 0;
                        return this.children.forEach(function(b) {
                            a += d(b)
                        }), Math.max(a, 0)
                    }
                }), window.GroupEffect.prototype = Object.create(e.prototype), Object.defineProperty(window.GroupEffect.prototype, "activeDuration", {
                    get: function() {
                        var a = 0;
                        return this.children.forEach(function(b) {
                            a = Math.max(a, d(b))
                        }), a
                    }
                }), b.newUnderlyingAnimationForGroup = function(c) {
                    var d, e = null,
                        f = function(b) {
                            var c = d._wrapper;
                            return c && "pending" != c.playState && c.effect ? null == b ? void c._removeChildAnimations() : 0 == b && c.playbackRate < 0 && (e || (e = a.normalizeTimingInput(c.effect.timing)), b = a.calculateTimeFraction(a.calculateActiveDuration(e), -1, e), isNaN(b) || null == b) ? (c._forEachChild(function(a) {
                                a.currentTime = -1
                            }), void c._removeChildAnimations()) : void 0 : void 0
                        },
                        g = new KeyframeEffect(null, [], c._timing, c._id);
                    return g.onsample = f, d = b.timeline._play(g)
                }, b.bindAnimationForGroup = function(a) {
                    a._animation._wrapper = a, a._isGroup = !0, b.awaitStartTime(a), a._constructChildAnimations(), a._setExternalAnimation(a)
                }, b.groupChildDuration = d
            }(c, e, f), b["true"] = a
        }({}, function() {
            return this
        }())
    }(), Polymer({
        is: "opaque-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            var node = config.node;
            return node.style.opacity = "0", this._effect = new KeyframeEffect(node, [{
                opacity: "1"
            }, {
                opacity: "1"
            }], this.timingFromConfig(config)), this._effect
        },
        complete: function(config) {
            config.node.style.opacity = ""
        }
    }), Polymer.NeonAnimatableBehavior = {
        properties: {
            animationConfig: {
                type: Object
            },
            entryAnimation: {
                observer: "_entryAnimationChanged",
                type: String
            },
            exitAnimation: {
                observer: "_exitAnimationChanged",
                type: String
            }
        },
        _entryAnimationChanged: function() {
            this.animationConfig = this.animationConfig || {}, this.animationConfig.entry = "fade-in-animation" !== this.entryAnimation ? [{
                name: "opaque-animation",
                node: this
            }, {
                name: this.entryAnimation,
                node: this
            }] : [{
                name: this.entryAnimation,
                node: this
            }]
        },
        _exitAnimationChanged: function() {
            this.animationConfig = this.animationConfig || {}, this.animationConfig.exit = [{
                name: this.exitAnimation,
                node: this
            }]
        },
        _copyProperties: function(config1, config2) {
            for (var property in config2) config1[property] = config2[property]
        },
        _cloneConfig: function(config) {
            var clone = {
                isClone: !0
            };
            return this._copyProperties(clone, config), clone
        },
        _getAnimationConfigRecursive: function(type, map, allConfigs) {
            if (this.animationConfig) {
                if (this.animationConfig.value && "function" == typeof this.animationConfig.value) return void this._warn(this._logf("playAnimation", "Please put 'animationConfig' inside of your components 'properties' object instead of outside of it."));
                var thisConfig;
                if (thisConfig = type ? this.animationConfig[type] : this.animationConfig, Array.isArray(thisConfig) || (thisConfig = [thisConfig]), thisConfig)
                    for (var config, index = 0; config = thisConfig[index]; index++)
                        if (config.animatable) config.animatable._getAnimationConfigRecursive(config.type || type, map, allConfigs);
                        else if (config.id) {
                    var cachedConfig = map[config.id];
                    cachedConfig ? (cachedConfig.isClone || (map[config.id] = this._cloneConfig(cachedConfig), cachedConfig = map[config.id]), this._copyProperties(cachedConfig, config)) : map[config.id] = config
                } else allConfigs.push(config)
            }
        },
        getAnimationConfig: function(type) {
            var map = {},
                allConfigs = [];
            this._getAnimationConfigRecursive(type, map, allConfigs);
            for (var key in map) allConfigs.push(map[key]);
            return allConfigs
        }
    }, Polymer.NeonAnimationRunnerBehaviorImpl = {
        properties: {
            _player: {
                type: Object
            }
        },
        _configureAnimationEffects: function(allConfigs) {
            var allAnimations = [];
            if (allConfigs.length > 0)
                for (var config, index = 0; config = allConfigs[index]; index++) {
                    var animation = document.createElement(config.name);
                    if (animation.isNeonAnimation) {
                        var effect = animation.configure(config);
                        effect && allAnimations.push({
                            animation: animation,
                            config: config,
                            effect: effect
                        })
                    } else Polymer.Base._warn(this.is + ":", config.name, "not found!")
                }
            return allAnimations
        },
        _runAnimationEffects: function(allEffects) {
            return document.timeline.play(new GroupEffect(allEffects))
        },
        _completeAnimations: function(allAnimations) {
            for (var animation, index = 0; animation = allAnimations[index]; index++) animation.animation.complete(animation.config)
        },
        playAnimation: function(type, cookie) {
            var allConfigs = this.getAnimationConfig(type);
            if (allConfigs) {
                var allAnimations = this._configureAnimationEffects(allConfigs),
                    allEffects = allAnimations.map(function(animation) {
                        return animation.effect
                    });
                allEffects.length > 0 ? (this._player = this._runAnimationEffects(allEffects), this._player.onfinish = function() {
                    this._completeAnimations(allAnimations), this._player && (this._player.cancel(), this._player = null), this.fire("neon-animation-finish", cookie, {
                        bubbles: !1
                    })
                }.bind(this)) : this.fire("neon-animation-finish", cookie, {
                    bubbles: !1
                })
            }
        },
        cancelAnimation: function() {
            this._player && this._player.cancel()
        }
    }, Polymer.NeonAnimationRunnerBehavior = [Polymer.NeonAnimatableBehavior, Polymer.NeonAnimationRunnerBehaviorImpl],
    function() {
        "use strict";
        var lastTouchPosition = {
                pageX: 0,
                pageY: 0
            },
            lastRootTarget = null,
            lastScrollableNodes = [];
        Polymer.IronDropdownScrollManager = {
            get currentLockingElement() {
                return this._lockingElements[this._lockingElements.length - 1]
            },
            elementIsScrollLocked: function(element) {
                var currentLockingElement = this.currentLockingElement;
                if (void 0 === currentLockingElement) return !1;
                var scrollLocked;
                return this._hasCachedLockedElement(element) ? !0 : this._hasCachedUnlockedElement(element) ? !1 : (scrollLocked = !!currentLockingElement && currentLockingElement !== element && !this._composedTreeContains(currentLockingElement, element), scrollLocked ? this._lockedElementCache.push(element) : this._unlockedElementCache.push(element), scrollLocked)
            },
            pushScrollLock: function(element) {
                this._lockingElements.indexOf(element) >= 0 || (0 === this._lockingElements.length && this._lockScrollInteractions(), this._lockingElements.push(element), this._lockedElementCache = [], this._unlockedElementCache = [])
            },
            removeScrollLock: function(element) {
                var index = this._lockingElements.indexOf(element); - 1 !== index && (this._lockingElements.splice(index, 1), this._lockedElementCache = [], this._unlockedElementCache = [], 0 === this._lockingElements.length && this._unlockScrollInteractions())
            },
            _lockingElements: [],
            _lockedElementCache: null,
            _unlockedElementCache: null,
            _hasCachedLockedElement: function(element) {
                return this._lockedElementCache.indexOf(element) > -1
            },
            _hasCachedUnlockedElement: function(element) {
                return this._unlockedElementCache.indexOf(element) > -1
            },
            _composedTreeContains: function(element, child) {
                var contentElements, distributedNodes, contentIndex, nodeIndex;
                if (element.contains(child)) return !0;
                for (contentElements = Polymer.dom(element).querySelectorAll("content"), contentIndex = 0; contentIndex < contentElements.length; ++contentIndex)
                    for (distributedNodes = Polymer.dom(contentElements[contentIndex]).getDistributedNodes(), nodeIndex = 0; nodeIndex < distributedNodes.length; ++nodeIndex)
                        if (this._composedTreeContains(distributedNodes[nodeIndex], child)) return !0;
                return !1
            },
            _scrollInteractionHandler: function(event) {
                if (event.cancelable && this._shouldPreventScrolling(event) && event.preventDefault(), event.targetTouches) {
                    var touch = event.targetTouches[0];
                    lastTouchPosition.pageX = touch.pageX, lastTouchPosition.pageY = touch.pageY
                }
            },
            _lockScrollInteractions: function() {
                this._boundScrollHandler = this._boundScrollHandler || this._scrollInteractionHandler.bind(this), document.addEventListener("wheel", this._boundScrollHandler, !0), document.addEventListener("mousewheel", this._boundScrollHandler, !0), document.addEventListener("DOMMouseScroll", this._boundScrollHandler, !0), document.addEventListener("touchstart", this._boundScrollHandler, !0), document.addEventListener("touchmove", this._boundScrollHandler, !0)
            },
            _unlockScrollInteractions: function() {
                document.removeEventListener("wheel", this._boundScrollHandler, !0), document.removeEventListener("mousewheel", this._boundScrollHandler, !0), document.removeEventListener("DOMMouseScroll", this._boundScrollHandler, !0), document.removeEventListener("touchstart", this._boundScrollHandler, !0), document.removeEventListener("touchmove", this._boundScrollHandler, !0)
            },
            _shouldPreventScrolling: function(event) {
                var target = Polymer.dom(event).rootTarget;
                if ("touchmove" !== event.type && lastRootTarget !== target && (lastRootTarget = target, lastScrollableNodes = this._getScrollableNodes(Polymer.dom(event).path)), !lastScrollableNodes.length) return !0;
                if ("touchstart" === event.type) return !1;
                var info = this._getScrollInfo(event);
                return !this._getScrollingNode(lastScrollableNodes, info.deltaX, info.deltaY)
            },
            _getScrollableNodes: function(nodes) {
                for (var scrollables = [], lockingIndex = nodes.indexOf(this.currentLockingElement), i = 0; lockingIndex >= i; i++)
                    if (nodes[i].nodeType === Node.ELEMENT_NODE) {
                        var node = nodes[i],
                            style = node.style;
                        "scroll" !== style.overflow && "auto" !== style.overflow && (style = window.getComputedStyle(node)), ("scroll" === style.overflow || "auto" === style.overflow) && scrollables.push(node)
                    }
                return scrollables
            },
            _getScrollingNode: function(nodes, deltaX, deltaY) {
                if (deltaX || deltaY)
                    for (var verticalScroll = Math.abs(deltaY) >= Math.abs(deltaX), i = 0; i < nodes.length; i++) {
                        var node = nodes[i],
                            canScroll = !1;
                        if (canScroll = verticalScroll ? 0 > deltaY ? node.scrollTop > 0 : node.scrollTop < node.scrollHeight - node.clientHeight : 0 > deltaX ? node.scrollLeft > 0 : node.scrollLeft < node.scrollWidth - node.clientWidth) return node
                    }
            },
            _getScrollInfo: function(event) {
                var info = {
                    deltaX: event.deltaX,
                    deltaY: event.deltaY
                };
                if ("deltaX" in event);
                else if ("wheelDeltaX" in event) info.deltaX = -event.wheelDeltaX, info.deltaY = -event.wheelDeltaY;
                else if ("axis" in event) info.deltaX = 1 === event.axis ? event.detail : 0, info.deltaY = 2 === event.axis ? event.detail : 0;
                else if (event.targetTouches) {
                    var touch = event.targetTouches[0];
                    info.deltaX = lastTouchPosition.pageX - touch.pageX, info.deltaY = lastTouchPosition.pageY - touch.pageY
                }
                return info
            }
        }
    }(),
    function() {
        "use strict";
        Polymer({
            is: "iron-dropdown",
            behaviors: [Polymer.IronControlState, Polymer.IronA11yKeysBehavior, Polymer.IronOverlayBehavior, Polymer.NeonAnimationRunnerBehavior],
            properties: {
                horizontalAlign: {
                    type: String,
                    value: "left",
                    reflectToAttribute: !0
                },
                verticalAlign: {
                    type: String,
                    value: "top",
                    reflectToAttribute: !0
                },
                openAnimationConfig: {
                    type: Object
                },
                closeAnimationConfig: {
                    type: Object
                },
                focusTarget: {
                    type: Object
                },
                noAnimations: {
                    type: Boolean,
                    value: !1
                },
                allowOutsideScroll: {
                    type: Boolean,
                    value: !1
                },
                _boundOnCaptureScroll: {
                    type: Function,
                    value: function() {
                        return this._onCaptureScroll.bind(this)
                    }
                }
            },
            listeners: {
                "neon-animation-finish": "_onNeonAnimationFinish"
            },
            observers: ["_updateOverlayPosition(positionTarget, verticalAlign, horizontalAlign, verticalOffset, horizontalOffset)"],
            get containedElement() {
                return Polymer.dom(this.$.content).getDistributedNodes()[0]
            },
            get _focusTarget() {
                return this.focusTarget || this.containedElement
            },
            ready: function() {
                this._scrollTop = 0, this._scrollLeft = 0, this._refitOnScrollRAF = null
            },
            attached: function() {
                this.sizingTarget && this.sizingTarget !== this || (this.sizingTarget = this.containedElement || this)
            },
            detached: function() {
                this.cancelAnimation(), document.removeEventListener("scroll", this._boundOnCaptureScroll), Polymer.IronDropdownScrollManager.removeScrollLock(this)
            },
            _openedChanged: function() {
                this.opened && this.disabled ? this.cancel() : (this.cancelAnimation(), this._updateAnimationConfig(), this._saveScrollPosition(), this.opened ? (document.addEventListener("scroll", this._boundOnCaptureScroll), !this.allowOutsideScroll && Polymer.IronDropdownScrollManager.pushScrollLock(this)) : (document.removeEventListener("scroll", this._boundOnCaptureScroll), Polymer.IronDropdownScrollManager.removeScrollLock(this)), Polymer.IronOverlayBehaviorImpl._openedChanged.apply(this, arguments))
            },
            _renderOpened: function() {
                !this.noAnimations && this.animationConfig.open ? (this.$.contentWrapper.classList.add("animating"), this.playAnimation("open")) : Polymer.IronOverlayBehaviorImpl._renderOpened.apply(this, arguments)
            },
            _renderClosed: function() {
                !this.noAnimations && this.animationConfig.close ? (this.$.contentWrapper.classList.add("animating"), this.playAnimation("close")) : Polymer.IronOverlayBehaviorImpl._renderClosed.apply(this, arguments)
            },
            _onNeonAnimationFinish: function() {
                this.$.contentWrapper.classList.remove("animating"), this.opened ? this._finishRenderOpened() : this._finishRenderClosed()
            },
            _onCaptureScroll: function() {
                this.allowOutsideScroll ? (this._refitOnScrollRAF && window.cancelAnimationFrame(this._refitOnScrollRAF), this._refitOnScrollRAF = window.requestAnimationFrame(this.refit.bind(this))) : this._restoreScrollPosition()
            },
            _saveScrollPosition: function() {
                document.scrollingElement ? (this._scrollTop = document.scrollingElement.scrollTop, this._scrollLeft = document.scrollingElement.scrollLeft) : (this._scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop), this._scrollLeft = Math.max(document.documentElement.scrollLeft, document.body.scrollLeft))
            },
            _restoreScrollPosition: function() {
                document.scrollingElement ? (document.scrollingElement.scrollTop = this._scrollTop, document.scrollingElement.scrollLeft = this._scrollLeft) : (document.documentElement.scrollTop = this._scrollTop, document.documentElement.scrollLeft = this._scrollLeft, document.body.scrollTop = this._scrollTop, document.body.scrollLeft = this._scrollLeft)
            },
            _updateAnimationConfig: function() {
                for (var animationNode = this.containedElement, animations = [].concat(this.openAnimationConfig || []).concat(this.closeAnimationConfig || []), i = 0; i < animations.length; i++) animations[i].node = animationNode;
                this.animationConfig = {
                    open: this.openAnimationConfig,
                    close: this.closeAnimationConfig
                }
            },
            _updateOverlayPosition: function() {
                this.isAttached && this.notifyResize()
            },
            _applyFocus: function() {
                var focusTarget = this.focusTarget || this.containedElement;
                focusTarget && this.opened && !this.noAutoFocus ? focusTarget.focus() : Polymer.IronOverlayBehaviorImpl._applyFocus.apply(this, arguments)
            }
        })
    }(), Polymer({
        is: "fade-in-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            var node = config.node;
            return this._effect = new KeyframeEffect(node, [{
                opacity: "0"
            }, {
                opacity: "1"
            }], this.timingFromConfig(config)), this._effect
        }
    }), Polymer({
        is: "fade-out-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            var node = config.node;
            return this._effect = new KeyframeEffect(node, [{
                opacity: "1"
            }, {
                opacity: "0"
            }], this.timingFromConfig(config)), this._effect
        }
    }), Polymer({
        is: "paper-menu-grow-height-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            var node = config.node,
                rect = node.getBoundingClientRect(),
                height = rect.height;
            return this._effect = new KeyframeEffect(node, [{
                height: height / 2 + "px"
            }, {
                height: height + "px"
            }], this.timingFromConfig(config)), this._effect
        }
    }), Polymer({
        is: "paper-menu-grow-width-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            var node = config.node,
                rect = node.getBoundingClientRect(),
                width = rect.width;
            return this._effect = new KeyframeEffect(node, [{
                width: width / 2 + "px"
            }, {
                width: width + "px"
            }], this.timingFromConfig(config)), this._effect
        }
    }), Polymer({
        is: "paper-menu-shrink-width-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            var node = config.node,
                rect = node.getBoundingClientRect(),
                width = rect.width;
            return this._effect = new KeyframeEffect(node, [{
                width: width + "px"
            }, {
                width: width - width / 20 + "px"
            }], this.timingFromConfig(config)), this._effect
        }
    }), Polymer({
        is: "paper-menu-shrink-height-animation",
        behaviors: [Polymer.NeonAnimationBehavior],
        configure: function(config) {
            {
                var node = config.node,
                    rect = node.getBoundingClientRect(),
                    height = rect.height;
                rect.top
            }
            return this.setPrefixedProperty(node, "transformOrigin", "0 0"), this._effect = new KeyframeEffect(node, [{
                height: height + "px",
                transform: "translateY(0)"
            }, {
                height: height / 2 + "px",
                transform: "translateY(-20px)"
            }], this.timingFromConfig(config)), this._effect
        }
    }),
    function() {
        "use strict";
        var config = {
                ANIMATION_CUBIC_BEZIER: "cubic-bezier(.3,.95,.5,1)",
                MAX_ANIMATION_TIME_MS: 400
            },
            PaperMenuButton = Polymer({
                is: "paper-menu-button",
                behaviors: [Polymer.IronA11yKeysBehavior, Polymer.IronControlState],
                properties: {
                    opened: {
                        type: Boolean,
                        value: !1,
                        notify: !0,
                        observer: "_openedChanged"
                    },
                    horizontalAlign: {
                        type: String,
                        value: "left",
                        reflectToAttribute: !0
                    },
                    verticalAlign: {
                        type: String,
                        value: "top",
                        reflectToAttribute: !0
                    },
                    dynamicAlign: {
                        type: Boolean
                    },
                    horizontalOffset: {
                        type: Number,
                        value: 0,
                        notify: !0
                    },
                    verticalOffset: {
                        type: Number,
                        value: 0,
                        notify: !0
                    },
                    noOverlap: {
                        type: Boolean
                    },
                    noAnimations: {
                        type: Boolean,
                        value: !1
                    },
                    ignoreSelect: {
                        type: Boolean,
                        value: !1
                    },
                    closeOnActivate: {
                        type: Boolean,
                        value: !1
                    },
                    openAnimationConfig: {
                        type: Object,
                        value: function() {
                            return [{
                                name: "fade-in-animation",
                                timing: {
                                    delay: 100,
                                    duration: 200
                                }
                            }, {
                                name: "paper-menu-grow-width-animation",
                                timing: {
                                    delay: 100,
                                    duration: 150,
                                    easing: config.ANIMATION_CUBIC_BEZIER
                                }
                            }, {
                                name: "paper-menu-grow-height-animation",
                                timing: {
                                    delay: 100,
                                    duration: 275,
                                    easing: config.ANIMATION_CUBIC_BEZIER
                                }
                            }]
                        }
                    },
                    closeAnimationConfig: {
                        type: Object,
                        value: function() {
                            return [{
                                name: "fade-out-animation",
                                timing: {
                                    duration: 150
                                }
                            }, {
                                name: "paper-menu-shrink-width-animation",
                                timing: {
                                    delay: 100,
                                    duration: 50,
                                    easing: config.ANIMATION_CUBIC_BEZIER
                                }
                            }, {
                                name: "paper-menu-shrink-height-animation",
                                timing: {
                                    duration: 200,
                                    easing: "ease-in"
                                }
                            }]
                        }
                    },
                    allowOutsideScroll: {
                        type: Boolean,
                        value: !1
                    },
                    restoreFocusOnClose: {
                        type: Boolean,
                        value: !0
                    },
                    _dropdownContent: {
                        type: Object
                    }
                },
                hostAttributes: {
                    role: "group",
                    "aria-haspopup": "true"
                },
                listeners: {
                    "iron-activate": "_onIronActivate",
                    "iron-select": "_onIronSelect"
                },
                get contentElement() {
                    return Polymer.dom(this.$.content).getDistributedNodes()[0]
                },
                toggle: function() {
                    this.opened ? this.close() : this.open()
                },
                open: function() {
                    this.disabled || this.$.dropdown.open()
                },
                close: function() {
                    this.$.dropdown.close()
                },
                _onIronSelect: function() {
                    this.ignoreSelect || this.close()
                },
                _onIronActivate: function() {
                    this.closeOnActivate && this.close()
                },
                _openedChanged: function(opened, oldOpened) {
                    opened ? (this._dropdownContent = this.contentElement, this.fire("paper-dropdown-open")) : null != oldOpened && this.fire("paper-dropdown-close")
                },
                _disabledChanged: function(disabled) {
                    Polymer.IronControlState._disabledChanged.apply(this, arguments), disabled && this.opened && this.close()
                },
                __onIronOverlayCanceled: function(event) {
                    var uiEvent = event.detail,
                        trigger = (Polymer.dom(uiEvent).rootTarget, this.$.trigger),
                        path = Polymer.dom(uiEvent).path;
                    path.indexOf(trigger) > -1 && event.preventDefault()
                }
            });
        Object.keys(config).forEach(function(key) {
            PaperMenuButton[key] = config[key]
        }), Polymer.PaperMenuButton = PaperMenuButton
    }(),
    function() {
        "use strict";
        Polymer({
            is: "paper-dropdown-menu",
            behaviors: [Polymer.IronButtonState, Polymer.IronControlState, Polymer.IronFormElementBehavior, Polymer.IronValidatableBehavior],
            properties: {
                selectedItemLabel: {
                    type: String,
                    notify: !0,
                    readOnly: !0
                },
                selectedItem: {
                    type: Object,
                    notify: !0,
                    readOnly: !0
                },
                value: {
                    type: String,
                    notify: !0,
                    readOnly: !0
                },
                label: {
                    type: String
                },
                placeholder: {
                    type: String
                },
                errorMessage: {
                    type: String
                },
                opened: {
                    type: Boolean,
                    notify: !0,
                    value: !1,
                    observer: "_openedChanged"
                },
                allowOutsideScroll: {
                    type: Boolean,
                    value: !1
                },
                noLabelFloat: {
                    type: Boolean,
                    value: !1,
                    reflectToAttribute: !0
                },
                alwaysFloatLabel: {
                    type: Boolean,
                    value: !1
                },
                noAnimations: {
                    type: Boolean,
                    value: !1
                },
                horizontalAlign: {
                    type: String,
                    value: "right"
                },
                verticalAlign: {
                    type: String,
                    value: "top"
                },
                dynamicAlign: {
                    type: Boolean
                },
                restoreFocusOnClose: {
                    type: Boolean,
                    value: !0
                }
            },
            listeners: {
                tap: "_onTap"
            },
            keyBindings: {
                "up down": "open",
                esc: "close"
            },
            hostAttributes: {
                role: "combobox",
                "aria-autocomplete": "none",
                "aria-haspopup": "true"
            },
            observers: ["_selectedItemChanged(selectedItem)"],
            attached: function() {
                var contentElement = this.contentElement;
                contentElement && contentElement.selectedItem && this._setSelectedItem(contentElement.selectedItem)
            },
            get contentElement() {
                return Polymer.dom(this.$.content).getDistributedNodes()[0]
            },
            open: function() {
                this.$.menuButton.open()
            },
            close: function() {
                this.$.menuButton.close()
            },
            _onIronSelect: function(event) {
                this._setSelectedItem(event.detail.item)
            },
            _onIronDeselect: function() {
                this._setSelectedItem(null)
            },
            _onTap: function(event) {
                Polymer.Gestures.findOriginalTarget(event) === this && this.open()
            },
            _selectedItemChanged: function(selectedItem) {
                var value = "";
                value = selectedItem ? selectedItem.label || selectedItem.getAttribute("label") || selectedItem.textContent.trim() : "", this._setValue(value), this._setSelectedItemLabel(value)
            },
            _computeMenuVerticalOffset: function(noLabelFloat) {
                return noLabelFloat ? -4 : 8
            },
            _getValidity: function() {
                return this.disabled || !this.required || this.required && !!this.value
            },
            _openedChanged: function() {
                var openState = this.opened ? "true" : "false",
                    e = this.contentElement;
                e && e.setAttribute("aria-expanded", openState)
            }
        })
    }(), Polymer({
        is: "sp-language-select",
        properties: {
            controlsDisabled: {
                type: Boolean
            },
            ignoreEvents: {
                type: Boolean,
                value: !0
            },
            language: {
                type: String,
                notify: !0
            }
        },
        listeners: {
            tap: "onTap"
        },
        onTap: function() {
            this.fire("sp-analytics-event", {
                eventCategory: "Language Dropdown",
                eventAction: "click",
                eventLabel: "Language Clicked"
            })
        },
        onLanguageSelected: function(event) {
            return this.language = event.target.selected, this.ignoreEvents ? void(this.ignoreEvents = !1) : void this.fire("sp-analytics-event", {
                eventCategory: "Language Dropdown",
                eventAction: "change",
                eventLabel: "Language Changed"
            })
        }
    }), Polymer({
        is: "sp-listening-dots"
    }), Polymer({
        is: "sp-captcha",
        properties: {
            apiKey: {
                type: String,
                value: "6LfEzwwUAAAAAFRKbujVWTzDuGpec8VNLAogFScV"
            },
            captchaReady: {
                type: Boolean,
                value: !1
            },
            captchaURL: {
                type: String,
                value: "https://www.google.com/recaptcha/api.js"
            },
            checkCaptcha: {
                type: Number,
                value: 0
            }
        },
        ready: function() {
            var script = document.createElement("script");
            script.src = this.captchaURL, document.head.appendChild(script), this.checkCaptcha = setInterval(function() {
                window.grecaptcha && (this.captchaReady = !0, this.addCaptcha(), clearInterval(this.checkCaptcha))
            }.bind(this), 200)
        },
        addCaptcha: function() {
            var reCaptchaWidget = window.grecaptcha.render(this.$.captchaContainer, {
                sitekey: this.apiKey,
                callback: function() {
                    this.fire("sp-captcha-verify"), setTimeout(function() {
                        window.grecaptcha.reset(reCaptchaWidget)
                    }, 1e3)
                }.bind(this)
            })
        }
    }), Polymer({
        is: "sp-controls",
        properties: {
            attempts: {
                type: Number,
                value: 0
            },
            captchaEvery: {
                type: Number,
                readOnly: !0,
                value: 5
            },
            controlsDisabled: {
                type: Boolean
            },
            isRecording: {
                type: Boolean,
                notify: !0
            },
            language: {
                type: String,
                notify: !0
            },
            needsCaptcha: {
                type: Boolean,
                value: !1
            },
            tempResult: {
                type: String
            },
            timeDisplay: {
                type: String
            }
        },
        listeners: {
            "record.tap": "startRecord",
            "stop.tap": "stopRecord",
            "captcha.sp-captcha-verify": "captchaSuccess"
        },
        captchaSuccess: function() {
            this.needsCaptcha = !1, this.isRecording = !0
        },
        startRecord: function() {
            var captchaReady = this.$.captcha.captchaReady;
            return this.attempts++, this.attempts % this.captchaEvery === 0 && captchaReady ? (this.fire("sp-analytics-event", {
                eventCategory: "Captcha",
                eventAction: "display",
                eventLabel: "Captcha displayed"
            }), void(this.needsCaptcha = !0)) : void(this.isRecording = !0)
        },
        stopRecord: function() {
            this.isRecording = !1
        }
    }), Polymer({
        is: "sp-loading"
    }), Polymer({
        is: "iron-image",
        properties: {
            src: {
                observer: "_srcChanged",
                type: String,
                value: ""
            },
            alt: {
                type: String,
                value: null
            },
            preventLoad: {
                type: Boolean,
                value: !1,
                observer: "_preventLoadChanged"
            },
            sizing: {
                type: String,
                value: null,
                reflectToAttribute: !0
            },
            position: {
                type: String,
                value: "center"
            },
            preload: {
                type: Boolean,
                value: !1
            },
            placeholder: {
                type: String,
                value: null,
                observer: "_placeholderChanged"
            },
            fade: {
                type: Boolean,
                value: !1
            },
            loaded: {
                notify: !0,
                readOnly: !0,
                type: Boolean,
                value: !1
            },
            loading: {
                notify: !0,
                readOnly: !0,
                type: Boolean,
                value: !1
            },
            error: {
                notify: !0,
                readOnly: !0,
                type: Boolean,
                value: !1
            },
            width: {
                observer: "_widthChanged",
                type: Number,
                value: null
            },
            height: {
                observer: "_heightChanged",
                type: Number,
                value: null
            }
        },
        observers: ["_transformChanged(sizing, position)"],
        ready: function() {
            var img = this.$.img;
            img.onload = function() {
                this.$.img.src === this._resolveSrc(this.src) && (this._setLoading(!1), this._setLoaded(!0), this._setError(!1))
            }.bind(this), img.onerror = function() {
                this.$.img.src === this._resolveSrc(this.src) && (this._reset(), this._setLoading(!1), this._setLoaded(!1), this._setError(!0))
            }.bind(this), this._resolvedSrc = ""
        },
        _load: function(src) {
            src ? this.$.img.src = src : this.$.img.removeAttribute("src"), this.$.sizedImgDiv.style.backgroundImage = src ? 'url("' + src + '")' : "", this._setLoading(!!src), this._setLoaded(!1), this._setError(!1)
        },
        _reset: function() {
            this.$.img.removeAttribute("src"), this.$.sizedImgDiv.style.backgroundImage = "", this._setLoading(!1), this._setLoaded(!1), this._setError(!1)
        },
        _computePlaceholderHidden: function() {
            return !this.preload || !this.fade && !this.loading && this.loaded
        },
        _computePlaceholderClassName: function() {
            return this.preload && this.fade && !this.loading && this.loaded ? "faded-out" : ""
        },
        _computeImgDivHidden: function() {
            return !this.sizing
        },
        _computeImgDivARIAHidden: function() {
            return "" === this.alt ? "true" : void 0
        },
        _computeImgDivARIALabel: function() {
            if (null !== this.alt) return this.alt;
            if ("" === this.src) return "";
            var pathComponents = new URL(this._resolveSrc(this.src)).pathname.split("/");
            return pathComponents[pathComponents.length - 1]
        },
        _computeImgHidden: function() {
            return !!this.sizing
        },
        _widthChanged: function() {
            this.style.width = isNaN(this.width) ? this.width : this.width + "px"
        },
        _heightChanged: function() {
            this.style.height = isNaN(this.height) ? this.height : this.height + "px"
        },
        _preventLoadChanged: function() {
            this.preventLoad || this.loaded || (this._reset(), this._load(this.src))
        },
        _srcChanged: function(newSrc) {
            var newResolvedSrc = this._resolveSrc(newSrc);
            newResolvedSrc !== this._resolvedSrc && (this._resolvedSrc = newResolvedSrc, this._reset(), this.preventLoad || this._load(newSrc))
        },
        _placeholderChanged: function() {
            this.$.placeholder.style.backgroundImage = this.placeholder ? 'url("' + this.placeholder + '")' : ""
        },
        _transformChanged: function() {
            var sizedImgDivStyle = this.$.sizedImgDiv.style,
                placeholderStyle = this.$.placeholder.style;
            sizedImgDivStyle.backgroundSize = placeholderStyle.backgroundSize = this.sizing, sizedImgDivStyle.backgroundPosition = placeholderStyle.backgroundPosition = this.sizing ? this.position : "", sizedImgDivStyle.backgroundRepeat = placeholderStyle.backgroundRepeat = this.sizing ? "no-repeat" : ""
        },
        _resolveSrc: function(testSrc) {
            var baseURI = this.ownerDocument.baseURI;
            return baseURI ? new URL(testSrc, baseURI).href : testSrc
        }
    }), Polymer({
        is: "paper-card",
        properties: {
            heading: {
                type: String,
                value: "",
                observer: "_headingChanged"
            },
            image: {
                type: String,
                value: ""
            },
            alt: {
                type: String
            },
            preloadImage: {
                type: Boolean,
                value: !1
            },
            fadeImage: {
                type: Boolean,
                value: !1
            },
            placeholderImage: {
                type: String,
                value: null
            },
            elevation: {
                type: Number,
                value: 1,
                reflectToAttribute: !0
            },
            animatedShadow: {
                type: Boolean,
                value: !1
            },
            animated: {
                type: Boolean,
                reflectToAttribute: !0,
                readOnly: !0,
                computed: "_computeAnimated(animatedShadow)"
            }
        },
        _isHidden: function(image) {
            return image ? "false" : "true"
        },
        _headingChanged: function(heading) {
            this.getAttribute("aria-label");
            this.setAttribute("aria-label", heading)
        },
        _computeHeadingClass: function(image) {
            return image ? " over-image" : ""
        },
        _computeAnimated: function(animatedShadow) {
            return animatedShadow
        }
    }), Polymer({
        is: "sp-result-stack",
        properties: {
            expanded: {
                type: Boolean,
                value: !1
            },
            maxResults: {
                type: Number,
                value: 5
            },
            totalResults: {
                type: Number,
                value: 0
            },
            multipleResults: {
                type: Boolean,
                value: !1
            }
        },
        addResult: function(resultText) {
            var card = document.createElement("paper-card"),
                result = document.createElement("div"),
                deck = this.$.deck;
            for (Polymer.dom(result).classList.add("result-text"), Polymer.dom(result).appendChild(document.createTextNode(resultText)), Polymer.dom(card).appendChild(result), Polymer.dom(deck).classList.add("no-transition"), Polymer.dom(deck).insertBefore(card, Polymer.dom(deck).firstElementChild), this.totalResults++; this.totalResults > this.maxResults;) this.removeResult();
            this.multipleResults = this.totalResults > 1, deck.offsetHeight, Polymer.dom(deck).classList.remove("no-transition")
        },
        removeResult: function() {
            if (0 !== this.totalResults) {
                var deck = this.$.deck,
                    lastCard = Polymer.dom(deck).lastChild;
                lastCard && (Polymer.dom(deck).removeChild(lastCard), this.totalResults--, this.multipleResults = this.totalResults > 1)
            }
        },
        toggleDeck: function() {
            this.multipleResults && (this.expanded = !this.expanded)
        }
    }), Polymer({
        is: "sp-app",
        properties: {
            audioContext: {
                type: Object
            },
            bufferSize: {
                type: Number,
                readOnly: !0,
                value: 4096
            },
            controlsDisabled: {
                type: Boolean,
                value: !1
            },
            checkRecorder: {
                type: Number,
                value: !1
            },
            fallbackKey: {
                type: String,
                readOnly: !0,
                value: "AIzaSyBmmqjUsStJat65IP7KgKuH2cz6rRvlIr8"
            },
            fallbackUrl: {
                type: String,
                readOnly: !0,
                value: "//speech.googleapis.com/v1beta1/speech:syncrecognize"
            },
            isRecording: {
                type: Boolean,
                value: !1,
                observer: "stateChanged"
            },
            isReady: {
                type: Boolean,
                value: !1
            },
            language: {
                type: String,
                value: "en-US"
            },
            maxRecordTime: {
                type: Number,
                value: 5e4
            },
            mediaTrack: {
                type: Object
            },
            processor: {
                type: Object
            },
            recorder: {
                type: Object
            },
            recorderLib: {
                type: String,
                readOnly: !0,
                value: "//gstatic.com/external_hosted/recorderjs/recorder.js"
            },
            recorderWorkerLib: {
                type: String,
                readOnly: !0,
                value: "//gstatic.com/external_hosted/recorderjs/recorderWorker.js"
            },
            startTime: {
                type: Number
            },
            socket: {
                type: Object
            },
            streamingAvailable: {
                type: Boolean
            },
            timeDisplay: {
                type: String,
                value: "00:00"
            },
            tempResult: {
                type: String,
                value: ""
            },
            updateInterval: {
                type: Number
            },
            serverUrl: {
                type: String,
                value: "cloudspeech.goog"
            }
        },
        listeners: {
            "sp-analytics-event": "handleAnalyticsEvent"
        },
        ready: function() {
            try {
                window.AudioContext = window.AudioContext || window.webkitAudioContext, navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia
            } catch (e) {
                return this.$.resultStack.addResult("Your browser is not currently supported."), this.isReady = !0, void(this.controlsDisabled = !0)
            }
            return navigator.getUserMedia && window.AudioContext ? (this.audioContext = new AudioContext, void this.checkServer()) : (this.$.resultStack.addResult("Your browser is not currently supported."), this.isReady = !0, void(this.controlsDisabled = !0))
        },
        checkServer: function() {
            var ajax = new XMLHttpRequest;
            ajax.onload = function() {
                ajax.status >= 200 && ajax.status < 400 && (this.streamingAvailable = !0, this.isReady = !0, this.controlsDisabled = !1)
            }.bind(this), ajax.onerror = function() {
                this.initFallback()
            }.bind(this), ajax.open("GET", "//" + this.serverUrl + "/status", !0), ajax.send()
        },
        handleAnalyticsEvent: function(e) {
            this.$.analytics.recordEvent(e.detail)
        },
        initFallback: function() {
            var script = document.createElement("script");
            script.src = this.recorderLib, document.head.appendChild(script), this.checkRecorder = setInterval(function() {
                window.Recorder && (this.isReady = !0, this.controlsDisabled = !1, this.maxRecordTime = 3e4, clearInterval(this.checkRecorder))
            }.bind(this), 200), this.streamingAvailable = !1
        },
        processAudio: function(e) {
            for (var float32Array = e.inputBuffer.getChannelData(0) || new Float32Array(this.bufferSize), len = float32Array.length, int16Array = new Int16Array(len); len--;) int16Array[len] = 32767 * Math.min(1, float32Array[len]);
            this.socket.send(int16Array.buffer)
        },
        startRecording: function() {
            this.controlsDisabled = !0, this.timeDisplay = "00:00 / 00:" + this.maxRecordTime / 1e3, this.startTime = Date.now(), this.updateInterval = setInterval(function() {
                this.updateApp()
            }.bind(this), 500), this.streamingAvailable ? this.startStreaming() : this.startFallback(), this.fire("sp-analytics-event", {
                eventCategory: "Record",
                eventAction: "start",
                eventLabel: "Record started"
            })
        },
        startFallback: function() {
            this.tempResult = "Recording...", navigator.getUserMedia({
                audio: {
                    mandatory: {
                        googEchoCancellation: "false",
                        googAutoGainControl: "false",
                        googNoiseSuppression: "false",
                        googHighpassFilter: "false"
                    },
                    optional: []
                }
            }, function(stream) {
                var input = this.audioContext.createMediaStreamSource(stream);
                this.mediaTrack = stream.getTracks()[0], this.recorder = new window.Recorder(input, {
                    numChannels: 1,
                    workerPath: this.recorderWorkerLib
                }), this.recorder.clear(), this.recorder.record()
            }.bind(this), function() {
                this.$.resultStack.addResult("There was an error connecting to the application.")
            }.bind(this))
        },
        startStreaming: function() {
            this.tempResult = "", this.socket = new WebSocket("wss://" + this.serverUrl + "/ws"), this.socket.binaryType = "arraybuffer", this.socket.onopen = function() {
                this.socket.send(JSON.stringify({
                    rate: this.audioContext.sampleRate,
                    language: this.language,
                    format: "LINEAR16"
                })), navigator.getUserMedia({
                    audio: !0
                }, function(stream) {
                    var source = this.audioContext.createMediaStreamSource(stream);
                    this.processor = this.audioContext.createScriptProcessor(this.bufferSize, 1, 1), this.processor.onaudioprocess = function(e) {
                        this.processAudio(e)
                    }.bind(this), this.processor.connect(this.audioContext.destination), source.connect(this.processor), this.mediaTrack = stream.getTracks()[0]
                }.bind(this), function() {
                    this.$.resultStack.addResult("There was an error communicating with the server. Please try again later."), this.stopRecording()
                }.bind(this))
            }.bind(this), this.socket.onmessage = function(e) {
                var response = JSON.parse(e.data);
                response.isFinal ? (this.$.resultStack.addResult(response.text.trim()), this.tempResult = "") : response.text.length >= this.tempResult.length && (this.tempResult = response.text)
            }.bind(this), this.socket.onclose = function() {
                this.controlsDisabled = !1
            }.bind(this), this.socket.onerror = function() {
                this.$.resultStack.addResult("There was an error communicating with the server. Please try again later.")
            }.bind(this)
        },
        stateChanged: function(newValue, oldValue) {
            return "undefined" != typeof oldValue ? this.isRecording ? void this.startRecording() : void this.stopRecording() : void 0
        },
        stopRecording: function() {
            var recTime = Date.now() - this.startTime;
            this.isRecording = !1, clearInterval(this.updateInterval), this.timeDisplay = "00:00 / 00:" + this.maxRecordTime / 1e3, this.streamingAvailable ? this.stopStreaming() : this.stopFallback(), this.fire("sp-analytics-event", {
                eventCategory: "Record",
                eventAction: "stop",
                eventLabel: "Record stopped",
                eventValue: recTime
            })
        },
        stopStreaming: function() {
            setTimeout(function() {
                this.audioContext && "running" == this.audioContext.state && (this.processor && (this.processor.onaudioprocess = function() {}), this.processor = {}), this.socket && 1 == this.socket.readyState && (this.socket && this.socket.close(), this.socket = {}), "" !== this.tempResult && (this.$.resultStack.addResult(this.tempResult), this.tempResult = ""), this.mediaTrack && (this.mediaTrack.stop(), this.mediaTrack = {})
            }.bind(this), 1500), clearInterval(this.updateInterval), this.timeDisplay = "00:00 / 00:" + this.maxRecordTime / 1e3
        },
        stopFallback: function() {
            this.tempResult = "Processing...", setTimeout(function() {
                this.recorder.stop(), this.mediaTrack && (this.mediaTrack.stop(), this.mediaTrack = {}), this.recorder.exportWAV(function(blob) {
                    var reader = new FileReader;
                    reader.onload = function(readerEvt) {
                        var binaryString = readerEvt.target.result;
                        this.sendAudio(btoa(binaryString), this.language, "LINEAR16", this.audioContext.sampleRate)
                    }.bind(this), reader.readAsBinaryString(blob)
                }.bind(this))
            }.bind(this), 500)
        },
        sendAudio: function(binaryAudioFile, language, encoding, sampleRate) {
            var request = JSON.stringify({
                    config: {
                        encoding: encoding,
                        sampleRate: sampleRate,
                        languageCode: language,
                        maxAlternatives: 1
                    },
                    audio: {
                        content: binaryAudioFile
                    }
                }),
                ajax = new XMLHttpRequest;
            ajax.onload = function() {
                if (ajax.status >= 200 && ajax.status < 400) {
                    var data = JSON.parse(ajax.responseText);
                    if (this.controlsDisabled = !1, this.tempResult = "", this.recorder = {}, !data.results) return void this.$.resultStack.addResult("No Speech Detected");
                    var transcript = data.results.map(function(result) {
                        return result.alternatives[0].transcript
                    });
                    this.$.resultStack.addResult(transcript.join(""))
                } else this.$.resultStack.addResult("Service unavailable")
            }.bind(this), ajax.open("POST", this.fallbackUrl + "?key=" + this.fallbackKey, !0), ajax.send(request)
        },
        updateApp: function() {
            var recTime = Date.now() - this.startTime;
            if (recTime >= this.maxRecordTime) this.stopRecording();
            else if (recTime >= 1e3) {
                var formattedTime = 1e4 > recTime ? "0" + recTime.toString().slice(0, -3) : recTime.toString().slice(0, -3);
                this.timeDisplay = "00:" + formattedTime + " / 00:" + this.maxRecordTime / 1e3
            }
        }
    });