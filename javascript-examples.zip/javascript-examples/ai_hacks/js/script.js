$(document).ready(function(){
	$('.helpIcon').on('click touch', function (e) {
		alert('tapped');
	      e.preventDefault();
	};
});