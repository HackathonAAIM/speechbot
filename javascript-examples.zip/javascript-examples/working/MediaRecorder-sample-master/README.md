#  Sample Code for HTML5 MediaRecorder API usage

-------

### [demo](https://mido22.github.io/MediaRecorder-sample/)

-------

### Works on:
* Chrome: v47+
* Firefox: v25+
